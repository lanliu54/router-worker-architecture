"""Move verified retired role files out of discovery while retaining rollback."""
import argparse
from contextlib import closing
import json
from pathlib import Path
import sqlite3

RUNTIME = Path("integrations/hybrid-api-workers")
RETIRED_ROLE = "api_terra_content"
FILES = (
    "agents/terra_content_subscription.toml",
    "agents/terra_desktop_native.toml",
    (RUNTIME / "prompts/api_terra_content.txt").as_posix(),
)
TERMINAL = ("completed", "completed_observed", "cancelled", "superseded")


def retired_files(package):
    records = json.loads((package / "reference/retired-terra-files.json").read_text(encoding="utf-8"))
    if set(records) != set(FILES) or any(not values for values in records.values()):
        raise ValueError("Retirement metadata does not cover the exact managed paths")
    return records


def retire(home, package, *, restore=False, apply=False):
    from portable import safe, sha, verify_package

    verify_package(package)
    home = Path(home).absolute()
    runtime = home / RUNTIME
    rollback = runtime / ".retired-terra-content"
    changes = []
    for relative, hashes in retired_files(package).items():
        active = safe(home / relative, home)
        retired = safe(rollback / relative, home)
        if active.exists() and retired.exists():
            raise ValueError("Conflicting active and rollback files: " + relative)
        source, target = (retired, active) if restore else (active, retired)
        if source.exists():
            if not source.is_file() or sha(source.read_bytes()) not in hashes:
                raise ValueError("Retired-role file differs from the verified baseline: " + relative)
            changes.append((source, target, sha(source.read_bytes())))
    maintenance = safe(runtime / "maintenance.json", home)
    if not maintenance.is_file() or json.loads(maintenance.read_text(encoding="utf-8"))["enabled"] is not True:
        raise ValueError("Retirement and rollback require the target maintenance window")
    database = safe(runtime / "state/tasks.sqlite3", home)
    if database.is_file():
        with closing(sqlite3.connect(database.as_uri() + "?mode=ro", uri=True)) as db:
            if db.execute("SELECT 1 FROM tasks WHERE role=? AND status NOT IN (?,?,?,?) LIMIT 1",
                          (RETIRED_ROLE, *TERMINAL)).fetchone():
                raise ValueError("An unfinished retired-role task requires reconciliation")
    desktop = safe(runtime / "routing/state/desktop-dispatch.sqlite3", home)
    if desktop.is_file():
        with closing(sqlite3.connect(desktop.as_uri() + "?mode=ro", uri=True)) as db:
            if db.execute("SELECT 1 FROM dispatches WHERE phase IN ('prepared','dispatch_pending','active')").fetchone():
                raise ValueError("An active desktop handoff requires reconciliation")
    if apply:
        moved = []
        try:
            for source, target, expected in changes:
                target.parent.mkdir(parents=True, exist_ok=True)
                if target.exists() or sha(source.read_bytes()) != expected:
                    raise ValueError("Retirement path changed after preview")
                source.rename(target)
                moved.append((source, target))
        except Exception:
            for source, target in reversed(moved):
                target.rename(source)
            raise
    return {"status": "applied" if apply else "preview", "restore": restore,
            "moves": [{"from": str(source.relative_to(home)), "to": str(target.relative_to(home)),
                       "sha256": expected} for source, target, expected in changes]}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--codex-home", required=True, type=Path)
    parser.add_argument("--restore", action="store_true")
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()
    print(json.dumps(retire(args.codex_home, Path(__file__).resolve().parent,
                            restore=args.restore, apply=args.apply)))

"""Upgrade a verified older Router–Worker installation to the editable layout."""
import argparse
from contextlib import closing
import json
import os
from pathlib import Path
import re
import sqlite3
import sys
import tempfile
import time

from portable import BEGIN_END, encode, safe, sha, verify_package

PACKAGE = Path(__file__).resolve().parent
RUNTIME = "integrations/hybrid-api-workers/"
BACKUP = RUNTIME + ".editable-upgrade-3.0.10"
PRESERVE = {"maintenance.json", "personalization-policy.json"}
RETIRED = ("agents/terra_content_subscription.toml", "agents/terra_desktop_native.toml",
           RUNTIME + "prompts/api_terra_content.txt", RUNTIME + "verify_local.py",
           RUNTIME + "prompts/api_astra_review.txt")
GUIDANCE = ("workers-block.md", "ownership-block.md", "controller-block.md", "in-place-block.md")
ACTIVE = ("queued", "validation_ready", "preparing", "api_running", "unknown_execution", "fallback_claimed")


def read(path):
    return path.read_bytes() if path.is_file() else None


def install_bytes(path, value):
    if value is None:
        path.unlink()
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=path.parent, delete=False) as stream:
        temp = Path(stream.name)
        stream.write(value)
    try:
        os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)


def quiescent(home):
    maintenance = safe(home / (RUNTIME + "maintenance.json"), home)
    if json.loads(maintenance.read_bytes()).get("enabled") is not True:
        raise ValueError("Enable the target maintenance window before an upgrade or rollback")
    worker = safe(home / (RUNTIME + "state/tasks.sqlite3"), home)
    if worker.is_file():
        with closing(sqlite3.connect(worker.as_uri() + "?mode=ro", uri=True)) as db:
            marks = ",".join("?" for _ in ACTIVE)
            if db.execute(f"SELECT 1 FROM tasks WHERE status IN ({marks}) LIMIT 1", ACTIVE).fetchone():
                raise ValueError("An active or uncertain Worker task requires reconciliation")
    controller = safe(home / (RUNTIME + "orchestrator-control/runtime/state.sqlite"), home)
    if controller.is_file():
        with closing(sqlite3.connect(controller.as_uri() + "?mode=ro", uri=True)) as db:
            if db.execute("SELECT 1 FROM attempts WHERE status IN ('starting','running','waiting_external','unknown') LIMIT 1").fetchone():
                raise ValueError("An active or uncertain Controller attempt requires reconciliation")

    desktop = safe(home / (RUNTIME + "routing/state/desktop-dispatch.sqlite3"), home)
    if desktop.is_file():
        with closing(sqlite3.connect(desktop.as_uri() + "?mode=ro", uri=True)) as db:
            tables = {row[0] for row in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            if ("dispatches" in tables and db.execute("SELECT 1 FROM dispatches WHERE phase IN ('prepared','dispatch_pending','active')").fetchone()
                    or "main_ui_leases" in tables and db.execute("SELECT 1 FROM main_ui_leases WHERE phase='active'").fetchone()):
                raise ValueError("An active UI grant requires reconciliation")


def merge_blocks(raw, allowed):
    body = raw.decode("utf-8-sig")
    # Older packages use a separate exact-phrase repair block. Replace only
    # the verified old bytes, leaving all unrelated instructions intact.
    begin, end = "<!-- BEGIN ROUTER_WORKER_REPAIR_V1 -->", "<!-- END ROUTER_WORKER_REPAIR_V1 -->"
    if begin in body or end in body:
        if body.count(begin) != 1 or body.count(end) != 1 or body.index(end) < body.index(begin):
            raise ValueError("Ambiguous older repair guidance")
        old = body[body.index(begin):body.index(end) + len(end)]
        if sha(old.replace("\r\n", "\n").encode()) not in allowed.get("repair-block.md", []):
            raise ValueError("Older repair guidance has local changes")
        body = body.replace(old, "", 1)
    for name, (begin, end) in zip(GUIDANCE, BEGIN_END):
        new = (PACKAGE / "reference" / name).read_text(encoding="utf-8").strip()
        if begin in body or end in body:
            if body.count(begin) != 1 or body.count(end) != 1 or body.index(end) < body.index(begin):
                raise ValueError("Ambiguous managed guidance")
            old = body[body.index(begin):body.index(end) + len(end)]
            if old.replace("\r\n", "\n") != new and sha(old.replace("\r\n", "\n").encode()) not in allowed.get(name, []):
                raise ValueError("Managed guidance has local changes: " + name)
            body = body.replace(old, new, 1)
        else:
            body = body.rstrip() + "\n\n" + new + "\n"
    if len(body.encode()) > 32768:
        raise ValueError("Merged guidance exceeds the discovery size")
    return body.encode()


def plan(home):
    verify_package()
    quiescent(home)
    reference = json.loads((PACKAGE / "reference/upgrade-baselines.json").read_bytes())
    rec = json.loads(safe(home / (RUNTIME + "portable-deployment.json"), home).read_bytes())
    if (rec.get("status") != "installed" or Path(rec.get("codex_home", "")) != home
            or rec.get("package_manifest_sha256") not in reference["manifest_sha256"]):
        raise ValueError("Target is not one of the verified migration baselines")
    owned = {e["path"]: e["installed_sha256"] for e in rec["files"]}
    for directory in (".editable-upgrade", ".editable-upgrade-3.0.7", ".editable-upgrade-3.0.8", ".editable-upgrade-3.0.9"):
        earlier = read(safe(home / (RUNTIME + directory + "/record.json"), home))
        if earlier is None:
            continue
        prior = json.loads(earlier)
        if prior.get("status") not in ("installed", "rolled_back"):
            raise ValueError("An earlier upgrade requires reconciliation")
        if prior["status"] == "installed":
            payload_names = {p.relative_to(PACKAGE / "payload").as_posix()
                             for p in (PACKAGE / "payload").rglob("*") if p.is_file()}
            for name, entry in prior["files"].items():
                if name not in payload_names and name not in RETIRED or not entry.get("after"):
                    continue
                owned[name] = entry["after"]
    changes = {}
    for path in (PACKAGE / "payload").rglob("*"):
        if not path.is_file():
            continue
        name = path.relative_to(PACKAGE / "payload").as_posix()
        if name.startswith(RUNTIME) and name[len(RUNTIME):] in PRESERVE:
            continue
        target = safe(home / name, home)
        old, new = read(target), path.read_bytes()
        if name == RUNTIME + "settings.json" and old is not None:
            settings = json.loads(old)
            settings["live_enabled"] = False
            new = encode(settings)
        elif name == RUNTIME + "architecture-policy.json":
            if old is not None and old != new and sha(old) != owned.get(name):
                raise ValueError("Owned payload has drift or conflicts: " + name)
            policy = json.loads(new)
            policy["host_spawn_effective_at_epoch"] = max(int(time.time()), policy["host_spawn_effective_at_epoch"])
            new = encode(policy)
        elif name == RUNTIME + "orchestrator-control/runtime/config.json" and old is not None:
            cfg = json.loads(old)
            defaults = json.loads(new)
            for key in ("architecture_profile", "native_astra_qa_boundary"):
                cfg[key] = defaults[key]
            cfg.setdefault("role_policy_version", defaults["role_policy_version"])
            cfg.update(mode="observe", dispatch_enabled=False, native_session_control=False)
            new = encode(cfg)
        elif old is not None and old != new and sha(old) != owned.get(name):
            raise ValueError("Owned payload has drift or conflicts: " + name)
        if old != new:
            changes[name] = old, new
    for name in RETIRED:
        old = read(safe(home / name, home))
        if old is not None:
            if sha(old) != owned.get(name) or sha(old) not in reference["retired"][name]:
                raise ValueError("Retired role file has drift: " + name)
            changes[name] = old, None
    for name in ("AGENTS.md", "AGENTS.override.md"):
        old = read(safe(home / name, home))
        if name.endswith(".override.md") and not (old or b"").strip():
            continue
        new = merge_blocks(old or b"", reference["blocks"])
        if old != new:
            changes[name] = old, new
    return changes


def transition(home, changes):
    applied = []
    try:
        for name, (before, after) in changes.items():
            path = safe(home / name, home)
            if read(path) != before:
                raise ValueError("Concurrent target change: " + name)
            install_bytes(path, after)
            applied.append(name)
    except BaseException:
        for name in reversed(applied):
            before, after = changes[name]
            path = safe(home / name, home)
            if read(path) == after:
                install_bytes(path, before)
        raise


def run(action, home, apply):
    record = safe(home / (BACKUP + "/record.json"), home)
    if action == "upgrade":
        if record.exists():
            raise ValueError("Existing upgrade record requires verification or reconciliation")
        changes = plan(home)
        if not apply:
            return {"status": "upgrade_ready", "changed_files": len(changes)}
        entries = {}
        for name, (old, new) in changes.items():
            if old is not None:
                backup = safe(home / (BACKUP + "/before/" + name), home)
                if backup.exists():
                    raise ValueError("Unexpected previous backup: " + name)
                install_bytes(backup, old)
            entries[name] = {"before": sha(old) if old is not None else None,
                             "after": sha(new) if new is not None else None}
        install_bytes(record, encode({"status": "applying", "files": entries}))
        transition(home, changes)
        install_bytes(record, encode({"status": "installed", "files": entries}))
        return {"status": "upgrade_applied", "changed_files": len(changes)}

    state = json.loads(record.read_bytes())
    if state["status"] != "installed":
        raise ValueError("Upgrade record is not in an installed state")
    changes = {}
    for name, item in state["files"].items():
        old = read(safe(home / (BACKUP + "/before/" + name), home))
        new = read(safe(home / name, home))
        if (sha(old) if old is not None else None) != item["before"] or (
                sha(new) if new is not None else None) != item["after"]:
            raise ValueError("Upgrade backup or installed file has drift: " + name)
        changes[name] = new, old
    if action == "verify":
        return {"status": "upgrade_verified", "changed_files": len(changes)}
    quiescent(home)
    if apply:
        transition(home, dict(reversed(changes.items())))
        state["status"] = "rolled_back"
        install_bytes(record, encode(state))
    return {"status": "upgrade_rolled_back" if apply else "upgrade_rollback_ready"}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("upgrade", "verify", "rollback"))
    parser.add_argument("--codex-home", type=Path, default=os.environ.get("CODEX_HOME", str(Path.home() / ".codex")))
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()
    try:
        print(json.dumps(run(args.action, args.codex_home.absolute(), args.apply)))
    except (OSError, ValueError, KeyError, sqlite3.Error) as exc:
        print(json.dumps({"status": "stopped", "reason": str(exc)}), file=sys.stderr)
        sys.exit(1)

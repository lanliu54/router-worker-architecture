param(
    [ValidateSet('check-package','install','verify','rollback')][string]$Action = 'install',
    [string]$CodexHome = '',
    [string]$Python = '',
    [switch]$Apply
)
$ErrorActionPreference = 'Stop'
if (-not $Python) {
    $taskPythonCommand = Get-Command python -ErrorAction SilentlyContinue
    if (-not $taskPythonCommand) { throw 'Install Python 3.12+ or supply -Python with the executable path.' }
    $Python = $taskPythonCommand.Source
}
$taskArgs = @('-X','utf8','-B',(Join-Path $PSScriptRoot 'portable.py'),$Action)
if ($CodexHome) { $taskArgs += @('--codex-home',$CodexHome) }
if ($Apply) { $taskArgs += '--apply' }
& $Python @taskArgs
if ($LASTEXITCODE -ne 0) { throw 'The operation stopped. Review the reported conflict before retrying.' }

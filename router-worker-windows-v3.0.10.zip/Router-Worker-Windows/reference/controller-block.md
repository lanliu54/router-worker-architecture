<!-- BEGIN ROUTER_WORKER_P0_P3_V1 -->
For controller-managed work read the installed controller runbook and read-only status/inbox. Preserve historical profiles and distinguish submitted, validated, independently reviewed, accepted and published. Hooks are bounded evidence.
<!-- END ROUTER_WORKER_P0_P3_V1 -->

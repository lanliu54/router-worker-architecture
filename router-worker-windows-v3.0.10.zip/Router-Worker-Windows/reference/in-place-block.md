<!-- BEGIN ROUTER_WORKER_IN_PLACE_V1 -->
## Router–Worker architecture maintenance

- A direct user request to maintain Router–Worker itself authorizes the main session to inspect, edit and locally validate the installed source within that scope. Edit the authoritative installation at `integrations/hybrid-api-workers/` under the Codex home. Use a normal main chat without a bound Worker task. Follow the installed RUNBOOK and keep one code/configuration rollback snapshot.
- The managed routing rules below govern Worker tasks. Local architecture maintenance stays with the main session. Use proportionate checks and preserve task ownership, frozen packages, runtime ledgers, uncertain execution, credentials and spend authority. Higher-priority instructions and actual tool permissions still apply.
- Verify the change in a fresh client after the user restarts. An independent review, when requested or required by risk, informs the change without owning the edits or triggering a separate release.
<!-- END ROUTER_WORKER_IN_PLACE_V1 -->

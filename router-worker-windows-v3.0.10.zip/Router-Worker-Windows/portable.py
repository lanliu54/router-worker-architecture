"""Verified offline deployment of the frozen Windows hybrid-worker package.

No credential reads, network requests, hook trust changes or model calls.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import sys
import tomllib

PACKAGE = Path(__file__).resolve().parent
BEGIN_END = [("<!-- BEGIN HYBRID_WORKERS_V2_1 -->", "<!-- END HYBRID_WORKERS_V2_1 -->"),
             ("<!-- BEGIN HYBRID_ROUTING_OWNERSHIP_V1 -->", "<!-- END HYBRID_ROUTING_OWNERSHIP_V1 -->"),
             ("<!-- BEGIN ROUTER_WORKER_P0_P3_V1 -->", "<!-- END ROUTER_WORKER_P0_P3_V1 -->"), ("<!-- BEGIN ROUTER_WORKER_IN_PLACE_V1 -->", "<!-- END ROUTER_WORKER_IN_PLACE_V1 -->")]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encode(data):
    return (json.dumps(data, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def safe(path, root):
    path, root = Path(path).absolute(), Path(root).absolute()
    if not path.is_relative_to(root):
        raise ValueError("Target outside installation root")
    if ".." in path.relative_to(root).parts:
        raise ValueError("Parent traversal refused")
    for p in [path, *path.parents]:
        if p.is_symlink() or (hasattr(p, "is_junction") and p.is_junction()):
            raise ValueError("Linked target refused")
        if p == root:
            break
    if path.exists() and not path.is_file():
        raise ValueError("Expected a regular file")
    return path


def verify_package(package=PACKAGE):
    manifest = json.loads((package / "MANIFEST.json").read_text(encoding="utf-8"))
    names = set()
    for entry in manifest["files"]:
        name = entry["path"]
        pure = PurePosixPath(name)
        if pure.is_absolute() or ".." in pure.parts or "\\" in name or ":" in name or name in names:
            raise ValueError("Invalid manifest entry")
        names.add(name)
        p = safe(package / name, package)
        if not p.is_file() or p.stat().st_size != entry["bytes"] or sha(p.read_bytes()) != entry["sha256"]:
            raise ValueError("Package integrity mismatch: " + name)
    actual = {p.relative_to(package).as_posix() for p in package.rglob("*") if p.is_file()}
    if actual != names | {"MANIFEST.json"}:
        raise ValueError("Package has unlisted or missing files")
    return manifest


def set_table(text, section, values):
    """Preserve unrelated TOML bytes, comments and tables; reject ambiguity."""
    if section:
        pattern = re.compile(r"(?m)^\[" + re.escape(section) + r"\][ \t]*(?:#.*)?$")
        hits = list(pattern.finditer(text))
        if len(hits) > 1:
            raise ValueError("Duplicate managed TOML section")
        if not hits:
            return text.rstrip() + "\n\n[" + section + "]\n" + "".join(k + " = " + v + "\n" for k, v in values.items())
        start = hits[0].end()
        next_table = re.search(r"(?m)^\[", text[start:])
        end = start + next_table.start() if next_table else len(text)
    else:
        start = 0
        first = re.search(r"(?m)^\[", text)
        end = first.start() if first else len(text)
    body = text[start:end]
    for key, value in values.items():
        pattern = re.compile(r"(?m)^" + re.escape(key) + r"\s*=.*$")
        replacement = key + " = " + value
        body = pattern.sub(lambda _: replacement, body) if pattern.search(body) else body.rstrip() + "\n" + replacement + "\n"
    return text[:start] + body.rstrip() + "\n\n" + text[end:]


def merge_guidance(body, blocks):
    for block, (begin, end) in zip(blocks, BEGIN_END):
        if begin in body or end in body:
            if body.count(begin) != 1 or body.count(end) != 1:
                raise ValueError("Ambiguous managed guidance block")
            existing = body[body.index(begin):body.index(end) + len(end)]
            if existing.strip() != block.strip():
                raise ValueError("Different existing hybrid guidance; review before installing")
        else:
            body = body.rstrip() + "\n\n" + block.strip() + "\n"
    if len(body.encode("utf-8")) > 32768:
        raise ValueError("Guidance exceeds discovery byte budget")
    return body.encode("utf-8")


def plan(home, python, package=PACKAGE):
    verify_package(package)
    home = Path(home).absolute()
    runtime = home / "integrations/hybrid-api-workers"
    from retire_legacy_terra import retired_files
    for relative in retired_files(package):
        if safe(home / relative, home).exists():
            raise ValueError("Retired managed file found; use the verified in-place upgrade: " + relative)
    if runtime.exists():
        raise ValueError("Integration directory already exists; use verify/rollback or review ownership")
    config_path = safe(home / "config.toml", home)
    text = config_path.read_text(encoding="utf-8-sig") if config_path.exists() else ""
    parsed = tomllib.loads(text)
    if parsed.get("allow_managed_hooks_only") is True:
        raise ValueError("Target allows managed hooks only; local installation cannot override it")
    if parsed.get("model_provider") not in (None, "openai"):
        raise ValueError("Target root provider differs from the subscription route; review explicitly")
    if {"hybrid_api_workers", "worker_orchestrator"} & parsed.get("mcp_servers", {}).keys():
        raise ValueError("Existing hybrid MCP registration requires ownership review")
    snapshot = json.loads((package / "reference/config-owned.json").read_text(encoding="utf-8"))
    text = set_table(text, "", {k: json.dumps(snapshot[k]) for k in snapshot})
    text = set_table(text, "agents", {"enabled": "true"})
    text = set_table(text, "features", {"hooks": "true"})
    service = runtime / "service.py"
    values = {"command": json.dumps(str(python)), "args": json.dumps(["-B", str(service), "--stdio"]),
              "startup_timeout_sec": "30", "tool_timeout_sec": "60", "enabled": "true"}
    text = set_table(text, "mcp_servers.hybrid_api_workers", values)
    controller = runtime / "orchestrator-control"
    launcher = controller / "launch.py"
    text = set_table(text, "mcp_servers.worker_orchestrator", {
        "command": json.dumps(str(python)),
        "args": json.dumps(["-X", "utf8", "-B", str(launcher), "mcp"]),
        "enabled": "true", "startup_timeout_sec": "20", "tool_timeout_sec": "30"})
    after = tomllib.loads(text)
    # Compare all unrelated structured settings, in addition to minimal textual edits.
    for key in set(parsed) | set(after):
        if key not in ("model", "model_reasoning_effort", "model_context_window", "agents", "mcp_servers", "features"):
            if parsed.get(key) != after.get(key):
                raise ValueError("Unrelated root configuration changed")
    for section, exclude in (("agents", {"enabled", "max_concurrent_threads_per_session"}), ("mcp_servers", {"hybrid_api_workers", "worker_orchestrator"}), ("features", {"hooks"})):
        if {k:v for k,v in parsed.get(section, {}).items() if k not in exclude} != {k:v for k,v in after.get(section, {}).items() if k not in exclude}:
            raise ValueError("Unrelated configuration table changed")
    writes = {"config.toml": text.encode("utf-8")}
    blocks = [(package / "reference" / name).read_text(encoding="utf-8") for name in ("workers-block.md", "ownership-block.md", "controller-block.md", "in-place-block.md")]
    for name in ("AGENTS.md", "AGENTS.override.md"):
        path = safe(home / name, home)
        if name.endswith("override.md") and (not path.exists() or not path.read_text(encoding="utf-8-sig").strip()):
            continue
        writes[name] = merge_guidance(path.read_text(encoding="utf-8-sig") if path.exists() else "", blocks)
    previous_hooks = safe(home / "hooks.json", home)
    hooks = json.loads(previous_hooks.read_text(encoding="utf-8-sig")) if previous_hooks.exists() else {"hooks": {}}
    if not isinstance(hooks.get("hooks", {}), dict):
        raise ValueError("Unsupported target hook shape")
    source = json.loads((package / "reference/hooks-source.json").read_text(encoding="utf-8"))
    guard = runtime / "routing/hook_chain.py"
    state = controller / "runtime"
    for event, groups in source["hooks"].items():
        for group in groups:
            for handler in group["hooks"]:
                handler["command"] = f'"{python}" -X utf8 -B "{guard}" --runtime "{state}"'
                handler["commandWindows"] = f'& "{python}" -X utf8 -B "{guard}" --runtime "{state}"'
            existing = hooks.setdefault("hooks", {}).setdefault(event, [])
            if any("hybrid-api-workers" in json.dumps(g).lower() for g in existing):
                raise ValueError("Existing hybrid hooks require ownership review")
        hooks["hooks"][event].extend(groups)
    writes["hooks.json"] = encode(hooks)
    for path in (package / "payload").rglob("*"):
        if path.is_file():
            rel = path.relative_to(package / "payload").as_posix()
            writes[rel] = path.read_bytes()
    settings_key = "integrations/hybrid-api-workers/settings.json"
    settings = json.loads(writes[settings_key])
    assert settings["live_enabled"] is False and settings["billing_confirmed"] is False
    writes[settings_key] = encode(settings)
    policy_key = "integrations/hybrid-api-workers/personalization-policy.json"
    policy = json.loads(writes[policy_key]); policy["codex_home"] = str(home)
    writes[policy_key] = encode(policy)
    for rel, data in writes.items():
        path = safe(home / rel, home)
        if rel not in ("config.toml", "AGENTS.md", "AGENTS.override.md", "hooks.json") and path.exists() and path.read_bytes() != data:
            raise ValueError("Existing role/skill conflict: " + rel)
    return writes


def record_path(home):
    return Path(home) / "integrations/hybrid-api-workers/portable-deployment.json"


def verify_install(home):
    home = Path(home).absolute()
    rec = json.loads(record_path(home).read_text(encoding="utf-8"))
    if rec["codex_home"] != str(home) or rec["status"] != "installed":
        raise ValueError("Deployment identity or state mismatch")
    for entry in rec["files"]:
        path = safe(home / entry["path"], home)
        if not path.is_file() or sha(path.read_bytes()) != entry["installed_sha256"]:
            raise ValueError("Installed file drift: " + entry["path"])
    return {"status": "installed_files_verified", "files": len(rec["files"]), "hook_trust": "requires_product_review_not_verified", "live_model_calls": False}


def install(home, python, package=PACKAGE, apply=False):
    home = Path(home).absolute()
    if record_path(home).exists():
        verify_package(package)
        rec = json.loads(record_path(home).read_text(encoding="utf-8"))
        if rec["package_manifest_sha256"] != sha((package / "MANIFEST.json").read_bytes()):
            raise ValueError("A different package is installed; reconcile instead of treating it as unchanged")
        result = verify_install(home)
        result["idempotent_no_change"] = True
        return result
    writes = plan(home, python, package)
    if not apply:
        return {"status": "ready_dry_run", "write_files": len(writes), "codex_home": str(home), "api_live_enabled": False, "hook_trust": "review_required_after_install"}
    originals = {}; entries = []
    backup = home / "integrations/hybrid-api-workers/.portable-backup"
    for rel, data in writes.items():
        p = safe(home / rel, home)
        original = p.read_bytes() if p.exists() else None
        originals[rel] = original
        entry = {"path": rel, "installed_sha256": sha(data), "existed_before": original is not None, "previous_sha256": sha(original) if original is not None else None}
        if original is not None:
            target = safe(backup / rel, home); target.parent.mkdir(parents=True, exist_ok=True); target.write_bytes(original)
            if target.read_bytes() != original:
                raise ValueError("Backup read-back failed")
        entries.append(entry)
    rec = {"schema": 1, "status": "installing", "codex_home": str(home), "package_manifest_sha256": sha((package / "MANIFEST.json").read_bytes()), "files": entries, "trust_transferred": False, "credentials_transferred": False}
    rp = record_path(home); rp.parent.mkdir(parents=True, exist_ok=True); rp.write_bytes(encode(rec))
    try:
        for rel, data in writes.items():
            p = safe(home / rel, home)
            actual = p.read_bytes() if p.exists() else None
            if actual != originals[rel]:
                raise ValueError("Concurrent target change; installation stopped")
            p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(data)
            if p.read_bytes() != data:
                raise ValueError("Installed read-back mismatch")
    except Exception:
        rec["status"] = "partial_install_requires_reconciliation"; rp.write_bytes(encode(rec))
        raise
    rec["status"] = "installed"; rp.write_bytes(encode(rec))
    return verify_install(home)


def rollback(home, apply=False):
    home = Path(home).absolute(); verify_install(home)
    rec = json.loads(record_path(home).read_text(encoding="utf-8"))
    backup = home / "integrations/hybrid-api-workers/.portable-backup"
    recovery = home / "integrations/hybrid-api-workers/.portable-retired"
    for entry in rec["files"]:
        if entry["existed_before"]:
            p = safe(backup / entry["path"], home)
            if not p.is_file() or sha(p.read_bytes()) != entry["previous_sha256"]:
                raise ValueError("Rollback backup mismatch")
        if (recovery / entry["path"]).exists():
            raise ValueError("Unreconciled retirement target")
    if apply:
        for entry in reversed(rec["files"]):
            p = safe(home / entry["path"], home)
            target = safe(recovery / entry["path"], home); target.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(p), str(target))
            if entry["existed_before"]:
                p.write_bytes((backup / entry["path"]).read_bytes())
        rec["status"] = "rolled_back_preserving_installed_files"; record_path(home).write_bytes(encode(rec))
    return {"status": "rollback_applied" if apply else "rollback_ready", "recovery": str(recovery), "destructive_deletion": False}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=("check-package", "install", "verify", "rollback"))
    parser.add_argument("--codex-home", default=os.environ.get("CODEX_HOME", str(Path.home() / ".codex")))
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()
    if sys.version_info < (3, 12):
        raise ValueError("Python 3.12 or newer is required")
    if args.action == "check-package":
        result = {"status": "package_verified", "version": verify_package()["version"], "files": len(verify_package()["files"])}
    elif args.action == "install":
        result = install(Path(args.codex_home), Path(sys.executable).resolve(), apply=args.apply)
    elif args.action == "verify":
        result = verify_install(Path(args.codex_home))
    else:
        result = rollback(Path(args.codex_home), apply=args.apply)
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        # Do not echo arbitrary configuration bodies or credential values.
        print(json.dumps({"status": "stopped", "error_type": type(error).__name__, "reason": str(error)}, ensure_ascii=False), file=sys.stderr)
        sys.exit(1)

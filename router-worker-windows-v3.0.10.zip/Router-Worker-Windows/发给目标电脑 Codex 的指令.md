# 目标电脑 Codex 验收指令 v3.0.10

读取 `README.md` 和 `VALIDATION.json`，校验包，判断新装或已知基线升级。先预览，再按授权应用。确认 Worker API 退出、Controller Observe、六个 Hook 注册和四个命名角色。配置检查通过后结束维护并重启 Codex。

在新的 Terra/high 主会话，用独立上下文和 `direct_` 名称，通过内置 `spawn_agent` 分别派遣 Sol 执行、Sol QA、Luna 批处理和 Astra 困难分析的公开样例。核对每个子会话的角色、模型、结果和真实 Hook 前后记录。Luna 使用公开样例 B,4；A,3；C,空，按编号升序输出整数和 null，并报告输入与输出各 3 行。核对实际子会话完成状态，确认其回复没有因缺少旧冻结包字段而报 missing_context。按主会话、调用 ID 和宿主记录的实际输入哈希配对前后 Hook。不要用付费 API、旧领取流程或私有材料完成验收。

---
name: hybrid-worker-routing
description: Coordinate managed worker routing, named native subscription roles, author-aware independent QA and uncertain-task recovery. Use for actual dispatch, recovery or routing maintenance.
---

# Built-in subscription dispatch

For new subscription work, the owning Codex root calls built-in `spawn_agent` directly with the exact named role, `fork_turns="none"`, and a unique `task_name` beginning with `direct_`. Put the task, authorized scope, required evidence, acceptance criteria and expected result in `message`. Include decisive wording and necessary originals or their authorized paths. Ordinary native work needs no Worker submission, claim, frozen nine-field package, acknowledgement, activation file or echo. Use the actual returned child ID for follow-up and verify the result in the owning chat.

Use `sol_execution_subscription` for scoped implementation, `sol_qa_subscription` for independent read-only review, `luna_batch_subscription` for bounded batch work, and `astra_review_subscription` for admitted difficult advisory analysis or planning. Preserve the existing model and high effort, actual authorship, inherited-permission boundary, applicable destination authorization and parent acceptance. The Router–Worker API route is retired. For new Astra work, use the named subscription role directly without API submission, credit checks or fallback. The prior API rules apply only to the historical records and recovery operations that remain supported. Preserve material authorization and do not replay uncertain executions. A direct review uses inherited host permissions and role instructions. It does not supply a frozen Controller review receipt. If a formal contract requires verified read-only or snapshot evidence, do not record acceptance without that evidence.

The old claim, preparation, receipt, activation and collection instructions apply only to tasks frozen before the policy cutover. Do not migrate a frozen historical task into a `direct_` task or bypass maintenance, higher-priority runtime constraints, permission or unresolved-work checks. The `direct_` prefix distinguishes built-in dispatch from historical prepared handoffs. The root still owns UI and acceptance.

# Hybrid Worker Routing

For direct user-authorized maintenance of Router–Worker itself, use the installed RUNBOOK. The main chat edits the installed source and validates locally. The user restarts for live acceptance.

## Delivery-level review planning

Plan independent review around a complete delivery. Group related in-place changes for that review. The parent identifies the objective, affected entry points, dependent paths, acceptance criteria and risks before implementation. Group tightly related in-place fixes into one bounded delivery and run relevant deterministic checks before review. Known missing dependencies, unwired entry points, incomplete tests or unresolved acceptance evidence are preparation work, not automatic triggers for another model review. An independently reviewed question may be raised earlier when a specific unresolved design decision blocks progress.

For an L1 delivery with no hard expert-review criterion, use parent inspection and proportionate deterministic checks. For L2/L3 or a hard expert-review criterion, retain the current author-independent reviewer and frozen evidence gates. Do not classify a consequential change as L1 merely to avoid review. Respect an explicit user request for review and all frozen contracts. Distinguish changes under review from the accepted delivery.

After findings, group related corrections and tests. The parent compares the changed paths, dependencies and criteria against the earlier finding and uses a focused review when the controller can verify all remaining criteria under its current snapshot rules. Otherwise submit the necessary current-snapshot review. Prior evidence can inform scoping but is not a formal pass for a changed snapshot. Record the original finding, current revision, affected criteria, checks and remaining uncertainty. Do not infer unchanged behavior from file hashes alone or from an untested dependency graph.

Before each model review, record its concrete question, decision impact, evidence and the reason an existing review does not suffice. Avoid per-fix, reassurance-only and automatically recurring reviews. Track review count, elapsed time and available usage separately; mark unavailable subscription usage as unknown. These workflow instructions do not create an automatic scheduler or override task admission, hard criteria, model independence or human acceptance.

Read the current request and higher-priority runtime rules first. This skill grants no new spending, UI, account, external-action or background authority. Resolve CODEX_HOME, then read `integrations/hybrid-api-workers/architecture-policy.json`, `RUNBOOK.md`, `routing/README.md` and the controller runbook. Inspect active/unknown work and legacy UI grants before dispatch or ownership changes.

## Current v5 ownership and historical direct-native qualification

The earlier claim-based policy was accepted on 2026-11-08. The built-in dispatch above is the current route for new work. Historical API and claim procedures apply only to existing frozen tasks.

| Work | Owner |
| --- | --- |
| Intent, classification, coordination, UI, vision, writing, integration, acceptance | Main session; configured Terra/high subscription unless an explicit current exception applies |
| Technical implementation, computation and debugging | sol_execution_subscription, exact Sol/high, direct native; standing v4 inheritance authorization within the authorized task scope |
| Independent extraction, cleaning, classification and fixed-process routine work | luna_batch_subscription, exact Luna/high, direct native |
| Required independent review of new v5 output from any author | sol_qa_subscription, exact Sol/high, direct native; frozen review_rules_v1 when authorized |
| Admitted difficult analysis and planning | astra_review_subscription, exact Astra/high, direct native and advisory only |

The controller enforces the frozen parent-declared work_kind-to-role mapping. It is not a semantic classifier or universal host interceptor. Preserve actual authorship of in-place changes. For v5, a separate Sol session may review Sol-authored output; never use the author session. Historical tasks retain their frozen same-family rule. L1 uses deterministic verification; substantive L2/L3 gates require the correct independent reviewer and main acceptance. Astra never implements, mutates artifacts, publishes or accepts. Do not create Terra content/desktop/QA proxies for new work.

Historical tasks keep their exact profile, role, prompt, sources and permissions. Configuration does not hot-switch a running model. Actual UI operations still require supported tools, the UI skill, actual runtime identity and the exclusive task lease in `routing/main_ui.py`; record owned-resource cleanup separately from client-control state.

For Luna/high and Astra/high, use the standing global authorization `native-workers-standing-inheritance-2026-11-10`. The named native child inherits existing parent permissions within its role and the current workspace without a separate inheritance confirmation. Astra remains read-only, with its existing admission and material boundary. Use the owning chat current workspace for new v5 handoff records.

For ordinary new v5 work, bind the owning chat current workspace and edit, test, review, and correct the same authorized project files. Do not create a candidate workspace or copy changes into place after review. Do not require a general review of finished historical tasks as a new-task step. Retain exact-request idempotency, overlapping write checks, active ownership, same-work uncertainty protection, and frozen historical evidence. Apply historical contract checks when handling that historical task or a relevant unresolved conflict.

## Historical claim-bound handoff

For a native worker task that requires project-local records, use `.codex/handoffs/<actual-main-session-id>/<task-name>/`. The routing workflow creates the directory when it needs to write task records. Keep the shared ledger and frozen source packages in their owning runtime, and refer to them by stable IDs and hashes. Do not store credentials or claim tokens in project records.

When recovering a historical managed native claim, supply `project_root` to `prepare_subscription_dispatch`. Astra, Sol execution, Sol QA and Luna return the frozen acknowledgement in chat, without tools, then stop. The parent validates the actual first completed turn and exact native identity, writes the receipt and activation files under the session's task directory, then uses the activation's exact `resume_message` to resume the same child. The literal v1 receipt is retired for new handoffs. Its verifier applies only to already frozen v1 records.

For historical Sol execution, Sol QA and Luna claims that still require preparation, use the plaintext file named by `handoff_protocol.sol_plaintext_activation_path`. The owning parent activates the same child and verifies that `activation.json` contains the plaintext continuation and frozen input reference. Pass the entire `resume_message` returned by activation to `followup_task` verbatim, including `RW-RESUME`, the space, and the per-claim challenge. Keep task content in the file. The host may wrap the wake signal. The child echoes the complete signal verbatim in its first commentary, reads `activation.json` as its first tool action, then reads the complete frozen input and required originals. The parent verifies the actual read and execution trace before collecting the result. Preserve older frozen protocols and the rule-bound or system-read-only evidence required by each QA contract; do not describe rule-bound QA as OS isolation.

For historical Astra tasks frozen with `astra_fallback_transport=parent_subagent_review_v1`, the actual owning main chat directly spawns `astra_review_subscription` after atomic claim and preparation. Use the same managed acknowledgement, first commentary echo and exact activation-file read described above. The prompt limits the review to reading supplied frozen files, and the Hook and collector verify the allowed read-only operations. The child inherits its parent's permissions. Record the actual child and trace, `permission_boundary=inherits_parent`, and `os_isolation_claimed=false`. Apply the frozen formal controller contract and its focused collection proof. Earlier frozen Astra tasks and public system-read-only qualification retain their carrier, host-bound wake and actual system isolation checks. Preserve any frozen historical API authorization and credit evidence for lookup and accounting. The retired route cannot submit or retry API work.

For architecture validation, test the installed global runtime from the normal Codex home with the existing Hooks and new public test tasks. A separate Codex home or separate Hook trust ceremony is not required. Preserve the role-specific permissions, actual Hook evidence and independent review requirements.

Use the existing shared ledger. Freeze the nine parent_context fields documented in `routing/README.md`, decisive wording/provenance, full required originals, source/prompt/package hashes, requirements coverage, output contract and acceptance. Missing necessary context blocks dispatch; do not silently truncate. Changed evidence requires a new immutable revision after reconciling the prior execution.

For new v5 Astra analysis and planning, apply the installed four-condition admission policy; the parent decides whether existing work should be reused. Historical frozen reviews retain their original lookup rules. Additional review needs a material source change or a recorded unresolved substantive question and renewed decision value, scope and budget. It is not an automatic final-delivery ritual or reciprocal review loop.

## Historical execution and fallback

New Astra analysis and planning use built-in dispatch. The frozen collection procedure applies only to historical formal reviews. Preserve the recorded ownership and evidence boundaries.

Previously frozen API and native candidate contracts retain their execution and evidence boundaries. For new Sol implementation, pass the authorized workspace and output scope to the built-in child, then verify edits and checks in place.

Eligible API failure or budget insufficiency is required for tasks frozen on the API-first fallback route. Accepted direct-native routes have no API-first attempt. Maintenance shutdown, disabled configuration, unknown execution, refusal, permission denial and quality rejection are not fallback permission. Atomically claim once; execution tasks require the service's receipt-first transport, its exact spawn_message, fork_turns=none and the fixed role/model/high effort. Observe the frozen acknowledgement or receipt, actual lineage and activation before substantive work. Main then inspects actual native tools, immutable originals and collected artifact hashes before completion. Do not substitute a generic agent or standalone CLI session for the named native route.

Other eligible content/QA fallbacks retain their frozen named roles and contracts. Historical native Sol QA with the frozen `review_rules_v1` boundary inherits host permissions and requires the exact rule-checked read/view transcript and package binding before controller acceptance. Record that evidence without claiming system read-only isolation. Historical formal Astra follows its frozen rule-bound review and focused evidence requirements. Historical tasks retain their frozen read-only evidence requirements. No worker recursively dispatches or applies another worker's returned code automatically.

## Accounting and recovery

Keep the approved per API task caps: Luna USD0.20, Sol execution USD2.50, Sol QA USD1.00 and Astra USD3.50; legacy Terra USD0.50 only for frozen compatibility. One owning API task includes all of its model/tool rounds. Controller api_usd is a per-attempt limit, propagated into that frozen task; explicit parent-authorized rework creates a separate attempt. Keep per_task_only and no new cumulative workflow-dollar cap, top-up or reset. Current role policy v3: Astra review 128000 input / 32768 output / 1 round / USD 3.50; Sol QA 256000 / 16384 / 1 / USD 1.00; Sol execution 256000 / 16384 / 3 / USD 2.50; Luna batch 512000 / 16384 / 1 / USD 0.20. Input is complete per request; output includes reasoning and tool calls. Reserve the full output at the actual input tier, including Luna long-context pricing above 272000. Retain lower caller caps and historical frozen authorization. Packages lacking provable historical limits fail closed. No input truncation or automatic unknown-result retries. The scalar 128000 field is legacy metadata. Native subscription usage and cost are separate and may remain unknown.

Host limits and resource exclusivity apply. Preserve historical claim ownership and reconcile uncertain work. Use finish_interaction_task only for an eligible unknown historical API result. Preserve local execution evidence and unresolved provider accounting. The retired API route cannot enqueue retries.

Controller events remain Observe-only and do not generate, open UI or accept. Read status/inbox manually. Worker completion, deterministic validation, independent review, main acceptance and publication are distinct. Verify fresh-client loading and actual Hook callbacks separately; offline tests and enabled flags are not live interception evidence.

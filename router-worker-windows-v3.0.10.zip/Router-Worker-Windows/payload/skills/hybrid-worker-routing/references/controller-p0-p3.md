# Controller-managed P0-P3 work

Read CODEX_HOME/integrations/hybrid-api-workers/orchestrator-control/RUNBOOK.md. The controller owns task versions, snapshots, validation, independent QA, main acceptance, publication and events. The existing API ledger still owns generation, frozen sources, budget, admission/dedup and exact fallback.

New tasks freeze architecture_profile=terra_main_v2; historical profiles remain unchanged. L1 requires actual deterministic checks; L2/L3 require independent Sol/high QA, API-first exact subscription fallback. Same-family Terra review cannot satisfy it. The historical CLI/receipt field sol_decision_ref means the current primary coordinator's evidence in v2; it is retained for compatibility, not a claim that Sol is the main.

Status/inbox MCP is read-only. Observe events do not call models, open UI, change source files or wake the original chat. Pick up pending continuations manually. Six trusted Hook definitions remain unchanged; short source guards do not establish universal client coverage. New main UI needs observed root Terra/high and an exclusive task lease. Report missing UI tools, target software, independent QA isolation or real cases as NOT_RUN/BLOCKED; offline mocks never establish live model/UI/domain behavior.

"""Pin a parent to native routing after a confirmed provider credit rejection."""
import json
import re
import time

CREDIT_ERROR = 'credit_balance_exhausted'
SESSION_NATIVE_REASON = 'api_credit_exhausted_session_native'


def session_key(parent):
    return 'api_credit_exhausted_v1:' + parent


def pinned_native_receipt(db, parent):
    row = db.execute('SELECT value FROM control WHERE key=?', (session_key(parent),)).fetchone()
    return json.loads(row[0]) if row else None


def confirmed_credit_receipt(receipt):
    if not isinstance(receipt,dict) or receipt.get('reason')!=CREDIT_ERROR or receipt.get('route')!='subscription':
        return False
    if receipt.get('http_status')==429:
        return receipt.get('endpoint') in ('responses','responses/input_tokens')
    return (receipt.get('confirmation')=='terminal_response' and receipt.get('response_status')=='failed'
            and isinstance(receipt.get('response_id'),str)
            and re.fullmatch(r'resp_[A-Za-z0-9_]{1,160}',receipt['response_id']) is not None)


def is_terminal_credit_failure(response):
    if not isinstance(response, dict) or response.get('status') != 'failed':
        return False
    error = response.get('error')
    response_id = response.get('id')
    return (isinstance(error, dict) and error.get('code') == CREDIT_ERROR
            and isinstance(response_id, str) and re.fullmatch(r'resp_[A-Za-z0-9_]{1,160}', response_id) is not None)


def record_terminal_rejection(db, task, response):
    """Pin on an exact failed response received or retrieved from the provider."""
    if not is_terminal_credit_failure(response):
        raise ValueError('Provider response does not establish a terminal credit failure.')
    receipt = {'version': 1, 'route': 'subscription', 'reason': CREDIT_ERROR,
               'observed_at': time.time(), 'confirmation': 'terminal_response',
               'endpoint': 'responses', 'response_status': 'failed',
               'response_id': response['id'], 'task_id': task['id'],
               'attempt': task.get('api_attempt', 1)}
    return pin(db, task['parent_session_id'], receipt)


def record_rejection(db, task, request_id, *, endpoint, round_number=None):
    """Call only for an observed HTTP 429 with the exact provider credit code."""
    receipt = {'version': 1, 'route': 'subscription', 'reason': CREDIT_ERROR,
               'observed_at': time.time(), 'http_status': 429, 'endpoint': endpoint,
               'task_id': task['id'], 'attempt': task.get('api_attempt', 1)}
    if round_number is not None:
        receipt['round'] = round_number
    if isinstance(request_id, str) and re.fullmatch(r'[A-Za-z0-9_.:-]{1,160}', request_id):
        receipt['provider_request_id'] = request_id
    return pin(db, task['parent_session_id'], receipt)


def pin(db, parent, receipt):
    db.execute('INSERT INTO control(key,value) VALUES(?,?) ON CONFLICT(key) DO NOTHING',
               (session_key(parent), json.dumps(receipt)))
    return receipt

"""Tool-aware Responses adapter candidate; credentials remain in the existing adapter."""
import json
import urllib.error
if __package__:
    from .sol_execution_loop import ProviderRejected
else:
    from sol_execution_loop import ProviderRejected

ELIGIBLE_REJECTIONS={'credit_balance_exhausted','organization_spend_limit_exceeded','project_spend_limit_exceeded',
                     'organization_usage_limit_exceeded','rate_limit_exceeded','model_not_found'}


class ToolAwareAdapter:
    def __init__(self, openai_adapter, *, attempt=1):
        self.adapter=openai_adapter
        self.attempt=attempt

    def count(self,payload):
        keys=('model','instructions','input','tools','parallel_tool_calls')
        try:
            value,_=self.adapter.post('responses/input_tokens',{key:payload[key] for key in keys if key in payload})
        except urllib.error.HTTPError as error:
            rejection=self.rejection(error)
            if rejection and rejection.code=='credit_balance_exhausted':
                raise rejection from None
            raise
        count=value.get('input_tokens')
        if type(count) is not int or count < 0:
            raise ValueError('Provider input token count unavailable')
        return count

    def run_round(self,payload,task_id,number,on_progress):
        attempt_suffix='' if self.attempt==1 else f'-a{self.attempt}'
        client_request_id=f'hybrid-{task_id}{attempt_suffix}-r{number}'
        return self.run(payload,client_request_id=client_request_id,on_progress=on_progress)

    def run(self,payload,*,client_request_id=None,on_progress=None):
        # The existing SSE handler tracks a single response id. Until per-round
        # streaming has its own durable transport, use one foreground response.
        wire=dict(payload);wire['stream']=False
        try:
            if hasattr(self.adapter,'post_request'):
                return self.adapter.post_request('responses',wire,client_request_id=client_request_id,
                                                 on_progress=on_progress)
            return self.adapter.post('responses',wire)
        except urllib.error.HTTPError as error:
            rejection=self.rejection(error)
            if rejection:
                raise rejection from None
            raise

    @staticmethod
    def rejection(error):
        if error.code not in (404,429):
            return None
        try:
            code=json.loads(error.read(65536)).get('error',{}).get('code')
        except (ValueError,OSError,AttributeError):
            return None
        if (isinstance(code,str) and code in ELIGIBLE_REJECTIONS
                and (code!='credit_balance_exhausted' or error.code==429)):
            return ProviderRejected(code,error.headers.get('x-request-id') if error.headers else None,error.code)
        return None

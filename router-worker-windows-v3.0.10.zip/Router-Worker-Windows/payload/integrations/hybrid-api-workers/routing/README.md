# Router–Worker Hook

See [the active dispatch rules](../RUNBOOK.md). The installed Hook registration points to `hook_chain.py`, which combines the routing guard and Controller bridge. Keep the registered commands and user-controlled trust intact. The guard checks supported host events and role identity; it is not OS isolation and does not prove task acceptance.

For new work, use the named built-in child and the `direct_` task name prefix. Match actual dispatch audits to the owning root, tool name, call ID, and input hash. Separately verify child lineage, actual role and result. The rolling audit in `state/routing-audit.sqlite3` stores metadata and hashes without raw prompts. Historical claims retain their frozen evidence and original transport checks; they are not templates for new dispatch.

## Main UI lease

New main UI uses no worker handoff. Before UI use, verify actual root identity and acquire the exclusive task lease (ordinary file operation; not a UI action):

```powershell
python -X utf8 -B <service>/routing/main_ui.py acquire --thread <actual-main-id> --scope <scope.json>
python -X utf8 -B <service>/routing/main_ui.py check --thread <actual-main-id>
python -X utf8 -B <service>/routing/main_ui.py release --thread <actual-main-id> --lease <returned-id> --closeout <closeout.json>
```

Scope JSON requires objective, authorized_scope, user_request_provenance and acceptance_criteria. Closeout JSON requires outcome (completed|blocked|cancelled|handoff), existing absolute evidence_references, owned_resources and client_control_state. Unknown client release remains unknown; closing the local lease never fabricates release. Another main owner, scope change or unresolved legacy grant blocks acquisition until explicit reconciliation; time does not transfer ownership. Apply supported UI tool protocols and authorization for the exact target. Existing six trusted Hook definitions are unchanged; controlled main UI requires verified metadata plus its lease. Ordinary root file work and connectors stay main-owned.


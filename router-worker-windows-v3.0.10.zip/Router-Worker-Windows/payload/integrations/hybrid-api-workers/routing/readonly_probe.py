"""Parent-authored native qualification probe on one disposable target."""
import hashlib
import json
from pathlib import Path
import sys


def main():
    source, target = (Path(value) for value in sys.argv[1:])
    if (not source.is_absolute() or source.suffix != '.txt' or not target.is_absolute()
            or target.name != 'child-write-canary.txt' or target.exists() or target.is_symlink()):
        raise SystemExit('Unexpected public fixture paths')
    raw = source.read_bytes()
    proof = {'read_value':raw.decode('utf-8').strip(),'sha256':hashlib.sha256(raw).hexdigest(),
             'target':str(target)}
    try:
        with target.open('xb') as stream:
            stream.write(b'Unexpected canary write')
    except PermissionError as error:
        proof.update(write_denied=True,error=type(error).__name__,errno=error.errno)
    else:
        proof['write_denied']=False
    print(json.dumps(proof,ensure_ascii=True))
    return 0 if proof['write_denied'] else 2


if __name__=='__main__':
    raise SystemExit(main())

"""Merge owned user-level hooks/instructions; exact fixed backups and rollback."""
import argparse
from copy import deepcopy
import hashlib
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
START = "<!-- BEGIN HYBRID_ROUTING_OWNERSHIP_V1 -->"
END = "<!-- END HYBRID_ROUTING_OWNERSHIP_V1 -->"
MATCHER = "(?i)(^Agent$|spawn_agent$|mcp__.*(cua_repl|node_repl|browser|computer|hybrid_api_workers).*|^(functions[.])?exec$)"
PUBLIC_UI_MATCHER = "(?i)^(?:mcp__codex_app__)?(?:open_in_codex|navigate_to_codex_page)$"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write(path, data):
    if path.is_symlink():
        raise ValueError("Refusing a symlink target.")
    temporary = path.with_name(path.name + ".routing-new")
    if temporary.exists():
        raise ValueError("Unreconciled installation temporary file exists.")
    try:
        temporary.write_bytes(data)
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def hook_groups(root=ROOT, python=sys.executable):
    command = '"' + str(Path(python).resolve()) + '" -B "' + str(root / "guard.py") + '"'
    result = {}
    for event in ("SessionStart", "PreToolUse", "PostToolUse"):
        handler = {"type": "command", "command": command, "timeout": 8,
                   "statusMessage": "Hybrid routing ownership check"}
        if os.name == "nt":
            # Session hooks inherit the Windows environment's PowerShell.
            # A quoted executable is a string expression without its call operator.
            handler["commandWindows"] = "& " + command.replace('" -B ', '" -X utf8 -B ', 1)
        result[event] = [{"matcher": "startup|resume|clear|compact|fork" if event == "SessionStart" else MATCHER,
                          "hooks": [handler]}]
        if event != "SessionStart":
            result[event].append({"matcher": PUBLIC_UI_MATCHER, "hooks": [deepcopy(handler)]})
    return result


def extend_public_ui_hooks(home, root=ROOT):
    """Append narrowly scoped handlers; preserve original definitions/trust.

    New definitions still require the product's user review. This function does
    not edit config.toml, trusted hashes, enabled flags or global instructions.
    """
    path = Path(home) / "hooks.json"
    before = path.read_bytes()
    config = json.loads(before)
    updated = deepcopy(config)
    guard_path = str((Path(root) / "guard.py").resolve()).replace("\\", "/").casefold()
    for event in ("PreToolUse", "PostToolUse"):
        groups = updated.get("hooks", {}).get(event, [])
        existing = [g for g in groups if g.get("matcher") == PUBLIC_UI_MATCHER]
        originals = [g for g in groups if g.get("matcher") != PUBLIC_UI_MATCHER and any(guard_path in str(h.get("command", "")).replace("\\", "/").casefold() for h in g.get("hooks", []))]
        if len(originals) != 1 or len(originals[0].get("hooks", [])) != 1:
            raise ValueError("Expected one unambiguous existing routing handler per tool event.")
        desired = {"matcher": PUBLIC_UI_MATCHER, "hooks": deepcopy(originals[0]["hooks"])}
        if existing:
            if existing != [desired]:
                raise ValueError("Existing public UI hook differs; preserve and reconcile it.")
        else:
            groups.append(desired)
    after = (json.dumps(updated, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    if updated == config:
        return {"changed": False, "original_definitions_preserved": True}
    backup = path.with_name(path.name + ".bak")
    write(backup, before)
    if backup.read_bytes() != before:
        raise ValueError("Hook backup read-back failed.")
    write(path, after)
    return {"changed": True, "original_definitions_preserved": True,
            "new_handler_count": 2, "new_matcher": PUBLIC_UI_MATCHER,
            "before_sha256": sha(before), "after_sha256": sha(after),
            "trust_changed": False, "status": "PENDING_USER_TRUST_FOR_NEW_HANDLERS"}


def install(home, root=ROOT, python=sys.executable):
    home = home.resolve()
    agents = home / "AGENTS.md"
    hooks = home / "hooks.json"
    record_path = root / "routing-deployment.json"
    if not agents.is_file() or not (home / "config.toml").is_file():
        raise ValueError("Expected existing local Codex configuration.")
    for path in (agents, hooks):
        if path.is_symlink() or (path.exists() and not path.is_file()):
            raise ValueError("Refusing a linked or non-file global target.")
    before_agents = agents.read_bytes()
    original = before_agents.decode("utf-8")
    addendum = (root / "global-addendum.md").read_text(encoding="utf-8").rstrip()
    if START in original or END in original:
        if original.count(START) != 1 or original.count(END) != 1:
            raise ValueError("Managed instruction markers are ambiguous.")
        start, end = original.index(START), original.index(END) + len(END)
        updated = original[:start] + addendum + original[end:]
    else:
        updated = original.rstrip() + "\n\n" + addendum + "\n"
    if len(updated.encode()) > 32768:
        raise ValueError("Global guidance exceeds the default discovery byte cap.")
    previous_hooks = hooks.read_bytes() if hooks.exists() else None
    config = json.loads(previous_hooks) if previous_hooks is not None else {"hooks": {}}
    if not isinstance(config.get("hooks", {}), dict):
        raise ValueError("Existing hooks shape is unsupported.")
    config = deepcopy(config)
    events = config.setdefault("hooks", {})
    groups = hook_groups(root, python)
    command = groups["PreToolUse"][0]["hooks"][0]["command"]
    for event, owned in groups.items():
        existing = events.get(event, [])
        retained = []
        for group in existing:
            group = deepcopy(group)
            group["hooks"] = [h for h in group.get("hooks", []) if h.get("command") != command]
            if group["hooks"]:
                retained.append(group)
        events[event] = retained + owned
    after = {agents: updated.encode("utf-8"), hooks: (json.dumps(config, ensure_ascii=False, indent=2) + "\n").encode()}
    previous = {agents: before_agents, hooks: previous_hooks}
    if record_path.exists():
        record = json.loads(record_path.read_text(encoding="utf-8"))
        if all(path.exists() and path.read_bytes() == content for path, content in after.items()):
            return {**record, "idempotent_no_change": True}
        for entry in record["owned_globals"]:
            path = Path(entry["path"])
            if not path.is_file() or sha(path.read_bytes()) != entry["installed_sha256"]:
                raise ValueError("Global file changed since routing installation; reconcile before updating.")
    record = {"status": "INSTALLED_PENDING_USER_HOOK_TRUST", "owned_globals": [], "hook_events": list(groups), "root_config_changed": False,
              "api_credentials_or_budgets_changed": False, "trust_bypass_used": False,
              "legacy_uninstall": "Historical whole-file ownership may report conflicts. Restore this scoped upgrade first; preserve unrelated app configuration drift."}
    for path, data in after.items():
        old = previous[path]
        if old == data:
            continue
        backup = path.with_name(path.name + ".bak")
        if old is not None:
            write(backup, old)
            if backup.read_bytes() != old:
                raise ValueError("Backup verification failed before mutation.")
        record["owned_globals"].append({"path": str(path), "existed_before": old is not None, "backup_path": str(backup) if old is not None else None,
                                        "previous_sha256": sha(old) if old is not None else None, "installed_sha256": sha(data)})
    changed = []
    try:
        for path, data in after.items():
            if path.read_bytes() == data if path.exists() else False:
                continue
            write(path, data)
            changed.append(path)
        write(record_path, (json.dumps(record, ensure_ascii=False, indent=2) + "\n").encode())
    except Exception:
        for path in reversed(changed):
            old = previous[path]
            if old is None:
                path.unlink()
            else:
                write(path, old)
        raise
    return record


def rollback(root=ROOT, apply=False):
    record_path = root / "routing-deployment.json"
    record = json.loads(record_path.read_text(encoding="utf-8"))
    conflicts = []
    for entry in record["owned_globals"]:
        path = Path(entry["path"])
        if not path.is_file() or path.is_symlink() or sha(path.read_bytes()) != entry["installed_sha256"]:
            conflicts.append(str(path))
        if entry["existed_before"]:
            backup = Path(entry["backup_path"])
            if not backup.is_file() or backup.is_symlink() or sha(backup.read_bytes()) != entry["previous_sha256"]:
                conflicts.append(str(backup))
    result = {"safe_to_restore": not conflicts, "conflicts": conflicts, "applied": False, "scope": "Routing upgrade user hooks and instruction addendum only; service, credentials, budgets and source remain"}
    if apply and not conflicts:
        for entry in reversed(record["owned_globals"]):
            path = Path(entry["path"])
            if entry["existed_before"]:
                write(path, Path(entry["backup_path"]).read_bytes())
            else:
                path.unlink()
        result["applied"] = True
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("operation", choices=("install", "rollback", "extend-public-ui"))
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()
    if args.operation == "install":
        result = install(Path.home() / ".codex")
    elif args.operation == "extend-public-ui":
        result = extend_public_ui_hooks(Path.home() / ".codex")
    else:
        result = rollback(apply=args.apply)
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()

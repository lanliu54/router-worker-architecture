"""Serialize the authorized qualification cutover with Worker admission."""
import argparse
from contextlib import closing
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import sys
import tempfile
import time

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import architecture_policy


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def verify_completed_samples(db, root, grant):
    for role,request in grant['requests'].items():
        row=db.execute('SELECT data FROM tasks WHERE request_id=?',(request,)).fetchone()
        task=json.loads(row[0]) if row else {}
        native=task.get('native_dispatch') or {}
        if (task.get('parent_session_id')!=grant['parent_session_id'] or task.get('role')!=role
                or task.get('status')!='completed' or task.get('reason')!='native_direct'
                or task.get('dispatch_mode')!='subscription_direct' or task.get('route')!='subscription'
                or task.get('reserved_micro_usd')!=0 or task.get('charged_micro_usd')!=0
                or task.get('api_dispatch_started_at') or task.get('delivery_receipt',{}).get('route')=='api'
                or native.get('phase')!='completed' or not native.get('child_id')):
            raise ValueError('No completed eligible direct sample for '+role)
        package=Path(task['package_path'])
        expected=root/'state/packages'/task['id']/'context-package.json'
        if package.resolve()!=expected.resolve() or package.is_symlink():
            raise ValueError('Direct sample package path is unexpected.')
        value=json.loads(package.read_bytes())
        body={k:v for k,v in value.items() if k!='integrity'}
        actual=sha(json.dumps(body,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8'))
        if (value['task'].get('dispatch_mode')!='subscription_direct'
                or not actual==value['integrity']['package_sha256']==task['package_hash']):
            raise ValueError('Direct sample package binding is invalid.')


def replace_policy(root, proposed_bytes, *, expected_sha256, actor, action, evidence_task=None):
    """Check and replace policy under the same SQLite write lock as submit_task."""
    root=Path(root).resolve()
    policy_path=root/'architecture-policy.json'
    proposed=architecture_policy.validate(json.loads(proposed_bytes))
    database=root/'state/tasks.sqlite3'
    with closing(sqlite3.connect(database.as_uri()+'?mode=rw',uri=True,timeout=20,isolation_level=None)) as db:
        db.execute('BEGIN IMMEDIATE')
        try:
            if policy_path.is_symlink() or sha(policy_path.read_bytes())!=expected_sha256:
                raise ValueError('The active policy changed since preflight.')
            current=architecture_policy.load(root)
            if action in ('astra-enable','astra-disable'):
                field='astra_readonly_api_first'
                release_fields={field,'version'}
                if {k:v for k,v in current.items() if k not in release_fields}!={k:v for k,v in proposed.items() if k not in release_fields}:
                    raise ValueError('Astra release cannot change unrelated policy fields.')
                if current.get('astra_readonly_qualification') or proposed.get('astra_readonly_qualification'):
                    raise ValueError('Close the public qualification before changing the release policy.')
                if action=='astra-enable':
                    if current.get('version')!=3 or proposed.get('version')!=4 or current.get(field) or proposed.get(field) is not True or not evidence_task:
                        raise ValueError('Astra release requires a new enable and a completed direct qualification task.')
                    row=db.execute('SELECT data FROM tasks WHERE id=?',(evidence_task,)).fetchone()
                    task=json.loads(row[0]) if row else {}
                    native=task.get('native_dispatch') or {}
                    evidence=task.get('native_evidence') or {}
                    evidence_path=Path(native.get('handoff_path','')).parent/'readonly-isolation-evidence.json'
                    if (not architecture_policy.astra_direct_task(task) or task.get('status')!='completed'
                            or task.get('parent_session_id')!=actor or task.get('api_dispatch_started_at')
                            or task.get('reserved_micro_usd')!=0 or task.get('charged_micro_usd')!=0
                            or native.get('phase')!='completed' or (native.get('resume_dispatch') or {}).get('plaintext_first_read_version')!=2
                            or evidence.get('reviewed_artifacts_read_only_verified') is not True
                            or evidence.get('isolation_evidence_ref')!=str(evidence_path)
                            or evidence_path.is_symlink() or not evidence_path.is_file()):
                        raise ValueError('The recorded task is not eligible read-only direct qualification evidence.')
                    proof=json.loads(evidence_path.read_bytes())
                    if (proof.get('owner_session_id')!=actor or proof.get('package_sha256')!=task['package_hash']
                            or proof.get('child_identity',{}).get('id')!=native.get('child_id')
                            or (proof.get('actual_probe') or {}).get('observed',{}).get('write_denied') is not True):
                        raise ValueError('Qualification proof must bind the actual write denial, owner and child.')
                elif current.get('version')!=4 or proposed.get('version')!=3 or not current.get(field) or proposed.get(field):
                    raise ValueError('Astra rollback must restore the prior coordinator schema and remove only the release flag.')
            elif action in ('astra-start','astra-stop'):
                field='astra_readonly_qualification'
                if {k:v for k,v in current.items() if k!=field}!={k:v for k,v in proposed.items() if k!=field}:
                    raise ValueError('Astra qualification cannot change unrelated policy fields.')
                active=current.get(field)
                grant=proposed.get(field)
                if action=='astra-start':
                    if (active or not grant or grant['parent_session_id']!=actor
                            or not 0<grant['expires_at_epoch']-time.time()<=1800):
                        raise ValueError('Astra qualification must be new, owned and limited to 30 minutes.')
                    if db.execute('SELECT 1 FROM tasks WHERE request_id=?',(grant['request_id'],)).fetchone():
                        raise ValueError('The Astra qualification request already exists.')
                    if db.execute("SELECT 1 FROM tasks WHERE parent=? AND status='fallback_claimed'",(actor,)).fetchone():
                        raise ValueError('The owner already holds a native claim; reconcile it before qualification.')
                elif not active or active['parent_session_id']!=actor or grant:
                    raise ValueError('Only the owning session can close this Astra qualification.')
            else:
                allowed={'version','release_status','native_direct_roles','native_direct_qualification',
                         'new_api_roles','independent_qa','technical_implementation'}
                if any(current.get(k)!=proposed.get(k) for k in (current.keys()|proposed.keys())-allowed):
                    raise ValueError('Qualification transition includes unrelated policy changes.')
                if (set(current.get('new_api_roles',[]))-architecture_policy.NATIVE_DIRECT_ROLES
                        != set(proposed.get('new_api_roles',[]))-architecture_policy.NATIVE_DIRECT_ROLES):
                    raise ValueError('Qualification cannot change unrelated API roles.')
                for field,route_key in (('independent_qa','route'),('technical_implementation','new_task_route')):
                    old={k:v for k,v in current.get(field,{}).items() if k!=route_key}
                    new={k:v for k,v in proposed.get(field,{}).items() if k!=route_key}
                    if old!=new:
                        raise ValueError('Qualification cannot change existing role permissions or limits.')
                active=current.get('native_direct_qualification')
                grant=proposed.get('native_direct_qualification')
                if action=='start':
                    if (current['version']!=2 or current.get('native_direct_roles') or not grant
                            or grant['parent_session_id']!=actor or grant['expires_at_epoch']<=time.time()):
                        raise ValueError('The authorized qualification start state does not match.')
                    for request in grant['requests'].values():
                        if db.execute('SELECT 1 FROM tasks WHERE request_id=?',(request,)).fetchone():
                            raise ValueError('A qualification request already exists; preserve its frozen state.')
                elif action=='accept':
                    if (not active or active['parent_session_id']!=actor or proposed['version']!=3
                            or proposed.get('release_status')!='parent_accepted' or grant
                            or active['expires_at_epoch']<=time.time()):
                        raise ValueError('The authorized qualification acceptance state does not match.')
                    verify_completed_samples(db,root,active)
                elif action=='rollback':
                    if not active or active['parent_session_id']!=actor or proposed['version']!=2 or proposed.get('native_direct_roles'):
                        raise ValueError('The authorized qualification rollback state does not match.')
                else:
                    raise ValueError('Unknown policy transition.')
            if action not in ('rollback','astra-stop','astra-disable'):
                maintenance=root/'maintenance.json'
                if maintenance.exists() and json.loads(maintenance.read_bytes()).get('enabled') is not False:
                    raise ValueError('Maintenance is active; qualification cannot start or be accepted.')
                if db.execute("SELECT 1 FROM tasks WHERE status IN ('queued','preparing','api_running','unknown_execution','validation_ready') LIMIT 1").fetchone():
                    raise ValueError('An API task is active, queued or uncertain; reconcile before changing policy.')
            temp=None
            try:
                with tempfile.NamedTemporaryFile(dir=root,prefix='.direct-policy-',delete=False) as stream:
                    temp=Path(stream.name)
                    stream.write(proposed_bytes)
                    stream.flush()
                    os.fsync(stream.fileno())
                os.replace(temp,policy_path)
            finally:
                if temp is not None:
                    temp.unlink(missing_ok=True)
            db.commit()
        except BaseException:
            db.rollback()
            raise
    return {'action':action,'policy_sha256':sha(proposed_bytes),'release_status':proposed.get('release_status')}


def main():
    from desktop_dispatch import runtime_identity
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action',choices=('start','accept','rollback','astra-start','astra-stop','astra-enable','astra-disable'))
    parser.add_argument('--evidence-task')
    parser.add_argument('--from-file',type=Path,required=True)
    parser.add_argument('--expect-sha256',required=True)
    args=parser.parse_args()
    actor=os.environ.get('CODEX_THREAD_ID')
    if not actor or not architecture_policy.is_primary(runtime_identity(actor,ROOT.parents[1]),
                                                        architecture_policy.load(ROOT)):
        raise ValueError('Only the actual owning Terra/high root may switch qualification policy.')
    print(json.dumps(replace_policy(ROOT,args.from_file.read_bytes(),expected_sha256=args.expect_sha256,
                                    actor=actor,action=args.action,evidence_task=args.evidence_task)))


if __name__=='__main__':
    main()

"""Serve only the owned static browser fixture on an ephemeral loopback port."""
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import json

handler = partial(SimpleHTTPRequestHandler, directory=str(Path(__file__).resolve().parent))
server = ThreadingHTTPServer(("127.0.0.1", 0), handler)
print(json.dumps({"fixture_url": f"http://127.0.0.1:{server.server_port}/browser-qa.html"}), flush=True)
try:
    server.serve_forever()
except KeyboardInterrupt:
    pass
finally:
    server.server_close()

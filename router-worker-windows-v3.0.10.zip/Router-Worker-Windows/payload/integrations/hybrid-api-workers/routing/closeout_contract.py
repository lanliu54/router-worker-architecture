"""Separate explicit API applicability, automatic resources and local authority.

Schema validation does not establish that cited evidence is true: parent
acceptance must inspect the actual tool/runtime records before finishing.
"""
import hashlib
import json
from pathlib import Path

POLICY_PATH=Path(__file__).resolve().parent/'profiles/client-closeout-v1.json'


def policy():
    return json.loads(POLICY_PATH.read_text(encoding='utf-8'))


def contract_descriptor():
    p=policy()
    return {'version':1,'policy_id':p['policy_id'],
            'policy_sha256':hashlib.sha256(POLICY_PATH.read_bytes()).hexdigest(),
            'explicit_release':'not_applicable_current_public_api',
            'required_separate_records':['explicit_release','automatic_resources','full_client_state'],
            'local_authorization_close':'computed_from_actual_state_transition'}


def nonempty(value):
    return isinstance(value,str) and bool(value.strip())


def validate_client_closeout(cleanup,descriptor=None):
    p=policy()
    if descriptor is not None:
        current=contract_descriptor()
        if descriptor.get('policy_id')!=current['policy_id'] or descriptor.get('policy_sha256')!=current['policy_sha256']:
            raise ValueError('Frozen closeout policy changed; reassess the package before acceptance.')
    if 'local_authorization_close' in cleanup:
        raise ValueError('Local authorization closure is computed by the state machine, not supplied by the caller.')
    if cleanup.get('client_control_state_exit')=='verified' or any(cleanup.get(k) is True for k in ['full_client_release_verified','explicit_client_control_release_verified']):
        raise ValueError('Current public API does not support a verified explicit/full-client release claim.')
    record=cleanup.get('client_closeout')
    if not isinstance(record,dict) or record.get('policy_id')!=p['policy_id']:
        raise ValueError('Supply the current client_closeout contract with three separate records.')
    explicit=record.get('explicit_release',{})
    if explicit.get('status') not in ['not_applicable','needs_reassessment'] or not nonempty(explicit.get('interface_scope')) or not isinstance(explicit.get('evidence'),list) or not explicit['evidence'] or not all(nonempty(x) for x in explicit['evidence']):
        raise ValueError('Explicit release requires scoped interface evidence and an applicable status.')
    if explicit['status']=='not_applicable' and explicit.get('reason')!='not_exposed_current_public_api':
        raise ValueError('N/A explicit release must identify current public API non-exposure.')
    if explicit['status']=='needs_reassessment' and not nonempty(explicit.get('reason')):
        raise ValueError('Explain changed interface exposure without claiming a release passed.')
    automatic=record.get('automatic_resources',{})
    if automatic.get('status') not in p['automatic_resources']['statuses']:
        raise ValueError('Record automatic resource recovery independently.')
    if automatic['status']=='observed':
        before=automatic.get('before',{});boundary=automatic.get('turn_boundary',{});after=automatic.get('after',{})
        if not nonempty(before.get('resource_id')) or not nonempty(before.get('binding_id')) or before.get('binding_id')!=after.get('binding_id') or not nonempty(before.get('reference')) or not nonempty(boundary.get('reference')) or not nonempty(after.get('reference')) or after.get('resource_absent') is not True or automatic.get('no_manual_close_mark_reset_or_navigation_between') is not True:
            raise ValueError('Observed automatic cleanup needs before/boundary/after evidence without intervening manual cleanup.')
    elif not nonempty(automatic.get('reason')):
        raise ValueError('Explain untested, absent or unknown automatic recovery; manual closure alone is not automatic proof.')
    full=record.get('full_client_state',{})
    normal=full.get('status')=='not_observable' and full.get('reason')=='no_public_release_status_getter'
    changed=explicit['status']=='needs_reassessment' and full.get('status')=='needs_reassessment' and nonempty(full.get('reason'))
    if not (normal or changed):
        raise ValueError('Hidden full client release cannot be promoted to verified without a public state interface.')
    return {'contract_version':1,'policy_id':p['policy_id'],'explicit_release_status':explicit['status'],
            'automatic_resources_status':automatic['status'],'full_client_state_status':full['status'],
            'records_separated':True,'evidence_validation':'Parent must verify actual cited records; schema checks alone are not proof.'}

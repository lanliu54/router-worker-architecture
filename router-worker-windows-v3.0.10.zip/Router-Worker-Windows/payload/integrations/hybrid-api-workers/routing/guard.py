"""Local routing guard. No network, credentials, UI input or inference.

This is a guardrail for supported hook paths, not a security boundary or a
semantic task classifier. Raw hook arguments and results are never logged.
"""
import hashlib
from contextlib import closing
import json
from pathlib import Path
import re
import sqlite3
import sys
import time
import tomllib

from desktop_dispatch import DispatchStore
import task_contract
from host_context import (identity as host_identity, is_astra_host, normal_path,
                          public_ui_call, readonly, wrapped_events)

ROOT = Path(__file__).resolve().parent
HOME = ROOT.parent.parent.parent if ROOT.name == "routing" else Path.home() / ".codex"
sys.path.insert(0,str(ROOT.parent))
import architecture_policy
ROLES = {
    "sol_execution_subscription": ("gpt-6.1-sol", "high"),
    "sol_qa_subscription": ("gpt-6.1-sol", "high"),
    "terra_desktop_native": ("gpt-6.1-terra", "medium"),
    "luna_batch_subscription": ("gpt-6-luna", "high"),
    "astra_review_subscription": ("gpt-6-astra", "high"),
}
KINDS = {"api_luna_batch": "batch_extraction", "api_astra_review": "substantive_review", "api_sol_qa":"independent_qa", "api_sol_execution":"technical_implementation"}
MANAGED_RESUME_ROLES = {'sol_execution_subscription','sol_qa_subscription','luna_batch_subscription'}
PARENT_FIELDS = ("task_relevant_background", "research_or_project_positioning", "relevant_user_requirements_with_verbatim_wording_and_provenance", "confirmed_decisions", "later_corrections_and_superseded_decisions", "approved_terminology", "constraints_and_immutable_items", "current_work_state", "known_unknowns_and_conflicts")
REMINDER = "Routing: Sol retains scope decisions, tightly coupled implementation, integration and final acceptance. Delegate bounded extraction to Luna, content production to Terra, and admitted substantive review to Astra. Only terra_desktop_native may operate browser/app UI. Use independent context and the full handoff contract in routing/README.md. Never silently take over a blocked worker's UI task."
PRIMARY_REMINDER = "Routing v2: the actual primary gpt-6.1-terra/high root retains intent, routing, UI, vision, writing, implementation, integration and final acceptance. Keep ordinary work in the main session. Use Luna/high API-first only for bounded batch work; independent Sol/high API-first workers with exact subscription fallback for non-author QA; Astra/high only after existing admission/dedup/budget gates. Do not dispatch new Terra content/desktop workers or use Terra to independently QA Terra output. Main UI requires its exclusive task lease and actual runtime identity; a config edit never changes this running session's model or higher-priority permissions. Use full frozen independent worker context and same-model fallback."
MANDATORY_REMINDER = (
    "For explicit user requests to maintain Router–Worker itself, the main session may inspect, edit "
    "and locally validate the installed architecture directly. Edit the installed source, then verify "
    "fresh-client behavior after the user restarts. Keep managed task ownership, frozen evidence, "
    "permissions, budgets and uncertain execution intact. For ordinary managed tasks, use the exact "
    "assigned roles and their claim, continuation and acceptance rules."
)

def digest(value):
    data = value if isinstance(value, bytes) else json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(data).hexdigest()


def identity(event, home=HOME):
    return host_identity(event, home)


def ui_call(tool, args):
    name = tool.lower()
    if public_ui_call(name):
        return True
    if any(token in name for token in ("cua_repl", "computer_use", "computer-use")):
        return True
    if "browser" in name and "hybrid_api_workers" not in name:
        return True
    if "node_repl" in name:
        code = str(args.get("code", ""))
        # Deliberately narrow, documented signature recognition. Arbitrary
        # JavaScript and aliases cannot be completely classified with regex.
        return bool(re.search(r"\b(?:sky|cua)\b|@oai/sky|browser-service|\.playwright\b|\.dom_cua\b|\.(?:getBrowser|createBrowserTab|getTab|launch_app|get_window_state|activate_window)\s*\(", code))
    return False


def route_record(record, owner, kind):
    if not isinstance(record, dict):
        raise ValueError("Supply routing_decision with owner, work_kind, reason and bounded_scope.")
    accepted_kinds = (kind,) if isinstance(kind, str) else kind
    if record.get("owner") != owner or record.get("work_kind") not in accepted_kinds:
        raise ValueError("Task type and assigned worker disagree; main-session work must not be delegated.")
    if not all(isinstance(record.get(k), str) and record[k].strip() for k in ("reason", "bounded_scope")):
        raise ValueError("Explain the task boundary and delegation reason.")


def desktop_handoff(message):
    try:
        data = json.loads(message)
    except (ValueError, TypeError):
        raise ValueError("Desktop dispatch requires the complete JSON handoff described in routing/README.md.") from None
    if not isinstance(data, dict):
        raise ValueError("Desktop handoff must be a JSON object.")
    route_record(data.get("routing_decision"), "terra_desktop_native", "desktop_operation")
    for key in ("objective", "package_id"):
        if not isinstance(data.get(key), str) or not data[key].strip():
            raise ValueError("Desktop handoff requires a nonempty string: " + key + ".")
    for key in ("authorized_scope", "deliverables", "acceptance_criteria"):
        value = data.get(key)
        if not isinstance(value, list) or not value or not all(isinstance(x, str) and x.strip() for x in value):
            raise ValueError("Desktop handoff requires a nonempty string list: " + key + ".")
    if type(data.get("version")) is not int or data["version"] < 1:
        raise ValueError("Desktop handoff version must be a positive integer.")
    background = data.get("parent_context", {})
    if not isinstance(background, dict) or not all(isinstance(background.get(k), str) and background[k].strip() for k in PARENT_FIELDS):
        raise ValueError("Desktop handoff requires all nine parent_context fields; preserve decisive user wording and provenance.")
    own = data.get("ui_ownership", {})
    if own.get("owner") != "terra_desktop_native" or own.get("parent_must_not_operate") is not True:
        raise ValueError("Assign exclusive desktop ownership to native Terra.")
    return data


def fallback_claim(home, who, target, message, task_name=None):
    from content_dispatch import native_parent_rows
    path = home / "integrations/hybrid-api-workers/state/tasks.sqlite3"
    with readonly(path) as db:
        rows = native_parent_rows(db,who['id'])
    matching = []
    staged = False
    unprepared = False
    for row in rows:
        task = json.loads(row[1])
        if task.get("native_role") != target:
            continue
        if task.get('native_dispatch'):
            staged = True
            continue
        if task.get('role')=='api_sol_execution' or task.get('requires_readonly_ack') or task.get('requires_chat_ack'):
            unprepared = True
            continue
        pinned = Path(task["native_input_path"])
        expected = "Use independent context. Read the complete UTF-8 JSON file at " + str(pinned) + ". Apply canonical_role_prompt and context_package as supplied. Read/view every required frozen original listed there, including binary images/PDFs, before substantive work. Return the specified JSON output and exact package hash. If essential context is missing, return missing_context. Do not recursively delegate, run generated code, edit originals or fetch unrelated sources. The parent integrates the result."
        if message == expected and digest(pinned.read_bytes()) == task["native_input_sha256"]:
            matching.append(task)
    if staged:
        from content_dispatch import ContentDispatch
        ContentDispatch(home / 'integrations/hybrid-api-workers').admit(who['id'],target,task_name,message)
        return
    if unprepared:
        raise ValueError('Native execution requires prepared receipt-first transport before spawning.')
    if len(matching) != 1:
        raise ValueError("No unique active same-version subscription fallback claim matches this exact dispatch. Submit/claim through hybrid_api_workers first.")


def historical_operation(home,who,args,policy,*,spawn=False):
    """Only an already-frozen task can survive a coordinator model migration."""
    path=home/'integrations/hybrid-api-workers/state/tasks.sqlite3'
    if not path.is_file():return False
    with readonly(path) as db:
        rows=db.execute('SELECT data FROM tasks WHERE parent=?',(who['id'],)).fetchall()
    for row in rows:
        task=json.loads(row[0])
        if task.get('created_at',float('inf'))>=policy['effective_at_epoch']:continue
        if spawn:
            if task.get('status')=='fallback_claimed' and task.get('native_role')==args.get('agent_type'):return True
        elif task.get('id')==args.get('task_id'):return True
    return False


def verify_followup(home, who, args, policy):
    """Only a verified parent can send the bound continuation to an active child."""
    from content_dispatch import ContentDispatch,native_parent_rows,verify_plaintext_activation
    from desktop_dispatch import runtime_identity
    from receipt_order import native_turn_ids, verify_readonly_ack, verify_system_readonly
    root=home/'integrations/hybrid-api-workers'
    dispatch=ContentDispatch(root)
    dispatch.require_not_maintenance()
    if who.get('is_child') or who.get('role'):
        raise ValueError('Only the owning root may continue a managed native child.')
    with readonly(root/'state/tasks.sqlite3') as db:
        rows=native_parent_rows(db,who['id'])
    matches=[]
    for row in rows:
        task=json.loads(row[1])
        record=task.get('native_dispatch',{})
        child=record.get('child_id')
        name=record.get('task_name')
        if not child or not name or args.get('target') not in (child,name,'/root/'+name):
            continue
        if record.get('phase')!='active' or record.get('receipt_order',{}).get('passed') is not True:
            continue
        if policy and not architecture_policy.is_primary(who,policy) and not task['created_at']<policy['effective_at_epoch']:
            continue
        message=args.get('message')
        opaque=isinstance(message,str) and re.fullmatch(r'gAAAA[A-Za-z0-9_=-]{1,131072}',message)
        if not record.get('resume_message') or (message!=record['resume_message'] and not opaque):
            continue
        with readonly(root/'state/tasks.sqlite3') as db:
            if dispatch.task(db,task['id'])!=task:
                continue
        frozen=dispatch.frozen(task)
        protocol=frozen['handoff_protocol']
        if protocol.get('sol_plaintext_activation_path'):
            verify_plaintext_activation(record)
        if protocol.get('astra_plaintext_activation_path'):
            verify_plaintext_activation(record,'astra_plaintext_activation_sha256')
        astra_echo=(protocol.get('opaque_resume_echo') is True or protocol.get('astra_readonly_resume') is True)
        managed_echo=(protocol.get('sol_resume_echo') is True or protocol.get('managed_resume_echo') is True)
        echo_required=astra_echo or managed_echo
        if opaque and not echo_required:
            continue
        observed=runtime_identity(child,home)
        expected={'id':child,'parent_id':who['id'],'task_name':name,'role':task['native_role'],
                  'model':frozen['model'],'effort':frozen['reasoning_effort'],'is_child':True}
        if all(observed.get(key)==value for key,value in expected.items()):
            matches.append((task,astra_echo,managed_echo,protocol))
    if len(matches)!=1:
        raise ValueError('Follow-up needs a unique active child and the exact parent-approved resume message.')
    task,astra_echo,managed_echo,protocol=matches[0]
    if astra_echo or managed_echo:
        record=task['native_dispatch']
        if managed_echo:
            eligible_roles = MANAGED_RESUME_ROLES
            if (architecture_policy.astra_parent_fallback(task)
                    and protocol.get('astra_fallback_transport') == architecture_policy.ASTRA_PARENT_FALLBACK):
                eligible_roles = {'astra_review_subscription'}
        else:
            eligible_roles = {'astra_review_subscription'}
        if (astra_echo and managed_echo) or task['native_role'] not in eligible_roles or record.get('resume_dispatch'):
            raise ValueError('Native resume grant has already been used or is invalid.')
        child=record['child_id']
        if managed_echo:
            verify_readonly_ack(child,protocol['acknowledgement'],home)
            turns=native_turn_ids(child,home)
        else:
            turns=verify_system_readonly(child,home)['turn_ids']
        if len(turns)!=1:
            raise ValueError('Only the completed acknowledgement may precede the first resume.')
        with dispatch.transaction() as db:
            current=dispatch.task(db,task['id'])
            if current!=task:
                raise ValueError('Active resume claim changed concurrently.')
            current['native_dispatch']['resume_dispatch']={
                'transport':'opaque' if opaque else 'plaintext',
                'envelope_sha256':hashlib.sha256(message.encode()).hexdigest(),
            }
            if managed_echo:
                current['native_dispatch']['resume_dispatch']['ack_turn_id']=turns[0]
            if protocol.get('astra_plaintext_activation_path'):
                current['native_dispatch']['resume_dispatch']['plaintext_activation']={
                    'handoff_path':record['handoff_path'],
                    'astra_plaintext_activation_sha256':record['astra_plaintext_activation_sha256'],
                }
            if protocol.get('sol_plaintext_activation_path'):
                current['native_dispatch']['resume_dispatch']['plaintext_activation']={
                    'handoff_path':record['handoff_path'],
                    'sol_plaintext_activation_sha256':record['sol_plaintext_activation_sha256'],
                }
            if protocol.get('plaintext_first_read_version') in (1,2):
                current['native_dispatch']['resume_dispatch']['plaintext_first_read_version']=protocol['plaintext_first_read_version']
            if protocol.get('astra_readonly_resume') is True:
                current['native_dispatch']['resume_dispatch'].update(
                    ack_turn_id=turns[0], recipient='/root/'+record['task_name'])
            dispatch.save(db,current)


def verify_managed_native_tool(who, home, event=None, *, require_claim=False):
    """Check the frozen native continuation before a local tool executes."""
    from content_dispatch import ContentDispatch, native_parent_rows, verify_plaintext_activation
    from receipt_order import verify_sol_resume_echo
    dispatch=ContentDispatch(home/'integrations/hybrid-api-workers')
    if not dispatch.dbpath.is_file() and who['role']!='sol_execution_subscription' and not require_claim:
        return
    with readonly(dispatch.dbpath) as db:
        matches=[]
        for tid,raw in native_parent_rows(db,who['parent_id']):
            task=json.loads(raw)
            record=task.get('native_dispatch',{})
            if (task.get('native_role')==who['role'] and record.get('task_name')==who['task_name']):
                task=dispatch.task(db,tid)
                matches.append((task,record,dispatch.frozen(task)))
        if not matches and who['role']!='sol_execution_subscription' and not require_claim:
            managed=db.execute("SELECT 1 FROM tasks WHERE parent=? AND "
                "(json_extract(data,'$.dispatch_mode')='subscription_direct' OR "
                "json_extract(data,'$.requires_managed_resume_ack')=1) AND "
                "json_extract(data,'$.native_dispatch.child_id')=? LIMIT 1",(who['parent_id'],who['id'])).fetchone()
            if not managed:
                return
    if len(matches)!=1:
        raise ValueError('Native worker has no unique frozen execution claim.')
    task,record,frozen=matches[0]
    protocol=frozen['handoff_protocol']
    if protocol.get('sol_resume_echo') is not True and protocol.get('managed_resume_echo') is not True:
        return
    dispatch.require_not_maintenance()
    if (record.get('phase')!='active' or record.get('child_id')!=who['id']
            or record.get('receipt_order',{}).get('passed') is not True
            or (who['model'],who['effort'])!=(frozen['model'],frozen['reasoning_effort'])
            or not record.get('resume_dispatch')):
        raise ValueError('Native tools require their active one-time continuation.')
    if protocol.get('sol_plaintext_activation_path'):
        verify_plaintext_activation(record)
    direct_sol_execution = (task.get('dispatch_mode') == 'subscription_direct'
                            and who['role'] == 'sol_execution_subscription')
    verify_sol_resume_echo(who['id'], record['resume_message'], record['resume_dispatch'], home,
                           allow_pending_read=True, allow_parent_messages=direct_sol_execution)
    if protocol.get('native_qa_boundary')=='review_rules_v1':
        from sol_qa_rules import permitted_operation
        package=json.loads(Path(task['native_input_path']).read_text(encoding='utf-8'))['context_package']
        permitted_operation(event['tool_name'],event.get('tool_input'),task,package)


def verify_astra_shell(event, who, home):
    """Permit a bounded read-only shell operation only after verified resume delivery."""
    from content_dispatch import ContentDispatch,native_parent_rows
    from receipt_order import verify_resume_echo
    root=home/'integrations/hybrid-api-workers'
    dispatch=ContentDispatch(root)
    dispatch.require_not_maintenance()
    with readonly(dispatch.dbpath) as db:
        rows=native_parent_rows(db,who['parent_id'])
        parent_bound = [json.loads(raw) for _, raw in rows]
    direct = [task for task in parent_bound if architecture_policy.astra_parent_fallback(task)
              and task.get('native_dispatch', {}).get('task_name') == who['task_name']]
    if direct:
        if len(direct) != 1:
            raise ValueError('Astra has no unique direct review claim.')
        task = direct[0]
        protocol = dispatch.frozen(task)['handoff_protocol']
        if (task.get('native_dispatch', {}).get('child_id') != who['id']
                or protocol.get('astra_fallback_transport') != architecture_policy.ASTRA_PARENT_FALLBACK
                or protocol.get('native_qa_boundary') != 'review_rules_v1'
                or protocol.get('managed_resume_echo') is not True):
            raise ValueError('Astra parent review is not bound to this active child and review rules.')
        verify_managed_native_tool(who,home,event,require_claim=True)
        return
    tool=event.get('tool_name','').rsplit('.',1)[-1]
    args=event.get('tool_input')
    if tool=='exec':
        code=args if isinstance(args,str) else args.get('code','') if isinstance(args,dict) else ''
        match=re.fullmatch(r'\s*text\(await tools\.exec_command\((\{[\s\S]*\})\)\);?\s*',code)
        if not match:
            raise ValueError('Native Astra may use only a single literal sandboxed shell call.')
        args=json.loads(match[1])
        tool='exec_command'
    shell_keys={'cmd','command','description','workdir','timeout_ms','max_output_tokens','yield_time_ms','shell','login'}
    if (tool not in ('Bash','shell_command','exec_command') or not isinstance(args,dict)
            or not set(args).issubset(shell_keys) or not (args.get('cmd') or args.get('command'))):
        raise ValueError('Native Astra is limited to the local sandboxed shell without overrides.')
    with readonly(dispatch.dbpath) as db:
        rows=native_parent_rows(db,who['parent_id'])
        matches=[]
        for tid,data in rows:
            row=json.loads(data)
            record=row.get('native_dispatch',{})
            if (record.get('child_id')==who['id'] and record.get('phase')=='active'
                    and record.get('resume_dispatch') and row.get('native_role')==who['role']):
                task=dispatch.task(db,tid)
                protocol=dispatch.frozen(task)['handoff_protocol']
                if protocol.get('opaque_resume_echo') is True or protocol.get('astra_readonly_resume') is True:
                    matches.append(record)
    if len(matches)!=1:
        raise ValueError('Native Astra has no unique active read-only resume grant.')
    record=matches[0]
    verify_resume_echo(who['id'],record['resume_message'],record['resume_dispatch'],home,allow_pending_read=True)


def verify_spawn_config(home,target,args):
    conf=tomllib.loads((home/'agents'/(target+'.toml')).read_text(encoding='utf-8'))
    expected=ROLES[target]
    if (conf.get('model'),conf.get('model_reasoning_effort'))!=expected:
        raise ValueError('The installed native role model/effort differs from the fixed route.')
    if args.get('model',expected[0])!=expected[0] or args.get('reasoning_effort',expected[1])!=expected[1]:
        raise ValueError('An explicit spawn override changes the fixed model or effort.')


def verify_task_owner(home,who,args):
    """Bind MCP mutations to the actual host-observed caller, not an argument."""
    if 'parent_session_id' in args and args['parent_session_id']!=who['id']:
        raise ValueError('Task mutation requires the actual owning parent.')
    ledger=home/'integrations/hybrid-api-workers/state/tasks.sqlite3'
    with readonly(ledger) as db:
        row=db.execute('SELECT parent,data FROM tasks WHERE id=?',(args.get('task_id'),)).fetchone()
    if not row or row[0]!=who['id'] or json.loads(row[1]).get('parent_session_id')!=who['id']:
        raise ValueError('Task mutation requires the actual owning parent.')


def decide_astra_host(event,who,home):
    from receipt_order import verify_system_readonly
    try:
        verify_system_readonly(who['id'],home)
        policy=architecture_policy.load(home/'integrations/hybrid-api-workers')
        if not architecture_policy.is_primary(who,policy):
            raise ValueError('Readonly carrier must use the configured coordinator model and effort.')
        tool=event.get('tool_name','')
        args=event.get('tool_input',{})
        if tool.endswith('spawn_agent') and args.get('agent_type')=='astra_review_subscription' and args.get('fork_turns')=='none':
            verify_spawn_config(home,args['agent_type'],args)
            fallback_claim(home,who,args['agent_type'],args.get('message'),args.get('task_name'))
        elif tool.endswith('followup_task'):
            verify_followup(home,who,args,policy)
        elif tool.endswith('wait_agent'):
            return 'allow','Bound carrier may wait for its only native child.'
        else:
            raise ValueError('Readonly carrier only transports the bound Astra claim.')
    except (ValueError,OSError,sqlite3.Error,TypeError,KeyError) as exc:
        return 'deny',str(exc) if isinstance(exc,ValueError) else 'Readonly carrier validation failed.'
    return 'allow','Readonly carrier and exact Astra claim verified.'


def host_spawn_name(name):
    return isinstance(name, str) and re.fullmatch(r'direct_[a-z0-9_]{1,57}', name) is not None


def host_spawn_child(who, home):
    if not who or not who.get('is_child') or not host_spawn_name(who.get('task_name')):
        return False
    role = who.get('role')
    if role not in MANAGED_RESUME_ROLES | {'astra_review_subscription'}:
        return False
    policy = architecture_policy.load(home/'integrations/hybrid-api-workers') or {}
    return bool(policy.get('host_spawn_effective_at_epoch') and who.get('parent_id')
                and (who.get('model'), who.get('effort')) == ROLES[role])


def decide(event, who, home=HOME):
    try:
        direct_child = host_spawn_child(who, home)
    except (ValueError, OSError, KeyError, TypeError):
        return 'deny', 'The native dispatch policy is unavailable.'
    if who and who.get('role') in MANAGED_RESUME_ROLES and not direct_child:
        try:
            verify_managed_native_tool(who,home,event)
        except (ValueError,OSError,sqlite3.Error,KeyError,TypeError):
            return 'deny','Native tools require the exact bound continuation and first commentary echo.'
    if who and who.get('role')=='astra_review_subscription' and not direct_child:
        try:
            verify_astra_shell(event,who,home)
        except (ValueError,OSError,sqlite3.Error,KeyError,TypeError) as exc:
            return 'deny',str(exc) if isinstance(exc,ValueError) else 'Native Astra read-only gate is unavailable.'
        return 'allow','Verified read-only native Astra resume and bounded shell call.'
    if is_astra_host(who,home):
        return decide_astra_host(event,who,home)
    nested, error = wrapped_events(event)
    if nested is not None:
        if error:
            return "deny", error
        for child in nested:
            decision, reason = decide(child, who, home)
            if decision == "deny":
                return decision, reason
        return "allow", "Inspectable nested calls checked; ordinary JavaScript remains parent-owned."
    tool = event.get("tool_name", "")
    args = event.get("tool_input", {})
    if not isinstance(args, dict):
        return "deny", "Unsupported controlled-tool input layout."
    ui = ui_call(tool, args)
    spawn = tool == "Agent" or tool.endswith("spawn_agent")
    followup = tool.endswith("followup_task")
    hybrid = "hybrid_api_workers" in tool
    if not (ui or spawn or followup or hybrid):
        return "allow", "Outside the controlled routing paths."
    if not who:
        return "deny", "Execution identity is unavailable; reconcile native metadata before controlled work."
    try:
        policy=architecture_policy.load(home/'integrations/hybrid-api-workers')
    except (ValueError,OSError):
        return 'deny','Active coordinator policy is invalid; no controlled work.'
    if ui:
        if policy:
            if architecture_policy.is_primary(who,policy):
                try:
                    from main_ui import MainUIStore
                    MainUIStore(home/'integrations/hybrid-api-workers').check(who)
                except (ValueError,OSError,sqlite3.Error) as exc:
                    return 'deny',str(exc) if isinstance(exc,ValueError) else 'Main UI lease is unavailable.'
                return 'allow','Verified primary Terra/high root with its exclusive task UI lease.'
            # An existing active v1 grant may finish cleanup; no new worker is admitted.
            if who['role']=='terra_desktop_native' and (who['model'],who['effort'])==ROLES['terra_desktop_native']:
                row=DispatchStore(home/'integrations/hybrid-api-workers/routing').find(who.get('parent_id'),who.get('task_name'))
                if row and row['phase']=='active' and row['created_at']<policy['effective_at_epoch'] and row['child_id']==who['id']:
                    return 'allow','Historical active desktop grant may finish its frozen scope only.'
            return 'deny','UI belongs to the actual primary Terra/high root; content/QA/desktop children and other root models cannot take over.'
        if who["role"] == "terra_desktop_native" and (who["model"], who["effort"]) == ROLES["terra_desktop_native"]:
            try:
                DispatchStore(home / "integrations/hybrid-api-workers/routing").check_ui(who)
            except (ValueError, OSError, sqlite3.Error) as exc:
                return "deny", str(exc) if isinstance(exc, ValueError) else "Desktop grant coordination is unavailable."
            return "allow", "Verified exclusive desktop role."
        return "deny", "Browser/app UI must be delegated to terra_desktop_native (Terra/medium); parent and content workers retain no UI ownership."
    if who["is_child"] or who["role"]:
        return "deny", "Workers must not recursively delegate or call hybrid_api_workers. Return the result to the parent."
    if hybrid and tool.endswith(('claim_subscription_fallback','prepare_subscription_dispatch',
                                 'complete_subscription_fallback','cancel_task',
                                 'finish_interaction_task','retry_interaction_task')):
        try:
            verify_task_owner(home,who,args)
        except (ValueError,OSError,sqlite3.Error,KeyError,TypeError):
            return 'deny','Task mutation requires the actual owning parent.'
    if followup:
        if (policy or {}).get('host_spawn_effective_at_epoch'):
            from desktop_dispatch import runtime_identity
            try:
                target = args.get('target')
                child = runtime_identity(target, home) if isinstance(target, str) else None
            except (ValueError, OSError, sqlite3.Error, KeyError, TypeError):
                child = None
            if host_spawn_child(child, home):
                if child['parent_id'] != who['id'] or not architecture_policy.is_primary(who, policy):
                    return 'deny', 'Only the owning primary root may follow up with its native child.'
                return 'allow', 'Owning root and native child verified.'
        try:
            verify_followup(home,who,args,policy)
        except (ValueError,OSError,sqlite3.Error,KeyError,TypeError):
            return "deny","Follow-up needs a unique active child and the exact parent-approved resume message."
        return "allow","Active native continuation and parent ownership verified."
    if policy and not architecture_policy.is_primary(who,policy):
        readonly_operation=hybrid and any(tool.endswith(name) for name in ('get_task','get_usage'))
        from qa_validation import operation
        canary=hybrid and operation(home/'integrations/hybrid-api-workers',who,tool,args)
        recovery=hybrid and any(tool.endswith(name) for name in ('cancel_task','complete_subscription_fallback','claim_subscription_fallback','prepare_subscription_dispatch'))
        if not (readonly_operation or canary or (recovery or spawn) and historical_operation(home,who,args,policy,spawn=spawn)):
            return 'deny','New controlled dispatch requires the actual Terra/high coordinator; refresh the session, do not claim a model switch.'
    if spawn:
        target = args.get("agent_type")
        if target=='terra_content_subscription' or (policy and target=='terra_desktop_native'):
            return 'deny','New Terra agents are retired in Terra-main mode; main handles UI/vision/writing and independent Sol handles QA.'
        if target not in ROLES or args.get("fork_turns") != "none":
            return "deny", "Use a named managed role with fork_turns=none; do not fork parent history or select a generic replacement."
        try:
            verify_spawn_config(home,target,args)
            if (policy or {}).get('host_spawn_effective_at_epoch') and host_spawn_name(args.get('task_name')):
                from content_dispatch import ContentDispatch
                ContentDispatch(home/'integrations/hybrid-api-workers').require_not_maintenance()
                if not architecture_policy.is_primary(who, policy):
                    raise ValueError('Direct subscription dispatch requires the primary Terra/high root.')
                if not isinstance(args.get('message'), str) or not args['message'].strip():
                    raise ValueError('Supply the independent task in the spawn message.')
                return 'allow', 'Built-in Codex subscription dispatch with the named role.'
            if target == "terra_desktop_native":
                ledger = home / "integrations/hybrid-api-workers/state/tasks.sqlite3"
                with readonly(ledger) as db:
                    active = db.execute("SELECT 1 FROM tasks WHERE parent=? AND status='fallback_claimed' LIMIT 1", (who["id"],)).fetchone()
                if active:
                    raise ValueError("The parent native slot is reserved by a subscription fallback; reconcile before desktop dispatch.")
                store = DispatchStore(home / "integrations/hybrid-api-workers/routing")
                staged = store.find(who["id"], args.get("task_name"))
                if staged:
                    store.admit_spawn(who["id"], args.get("task_name"), args.get("message"), desktop_handoff)
                else:
                    try:
                        handoff = desktop_handoff(args.get("message"))
                    except ValueError as exc:
                        if isinstance(args.get("message"), str) and args["message"].startswith("gAAAA"):
                            raise ValueError("The host supplied an opaque desktop message. Prepare a frozen complete handoff with routing/desktop_dispatch.py; receipt and runtime identity must be verified before UI activation. Do not retry or decrypt the envelope.") from None
                        raise exc
                    if handoff.get("handoff_protocol"):
                        raise ValueError("Staged desktop handoff has no matching prepared dispatch.")
            else:
                if DispatchStore(home / "integrations/hybrid-api-workers/routing").has_open(who["id"]):
                    raise ValueError("The parent native slot is reserved by a staged desktop dispatch; reconcile before subscription fallback.")
                fallback_claim(home, who, target, args.get("message"), args.get('task_name'))
        except (ValueError, OSError, sqlite3.Error, KeyError, TypeError) as exc:
            return "deny", str(exc) if isinstance(exc, ValueError) else "Native route metadata/claim is unavailable; reconcile before dispatch."
        return "allow", "Named independent worker handoff and fixed route verified."
    if tool.endswith("claim_subscription_fallback"):
        try:
            if DispatchStore(home / "integrations/hybrid-api-workers/routing").has_open(who["id"]):
                return "deny", "The parent native slot is reserved by a staged desktop dispatch; do not claim a second native worker."
        except (OSError, sqlite3.Error):
            return "deny", "Native slot coordination is unavailable; reconcile before fallback claim."
    if tool.endswith("submit_task"):
        role = args.get("role")
        try:
            if role=='api_sol_execution' and (not policy or policy.get('profile') not in ('mandatory_delegation_v3','simplified_workflow_v5')):
                raise ValueError('Sol execution requires an admitted mandatory routing profile.')
            if role not in KINDS:
                raise ValueError("Unknown managed API content role.")
            if args.get("parent_session_id") != who["id"]:
                raise ValueError("Submission parent_session_id does not match the actual parent thread.")
            kind = KINDS[role]
            if policy and policy.get('profile') == 'simplified_workflow_v5':
                kind = {'api_luna_batch': ('batch_extraction', 'routine_fixed_process'),
                        'api_astra_review': ('substantive_analysis', 'planning')}.get(role, kind)
                # The Worker verifies the exact prior controller binding before
                # admitting an old formal Astra QA task under its frozen profile.
                if role == 'api_astra_review' and isinstance(args.get('context', {}).get('qa_binding'), dict):
                    kind += ('substantive_review',)
            route_record(args.get("context", {}).get("routing_decision"), role, kind)
            task_contract.validate(args.get("context", {}), role)
        except (ValueError, AttributeError) as exc:
            return "deny", str(exc)
    return "allow", "Parent-owned hybrid operation; service retains context, Astra, budget and claim validation."


def audit(event, who, decision, reason, root=ROOT):
    """Store safe metadata only; cap the rolling table at 5000 records."""
    directory = root / "state"
    directory.mkdir(exist_ok=True)
    with closing(sqlite3.connect(directory / "routing-audit.sqlite3", timeout=1.5)) as db, db:
        db.execute("CREATE TABLE IF NOT EXISTS events (id INTEGER PRIMARY KEY, observed_at REAL, event TEXT, thread_id TEXT, role TEXT, model TEXT, tool TEXT, tool_use_id TEXT, input_hash TEXT, decision TEXT, reason_code TEXT)")
        db.execute("INSERT INTO events(observed_at,event,thread_id,role,model,tool,tool_use_id,input_hash,decision,reason_code) VALUES(?,?,?,?,?,?,?,?,?,?)", (time.time(), event.get("hook_event_name", ""), who.get("id", "") if who else "", who.get("role", "") if who else "", event.get("model", ""), event.get("tool_name", ""), event.get("tool_use_id", ""), digest(event.get("tool_input", {})), decision, "routing_denial" if decision == "deny" else "routing_observation"))
        db.execute("DELETE FROM events WHERE id NOT IN (SELECT id FROM events ORDER BY id DESC LIMIT 5000)")


def handle(event, home=HOME, root=ROOT):
    kind = event.get("hook_event_name")
    if kind == "SessionStart":
        try:current=architecture_policy.load(home/'integrations/hybrid-api-workers')
        except (ValueError,OSError):return {'systemMessage':'Coordinator policy unavailable; do not perform controlled work.'}
        if current and current.get('host_spawn_effective_at_epoch'):
            reminder = (
                'Router-Worker v3.0.10: the Terra/high root owns scope, UI and acceptance. '
                'New managed work uses built-in spawn_agent with the exact named subscription role, '
                'fork_turns=none, a direct_ task name and independent task context. '
                'Use the route only when supported by the host and the current authorization. '
                'Claims, activation, receipts and API accounting apply to frozen historical tasks. '
                'The Worker API route is retired. The Controller observes. '
                'Main-session local maintenance remains available when the user authorizes it.'
            )
            return {"hookSpecificOutput": {"hookEventName": kind, "additionalContext": reminder}}
        reminder=MANDATORY_REMINDER if current and current.get('profile') in ('mandatory_delegation_v3','simplified_workflow_v5') else PRIMARY_REMINDER if current else REMINDER
        if current and current.get('native_direct_qualification'):
            reminder += (' A direct-native qualification window is active only for its bound owner and exact '
                         'predeclared public requests. Other listed-role submissions are blocked. '
                         'Do not describe this window as general release acceptance.')
        elif current and current.get('native_direct_roles'):
            reminder += (' The actual Terra/high coordinator owns scope, UI, integration and acceptance. '
                      'The owning ledger routes new managed roles listed in native_direct_roles directly to '
                      'their named native worker. Claim, acknowledge, activate and verify the one-use '
                      'continuation. Preserve v4 Sol authorization, read-only independent QA, Astra admission, '
                      'and all frozen historical and uncertain work.')
        if current and current.get('new_api_roles') == []:
            reminder += (' The Worker API route is retired. Send new Astra analysis directly to '
                         'astra_review_subscription without an API attempt or credit check.')
        return {"hookSpecificOutput": {"hookEventName": kind, "additionalContext": reminder}}
    if kind not in ("PreToolUse", "PostToolUse"):
        return {}
    tool = event.get("tool_name", "")
    args = event.get("tool_input", {})
    nested, wrapper_error = wrapped_events(event)
    controlled = bool(wrapper_error or nested) if nested is not None else isinstance(args, dict) and (ui_call(tool, args) or tool == "Agent" or tool.endswith(("spawn_agent","followup_task")) or "hybrid_api_workers" in tool)
    astra_model=event.get('model')=='gpt-6-astra'
    managed_model=event.get('model') in ('gpt-6.1-sol','gpt-6-luna')
    carrier_model=event.get('model')=='gpt-6.1-terra'
    if not controlled and not (astra_model or managed_model or carrier_model):
        return {}
    who = None
    try:
        who = identity(event, home)
    except (OSError, ValueError, KeyError, sqlite3.Error, TypeError):
        pass
    if (astra_model or managed_model) and who is None and kind=='PreToolUse':
        return {'hookSpecificOutput':{'hookEventName':kind,'permissionDecision':'deny',
                                      'permissionDecisionReason':'Actual native-capable tool identity is unavailable.'}}
    managed_child=who and who.get('role') in MANAGED_RESUME_ROLES
    if not controlled and not astra_model and not managed_child and not is_astra_host(who,home):
        return {}
    if kind == "PostToolUse":
        try:
            audit(event, who, "observed", "", root)
        except (OSError, sqlite3.Error):
            return {"hookSpecificOutput": {"hookEventName": kind, "additionalContext": "Routing audit could not be saved. Report that evidence gap; do not claim full execution verification."}}
        return {}
    decision, reason = decide(event, who, home)
    try:
        audit(event, who, decision, reason, root)
    except (OSError, sqlite3.Error):
        decision, reason = "deny", "Routing coordination/audit is unavailable; reconcile before controlled execution."
    if decision == "deny":
        return {"hookSpecificOutput": {"hookEventName": kind, "permissionDecision": "deny", "permissionDecisionReason": reason}}
    return {}


def main():
    try:
        event = json.load(sys.stdin)
        result = handle(event)
    except Exception:
        # An error/timeout in a hook can fail open in the host. Emit a valid
        # explicit denial whenever this process can still answer a PreToolUse.
        result = {"hookSpecificOutput": {"hookEventName": "PreToolUse", "permissionDecision": "deny", "permissionDecisionReason": "Routing guard could not validate this call. Reconcile local routing metadata before continuing."}}
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()

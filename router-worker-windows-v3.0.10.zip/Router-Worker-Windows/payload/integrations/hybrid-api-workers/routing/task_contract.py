"""Optional task-scoped assignment contracts; no global semantic classifier."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def normalization_batches(specimen_rows, max_output_tokens=8192,
                          reasoning_reserve=4096, tokens_per_row=48,
                          metadata_reserve=768):
    """Conservative output planning; never reduce the fixed model or effort.

    These are explicit estimates, not provider token counts. Keep complete
    required originals in every frozen package and bound only the output rows.
    Submit serially under the shared one-active-Luna role limit.
    """
    if any(not isinstance(x, int) or isinstance(x, bool) or x <= 0
           for x in [max_output_tokens, reasoning_reserve, tokens_per_row, metadata_reserve]):
        raise ValueError("Output-planning bounds must be positive integers.")
    capacity = (max_output_tokens - reasoning_reserve - metadata_reserve) // tokens_per_row
    if capacity < 1:
        raise ValueError("Output bound cannot fit one normalized row plus declared reserves.")
    batches = []
    for specimen, count in specimen_rows.items():
        if not isinstance(count, int) or isinstance(count, bool) or count < 1:
            raise ValueError("Every specimen must have a positive observed source-row count.")
        for start in range(0, count, capacity):
            end = min(count, start + capacity)
            batches.append({"specimen": specimen, "source_row_start_zero_based": start,
                            "source_row_end_exclusive": end, "expected_rows": end - start,
                            "estimated_output_tokens": (end - start) * tokens_per_row + metadata_reserve,
                            "reasoning_reserve_tokens": reasoning_reserve,
                            "input_policy": "full_required_originals_unchanged",
                            "acceptance": "actual_normalized_rows_required_not_audit_only"})
    return {"estimate_only": True, "serial_role": "api_luna_batch", "fixed_model": "gpt-6-luna",
            "fixed_effort": "high", "batches": batches, "total_expected_rows": sum(specimen_rows.values())}


def validate(context, role, root=ROOT):
    contract = context.get("assignment_contract")
    if contract is None:
        return
    if not isinstance(contract, dict) or contract.get("profile") != "revision-scorecard-v1":
        raise ValueError("Unknown task-scoped assignment contract.")
    profile = json.loads((Path(root) / "profiles/revision-scorecard-v1.json").read_text(encoding="utf-8"))
    item = profile["assignments"].get(contract.get("work_item"))
    if not item or item["owner"] != role:
        raise ValueError("This work item belongs to a different worker or the main session.")
    ids = contract.get("deliverable_ids")
    if not isinstance(ids, list) or len(ids) != len(set(ids)) or set(ids) != set(item["deliverable_ids"]):
        raise ValueError("Delegation must deliver the exact assigned outputs; a source audit cannot replace normalization.")
    if contract.get("parent_reserved") != profile["parent_reserved"]:
        raise ValueError("Preserve the explicit main-session abstract, integration and specimen-selection boundary.")
    if context.get("routing_decision", {}).get("bounded_scope") != item["bounded_scope"]:
        raise ValueError("Use the canonical bounded scope for this task contract.")
    if contract.get("browser_policy") != "no_ui":
        raise ValueError("The content-only scorecard forbids browser/UI work. Use a separate authorized desktop test.")


def acceptance(profile, work_item, returned_ids, checks):
    """Parent supplies observed checks, not a worker's self-acceptance claim."""
    spec = json.loads((ROOT / "profiles" / (profile + ".json")).read_text(encoding="utf-8"))
    expected = set(spec["assignments"][work_item]["deliverable_ids"])
    if set(returned_ids) != expected:
        raise ValueError("Actual outputs differ from the assigned deliverables.")
    if not checks or any(c.get("passed") is not True or not c.get("tool_evidence_reference") for c in checks):
        raise ValueError("Parent-observed verification and tool evidence are required before adoption.")
    return {"accepted": True, "work_item": work_item, "deliverable_ids": sorted(expected), "checks": checks}

"""Foreground bridge for an eligible Astra claim. The project parent owns all writes."""

from contextlib import closing
import hashlib
import json
import os
from pathlib import Path
from queue import Empty, Queue
import re
import sqlite3
import subprocess
import sys
import threading
import time
import tomllib

from content_dispatch import ContentDispatch, write_record
from desktop_dispatch import runtime_identity
from receipt_order import runtime_transcript, verify_resume_echo, verify_system_readonly


class ReadonlyHost:
    def __init__(self, home, log):
        env = os.environ.copy()
        env.pop('CODEX_THREAD_ID', None)
        config = tomllib.loads((home/'config.toml').read_text(encoding='utf-8'))
        # Disable the carrier's network connectors without modifying user configuration.
        args = ['codex','app-server','--listen','stdio://','-c','features.apps=false']
        if os.name == 'nt':
            # The standalone carrier lacks the desktop application's registered
            # Core launch context. MXC enforces the same explicit read-only profile.
            args += ['-c','windows.sandbox="mxc"']
        for name in config.get('mcp_servers',{}):
            if not re.fullmatch(r'[A-Za-z0-9_-]+',name):
                raise ValueError('Unsupported MCP configuration key for isolated carrier.')
            args += ['-c',f'mcp_servers.{name}.enabled=false']
        self.proc = subprocess.Popen(args,stdin=subprocess.PIPE,stdout=subprocess.PIPE,
                                     stderr=log,encoding='utf-8',env=env)
        self.events = Queue()
        self.ident = 0

        def pump():
            try:
                for line in self.proc.stdout:
                    self.events.put(json.loads(line))
            finally:
                self.events.put(None)

        threading.Thread(target=pump,daemon=True).start()

    def send(self,payload):
        self.proc.stdin.write(json.dumps(payload,ensure_ascii=False)+'\n')
        self.proc.stdin.flush()

    def receive(self,deadline):
        while True:
            remaining=deadline-time.monotonic()
            if remaining<=0:
                raise TimeoutError('Read-only carrier deadline exceeded.')
            try:
                event=self.events.get(timeout=remaining)
            except Empty as error:
                raise TimeoutError('Read-only carrier deadline exceeded.') from error
            if event is None:
                raise RuntimeError('Read-only carrier exited.')
            if 'method' in event and 'id' in event:
                self.send({'id':event['id'],'error':{'code':-32601,'message':'Carrier grants no host requests.'}})
                continue
            yield event

    def request(self,method,params):
        self.ident+=1
        self.send({'id':self.ident,'method':method,'params':params})
        for event in self.receive(time.monotonic()+35):
            if event.get('id')==self.ident:
                if 'error' in event:
                    raise RuntimeError(f"Read-only carrier rejected {method}.")
                return event['result']

    def start(self,project,policy):
        self.request('initialize',{'clientInfo':{'name':'astra_readonly_carrier','version':'1.0'}})
        self.send({'method':'initialized','params':{}})
        if os.name == 'nt' and self.request('windowsSandbox/readiness',{}).get('status') != 'ready':
            raise RuntimeError('The Windows MXC sandbox is not ready for the read-only carrier.')
        opened=self.request('thread/start',{'cwd':str(project),'sandbox':'read-only','approvalPolicy':'never',
            'model':policy['root_model'],'config':{'model_reasoning_effort':policy['root_effort']}})
        if (opened['sandbox'].get('type')!='readOnly' or opened['sandbox'].get('networkAccess',False)
                or opened['approvalPolicy']!='never' or opened['model']!=policy['root_model']):
            raise RuntimeError('Host refused the required read-only session.')
        return opened['thread']['id']

    def turn(self,thread,message):
        turn=self.request('turn/start',{'threadId':thread,'input':[{'type':'text','text':message}]})['turn']
        for event in self.receive(time.monotonic()+480):
            if event.get('method')=='turn/completed' and event['params']['turn']['id']==turn['id']:
                if event['params']['turn']['status']!='completed':
                    raise RuntimeError('Readonly carrier turn did not complete.')
                return

    def close(self):
        self.proc.stdin.close()
        try:
            self.proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            self.proc.terminate()
            self.proc.wait(timeout=10)


def find_child(home,parent,name):
    databases=sorted(home.glob('state_*.sqlite'),key=lambda p:int(p.stem.split('_')[-1]),reverse=True)
    if not databases:
        raise RuntimeError('Native thread index is unavailable.')
    with closing(sqlite3.connect(databases[0].as_uri()+'?mode=ro',uri=True)) as db:
        rows=db.execute("select id,source from threads where agent_role='astra_review_subscription'").fetchall()
    children=[]
    for tid,source in rows:
        lineage=json.loads(source).get('subagent',{}).get('thread_spawn',{})
        if (lineage.get('parent_thread_id')==parent
                and str(lineage.get('agent_path','')).rsplit('/',1)[-1]==name):
            children.append(tid)
    if len(children)!=1:
        raise RuntimeError('No unique native Astra child of the bound carrier.')
    return children[0]


def probe_command_bound(call, task, source, helper, target):
    raw=call.get('input',call.get('arguments',''))
    if not isinstance(raw,str):
        return False
    match=re.search(r'(?:"cmd"|cmd)\s*:\s*("(?:\\.|[^"\\])*")',raw)
    command=json.loads(match[1]) if match else raw
    command=command.replace('\r\n','\n').strip()
    literal="python -B '"+helper['frozen_snapshot_reference']+"' '"+source['frozen_snapshot_reference']+"' '"+str(target)+"'"
    if command==literal:
        return True
    # The native shell can resolve the exact paths from the immutable JSON
    # rather than restating them. Match the complete observed PowerShell form.
    expected=(
        f"$frozenInput = Get-Content -LiteralPath '{task['native_input_path']}' -Encoding UTF8 -Raw | ConvertFrom-Json\n"
        f"$probeHelper = ($frozenInput.context_package.evidence.source_material_manifest | Where-Object material_id -eq '{helper['material_id']}').frozen_snapshot_reference\n"
        f"$probeSource = ($frozenInput.context_package.evidence.source_material_manifest | Where-Object material_id -eq '{source['material_id']}').frozen_snapshot_reference\n"
        "$probeTarget = $frozenInput.context_package.task.readonly_probe.target\n"
        "python -B $probeHelper $probeSource $probeTarget"
    )
    return command==expected


def verify_public_probe(package, events, task):
    """Validate an optional qualification probe from actual tool results."""
    probe=package['task'].get('readonly_probe')
    if not probe:
        return None
    target=Path(probe['target'])
    files={item['material_id']:item for item in package['evidence']['source_material_manifest']}
    source=files[probe['source_material_id']]
    helper=files[probe['helper_material_id']]
    calls={}
    matches=[]
    for line,event in enumerate(events,1):
        item=event.get('payload',{})
        kind=item.get('type','')
        if kind.endswith('_call'):
            calls[item.get('call_id')]=(line,item)
        if kind not in ('function_call_output','custom_tool_call_output'):
            continue
        for block in item.get('output',[]):
            if not isinstance(block,dict):
                continue
            try:
                output=json.loads(block['text'])
                observed=json.loads(output['output'])
            except (KeyError,ValueError,TypeError):
                continue
            if not isinstance(observed,dict):
                continue
            if (output.get('exit_code')==0 and observed.get('target')==str(target)
                    and observed.get('sha256')==source['sha256'] and observed.get('write_denied') is True
                    and observed.get('error')=='PermissionError' and observed.get('errno')==13):
                call_line,call=calls[item['call_id']]
                if probe_command_bound(call,task,source,helper,target):
                    matches.append({'call_line':call_line,'output_line':line,'observed':observed})
    if len(matches)!=1 or target.exists() or target.is_symlink():
        raise RuntimeError('Public fixture did not establish an actual system write denial.')
    return matches[0]


def collect_astra_readonly_result(engine,task_id,parent):
    """Collect an already completed native turn without sending another turn."""
    from worker_core import digest
    dispatch=ContentDispatch(engine.root,ledger_path=engine.database)
    with dispatch.transaction() as db:
        task=dispatch.task(db,task_id)
    record=task['native_dispatch']
    if task['parent_session_id']!=parent or not record.get('host_session_id') or record['phase']!='active':
        raise ValueError('Native collection does not belong to the active project owner.')
    child=record['child_id']
    carrier=record['host_session_id']
    identity=runtime_identity(child,dispatch.home)
    if identity.get('parent_id')!=carrier:
        raise RuntimeError('Native carrier lineage changed before collection.')
    transcript=runtime_transcript(child,dispatch.home)
    events=[json.loads(line) for line in transcript.open(encoding='utf-8')]
    turns=[x['payload'] for x in events if x.get('type')=='event_msg' and x.get('payload',{}).get('type')=='task_complete']
    if len(turns)<2:
        return engine.get_task(task_id)
    if len(turns)!=2:
        raise RuntimeError('Unexpected additional native child turns.')
    result=json.loads(turns[-1]['last_agent_message'])
    package=engine.read_package(task)
    if digest(Path(task['native_input_path']).read_bytes())!=task['native_input_sha256']:
        raise RuntimeError('Frozen native input drifted after execution.')
    system=verify_resume_echo(child,record['resume_message'],record['resume_dispatch'],dispatch.home)
    host_system=verify_system_readonly(carrier,dispatch.home)
    if len(host_system['turn_ids'])!=2:
        raise RuntimeError('Expected exactly the two bound read-only carrier turns.')
    probe=verify_public_probe(package,events,task)
    with closing(sqlite3.connect((engine.root/'routing/state/routing-audit.sqlite3').as_uri()+'?mode=ro',uri=True)) as audit:
        calls=audit.execute("SELECT event,tool,decision FROM events WHERE thread_id=? ORDER BY id",(child,)).fetchall()
        host_calls=audit.execute("SELECT event,tool,decision FROM events WHERE thread_id=? ORDER BY id",(carrier,)).fetchall()
    if (('PreToolUse','Bash','allow') not in calls or ('PostToolUse','Bash','observed') not in calls):
        raise RuntimeError('Actual native sandboxed read has no matching Hook evidence.')
    for suffix in ('spawn_agent','followup_task'):
        if sum(event=='PreToolUse' and tool.endswith(suffix) and decision=='allow'
               for event,tool,decision in host_calls)!=1:
            raise RuntimeError('Read-only carrier lacks an exact observed spawn or continuation.')
    evidence=Path(record['handoff_path']).parent/'readonly-isolation-evidence.json'
    write_record(evidence,{'owner_session_id':parent,'host_session_id':carrier,'child_identity':identity,
        'package_sha256':task['package_hash'],'child_trace':str(transcript),'system_readonly':system,
        'host_system_readonly':host_system,'host_hook_events':host_calls,
        'actual_probe':probe,'actual_hook_events':calls,'parent_owned_receipt':True})
    native={'native_thread_id':child,'actual_model':identity['model'],'actual_reasoning_effort':identity['effort'],
            'execution_record_reference':str(transcript),'reviewed_artifacts_read_only_verified':True,
            'isolation_evidence_ref':str(evidence)}
    return engine.complete_subscription_fallback(task_id,task['claim_token'],native,result)


def run_astra_readonly_fallback(engine,task_id,parent,project_root,*,host_factory=ReadonlyHost):
    """The owning foreground call claims, starts, verifies and collects; never accepts."""
    import architecture_policy
    import api_balance
    from project_handoffs import project_handoffs
    from worker_core import ELIGIBLE_CODES
    task=engine.get_task(task_id)
    if architecture_policy.astra_parent_fallback(task):
        raise ValueError('This Astra review must be spawned directly by the owning main session.')
    if (task['parent_session_id']!=parent or task['role']!='api_astra_review'
            or task['status']!='fallback_ready' or task.get('api_charge_uncertain')
            or not architecture_policy.astra_direct_task(task) and task.get('reason') not in ELIGIBLE_CODES | {
                'api_budget_insufficient_before_dispatch','confirmed_pre_inference_provider_unavailable',
                api_balance.SESSION_NATIVE_REASON}):
        raise ValueError('Task is not an eligible owning Astra fallback.')
    engine.read_package(task)
    dispatch=ContentDispatch(engine.root,ledger_path=engine.database)
    policy=architecture_policy.load(engine.root)
    if not policy:
        raise ValueError('Coordinator policy is unavailable.')
    if (architecture_policy.astra_direct_task(task) or task.get('astra_readonly_review')) and (
            os.environ.get('CODEX_THREAD_ID')!=parent
            or not architecture_policy.is_primary(runtime_identity(parent,dispatch.home),policy)):
        raise ValueError('Astra direct qualification requires its actual owning Terra/high session.')
    directory=project_handoffs(project_root,parent)
    project=directory.parents[2]
    name='astra_'+task_id.replace('-','')
    claim=engine.claim_subscription_fallback(task_id,parent)
    log_path=directory/(name+'-host.stderr')
    with log_path.open('xb') as log:
        host=None
        try:
            try:
                host=host_factory(dispatch.home,log)
                carrier=host.start(project,policy)
            except Exception:
                # No thread turn has been requested. Release only after the
                # process is confirmed closed, and keep the startup evidence.
                if host is not None:
                    host.close()
                host=None
                evidence=directory/(name+'-startup-closeout.json')
                write_record(evidence,{'status':'cancelled_before_native_dispatch','task_id':task_id,
                                       'owner_session_id':parent,'host_stderr':str(log_path)})
                engine.cancel_task(task_id,{'confirmed_not_running':True,'outcome':'cancelled',
                                            'evidence_reference':str(evidence)})
                raise
            handoff=dispatch.prepare(task_id,parent,claim['claim_token'],name,str(project),host_session_id=carrier)
            args={'agent_type':handoff['native_role'],'task_name':name,'fork_turns':'none','message':handoff['spawn_message']}
            host.turn(carrier,'Transport one frozen Astra claim. Call the named native spawn tool once with these exact arguments. '
                      'Wait for the chat acknowledgement, then end the turn. Do not perform review or call other tools. '
                      +json.dumps(args,ensure_ascii=False))
            child=find_child(dispatch.home,carrier,name)
            identity=runtime_identity(child,dispatch.home)
            activation=dispatch.activate(task_id,parent,child,identity)
            host.turn(carrier,'The project parent verified the chat receipt and activated the same child. '
                      f'Call followup_task exactly once on {name} with the exact message below. '
                      'Wait for its result and stop. Do not start another child. Exact message:\n'+activation['resume_message'])
            return collect_astra_readonly_result(engine,task_id,parent)
        finally:
            if host is not None:
                host.close()


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--task-id',required=True)
    parser.add_argument('--project-root')
    args=parser.parse_args()
    parent=os.environ.get('CODEX_THREAD_ID')
    if not parent:
        raise SystemExit('Run from the owning project main session.')
    service=Path(__file__).resolve().parents[1]
    sys.path.insert(0,str(service))
    from worker_core import Engine
    from project_handoffs import project_for_session
    project=args.project_root or project_for_session(service.parents[1],parent)
    if project is None:
        raise SystemExit('The owning session has no registered project. Initialize the managed project first.')
    result=run_astra_readonly_fallback(Engine(service),args.task_id,parent,project)
    print(json.dumps({'task_id':result['id'],'status':result['status'],'acceptance_owner':'project_main'}))

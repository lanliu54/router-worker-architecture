"""Exclusive UI lease for an actual primary Terra/high root; no UI operations."""
from contextlib import contextmanager
import argparse
import hashlib
import json
from pathlib import Path
import secrets
import sqlite3
import sys
import time
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from architecture_policy import load,is_primary

ROOT=Path(__file__).resolve().parent.parent

class MainUIStore:
    def __init__(self,root=ROOT):
        self.root=Path(root).resolve();self.path=self.root/'routing/state/desktop-dispatch.sqlite3'
    @contextmanager
    def transaction(self):
        self.path.parent.mkdir(parents=True,exist_ok=True)
        db=sqlite3.connect(self.path,timeout=2,isolation_level=None);db.row_factory=sqlite3.Row
        try:
            db.execute('BEGIN IMMEDIATE')
            db.execute('CREATE TABLE IF NOT EXISTS main_ui_leases(thread_id TEXT PRIMARY KEY,lease_id TEXT NOT NULL,phase TEXT NOT NULL,scope_json TEXT NOT NULL,scope_sha256 TEXT NOT NULL,created_at REAL NOT NULL,closeout_json TEXT)')
            yield db;db.commit()
        except Exception:db.rollback();raise
        finally:db.close()
    def acquire(self,who,scope):
        if not is_primary(who,load(self.root)):raise ValueError('UI lease requires observed root gpt-6.1-terra/high, not a child, declared name or stale model.')
        for key in ('objective','authorized_scope','user_request_provenance','acceptance_criteria'):
            if not scope.get(key):raise ValueError('Complete task UI authority and acceptance before acquiring a lease.')
        raw=json.dumps(scope,ensure_ascii=False,sort_keys=True,separators=(',',':'))
        with self.transaction() as db:
            active=db.execute("SELECT * FROM main_ui_leases WHERE phase='active'").fetchall()
            if active:
                if len(active)==1 and active[0]['thread_id']==who['id'] and active[0]['scope_json']==raw:return dict(active[0])
                raise ValueError('Another UI owner or changed scope requires explicit reconciliation; elapsed time never transfers ownership.')
            exists=db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='dispatches'").fetchone()
            if exists and db.execute("SELECT 1 FROM dispatches WHERE phase IN ('prepared','dispatch_pending','active') LIMIT 1").fetchone():
                raise ValueError('A legacy desktop grant is still open; do not take over its UI.')
            lease=secrets.token_hex(16)
            db.execute('INSERT INTO main_ui_leases VALUES(?,?,?,?,?,?,NULL) ON CONFLICT(thread_id) DO UPDATE SET lease_id=excluded.lease_id,phase=excluded.phase,scope_json=excluded.scope_json,scope_sha256=excluded.scope_sha256,created_at=excluded.created_at,closeout_json=NULL',
                (who['id'],lease,'active',raw,hashlib.sha256(raw.encode()).hexdigest(),time.time()))
            return dict(db.execute('SELECT * FROM main_ui_leases WHERE thread_id=?',(who['id'],)).fetchone())
    def check(self,who):
        if not is_primary(who,load(self.root)):raise ValueError('Current native identity is not the primary Terra/high root.')
        with self.transaction() as db:
            rows=db.execute("SELECT * FROM main_ui_leases WHERE phase='active'").fetchall()
            if len(rows)!=1 or rows[0]['thread_id']!=who['id']:raise ValueError('Acquire this main session task UI lease before desktop/browser control.')
            return dict(rows[0])
    def release(self,who,lease_id,closeout):
        self.check(who)
        if closeout.get('outcome') not in ('completed','blocked','cancelled','handoff'):raise ValueError('Record actual outcome.')
        if not closeout.get('evidence_references') or not closeout.get('owned_resources') or not closeout.get('client_control_state'):
            raise ValueError('Separate observed owned resources and client-state limits with evidence.')
        for path in closeout['evidence_references']:
            if not Path(path).is_absolute() or not Path(path).is_file():raise ValueError('Closeout evidence must exist; do not infer cleanup.')
        with self.transaction() as db:
            changed=db.execute("UPDATE main_ui_leases SET phase='closed',closeout_json=? WHERE thread_id=? AND lease_id=? AND phase='active'",
                (json.dumps(closeout,ensure_ascii=False),who['id'],lease_id)).rowcount
            if changed!=1:raise ValueError('Lease token or owner changed.')
            return {'local_authority':'closed','full_client_release':closeout['client_control_state'],'owned_resources':closeout['owned_resources']}

def main():
    p=argparse.ArgumentParser();p.add_argument('action',choices=['acquire','check','release']);p.add_argument('--thread',required=True);p.add_argument('--scope');p.add_argument('--lease');p.add_argument('--closeout');args=p.parse_args()
    from desktop_dispatch import runtime_identity
    who=runtime_identity(args.thread)
    store=MainUIStore()
    if args.action=='acquire':result=store.acquire(who,json.loads(Path(args.scope).read_text(encoding='utf-8')))
    elif args.action=='release':result=store.release(who,args.lease,json.loads(Path(args.closeout).read_text(encoding='utf-8')))
    else:result=store.check(who)
    print(json.dumps(result,ensure_ascii=False))

if __name__=='__main__':main()

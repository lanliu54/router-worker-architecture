"""Stable host metadata and tool classification for the routing Hook."""
import ast
from contextlib import contextmanager
import json
from pathlib import Path
import re
import sqlite3


JS_NON_CODE = re.compile(r'''"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|`(?:\\.|[^`\\])*`|//[^\r\n]*|/\*[\s\S]*?\*/''')
WRAPPERS = {"exec", "functions.exec"}
PUBLIC_UI_TOOLS = {"open_in_codex", "navigate_to_codex_page"}


def public_ui_call(tool):
    return tool in PUBLIC_UI_TOOLS or (tool.startswith("mcp__codex_app__") and tool.rsplit("__", 1)[-1] in PUBLIC_UI_TOOLS)


def interpolated_templates(code):
    return (match.group() for match in JS_NON_CODE.finditer(code)
            if match.group().startswith(chr(96)) and "${" in match.group())


def wrapped_events(event):
    """Inspect documented literal tools.NAME(...) calls without executing JS.

    Ordinary code is unaffected. Controlled calls with dynamic arguments must
    use a structured tool call or literal JSON so ownership can be checked.
    This is intentionally not a general JavaScript evaluator or security parser.
    """
    if event.get("tool_name") not in WRAPPERS:
        return None, None
    value = event.get("tool_input")
    code = value if isinstance(value, str) else (value.get("code", value.get("input")) if isinstance(value, dict) else None)
    if not isinstance(code, str):
        return [], "Unsupported code-mode input layout."
    if len(code) > 1024 * 1024:
        return [], "Code-mode input exceeds the routing inspection bound."
    if any(re.search(r"\b(?:tools|eval|Function)\b", template) for template in interpolated_templates(code)):
        return [], "Tool access inside interpolated templates cannot be inspected. Use an explicit tool call."
    masked = JS_NON_CODE.sub(lambda m: " " * len(m.group()), code)
    found = []
    for match in re.finditer(r"\btools\s*\.\s*([A-Za-z_$][\w$]*)\s*\(", masked):
        name = match.group(1)
        if not public_ui_call(name) and not any(part in name for part in ("cua_repl", "computer", "browser", "node_repl", "hybrid_api_workers", "spawn_agent", "followup_task")):
            continue
        start, end, depth = match.end(), match.end(), 1
        while end < len(masked) and depth:
            depth += (masked[end] == "(") - (masked[end] == ")")
            end += 1
        if depth or len(found) >= 64:
            return [], "Controlled code-mode calls could not be bounded for inspection."
        raw = code[start:end - 1].strip()
        args = None
        try:
            args = json.loads(raw)
        except (ValueError, TypeError):
            # JSON.parse("...") is also inspectable, without evaluating code.
            parsed = re.fullmatch(r"JSON\.parse\(\s*(\"(?:\\.|[^\"\\])*\")\s*\)", raw)
            if parsed:
                try:
                    args = json.loads(json.loads(parsed.group(1)))
                except (ValueError, TypeError):
                    pass
        if args is None and "node_repl" in name:
            visible = JS_NON_CODE.sub(lambda m: " " * len(m.group()), raw)
            field = re.search(r"\bcode\s*:", visible)
            if field:
                offset = field.end()
                while offset < len(raw) and raw[offset].isspace():
                    offset += 1
                literal = JS_NON_CODE.match(raw, offset)
                if literal and literal.group()[0] in ("'", '"'):
                    try:
                        value = ast.literal_eval(literal.group())
                        if isinstance(value, str):
                            args = {"code": value}
                    except (ValueError, SyntaxError):
                        pass
                elif literal and literal.group()[0] == "`" and "${" not in literal.group() and "\\" not in literal.group():
                    args = {"code": literal.group()[1:-1]}
        if not isinstance(args, dict):
            return [], "Controlled code-mode arguments are dynamic or unsupported; use a structured call or literal JSON without omitting context."
        found.append({**event, "tool_name": name, "tool_input": args})
    return found, None


def normal_path(value):
    """Normalize equivalent Windows extended-length paths before comparison."""
    text = str(value)
    if text.startswith("\\\\?\\UNC\\"):
        text = "\\\\" + text[8:]
    elif text.startswith("\\\\?\\"):
        text = text[4:]
    return Path(text).resolve()


@contextmanager
def readonly(path):
    db = sqlite3.connect(path.resolve().as_uri() + "?mode=ro", uri=True, timeout=1.5)
    db.execute("PRAGMA query_only=ON")
    try:
        yield db
    finally:
        db.close()


def identity(event, home):
    """Cross-check runtime transcript metadata against the local threads record.

    Hook session_id can be the PARENT id, so it must not identify a child.
    Local transcript metadata is version-specific; unknown layouts fail closed
    for controlled calls instead of granting desktop access by model name alone.
    """
    raw_path = event.get("transcript_path")
    if not raw_path:
        raise ValueError("Runtime transcript identity is unavailable.")
    path = normal_path(raw_path)
    if not path.is_relative_to(normal_path(home / "sessions")) or Path(raw_path).is_symlink():
        raise ValueError("Runtime transcript is outside the configured session directory.")
    with path.open("r", encoding="utf-8") as stream:
        line = stream.readline(2 * 1024 * 1024)
    meta = json.loads(line)
    if meta.get("type") != "session_meta":
        raise ValueError("Runtime transcript metadata layout is unsupported.")
    meta = meta["payload"]
    identifier = meta["id"]
    paths = sorted(home.glob("state_*.sqlite"), key=lambda p: int(p.stem.split("_")[-1]), reverse=True)
    if not paths:
        raise ValueError("Native execution metadata database is unavailable.")
    with readonly(paths[0]) as db:
        row = db.execute("SELECT rollout_path,agent_role,model,reasoning_effort,source FROM threads WHERE id=?", (identifier,)).fetchone()
    if not row or normal_path(row[0]) != path:
        raise ValueError("Native execution metadata does not match the supplied transcript.")
    role = row[1] or ""
    if role != (meta.get("agent_role") or "") or row[2] != event.get("model"):
        raise ValueError("Native role/model identity is inconsistent.")
    source = meta.get("source", {})
    spawned = isinstance(source, dict) and "subagent" in source
    if spawned and not role:
        raise ValueError("Unnamed subagent identity is unsupported by managed routing.")
    lineage = source.get("subagent", {}).get("thread_spawn", {}) if spawned else {}
    return {"id": identifier, "role": role, "model": row[2], "effort": row[3], "is_child": spawned,
            "parent_id": lineage.get("parent_thread_id"),
            "task_name": lineage.get("agent_path", "").rsplit("/", 1)[-1] or None}


def is_astra_host(who,home):
    if not who or who.get('is_child') or who.get('role'):
        return False
    ledger=home/'integrations/hybrid-api-workers/state/tasks.sqlite3'
    if not ledger.is_file():
        return False
    with readonly(ledger) as db:
        return db.execute("SELECT 1 FROM tasks WHERE json_extract(data,'$.native_dispatch.host_session_id')=? LIMIT 1",
                          (who['id'],)).fetchone() is not None



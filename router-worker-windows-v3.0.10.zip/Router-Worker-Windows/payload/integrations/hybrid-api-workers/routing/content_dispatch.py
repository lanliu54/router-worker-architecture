"""Receipt-first transport for an already claimed content subscription fallback.

Opaque host envelopes are not decrypted or treated as authority. This module
uses the existing worker task ledger, exact frozen input and native identity.
It creates no second task, execution ledger, model call or substitute role.
"""
from contextlib import contextmanager, closing
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import sqlite3
import tempfile
from project_handoffs import check_directory, project_handoffs

ROOT=Path(__file__).resolve().parent.parent

def canonical(value):
    return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode('utf-8')

def sha(value):return hashlib.sha256(value).hexdigest()

def frozen_text_lengths(native_input_path, package):
    """Match PowerShell's BOM-aware decoded UTF-16 units for exact frozen paths."""
    paths = [native_input_path]
    paths.extend(item['frozen_snapshot_reference'] for item in package['evidence']['source_material_manifest']
                 if item['media_type'].startswith('text/') or item['media_type']=='application/json')
    return {name: len(Path(name).read_bytes().decode('utf-8-sig').encode('utf-16-le')) // 2
            for name in paths}

def frozen_text_slices(native_input_path, package, limit=8000):
    """Provide UTF-16 ranges that never split a non-BMP character."""
    result = {}
    for name in frozen_text_lengths(native_input_path, package):
        text = Path(name).read_bytes().decode('utf-8-sig')
        start = count = 0
        ranges = []
        for character in text:
            size = 2 if ord(character) > 0xffff else 1
            if count and count + size > limit:
                ranges.append([start, count])
                start += count
                count = 0
            count += size
        if count:
            ranges.append([start, count])
        result[name] = ranges
    return result


def native_parent(task):
    """A carrier session can transport the claim without owning it."""
    return task.get('native_dispatch',{}).get('host_session_id') or task['parent_session_id']


def native_parent_rows(db, parent):
    return db.execute(
        "SELECT json_extract(data,'$.id'),data FROM tasks WHERE status='fallback_claimed' AND "
        "coalesce(json_extract(data,'$.native_dispatch.host_session_id'),parent)=?",(parent,)).fetchall()


def write_record(path, value):
    data = canonical(value)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=path.parent, prefix='.record-', delete=False) as stream:
            temporary = Path(stream.name)
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        try:
            os.link(temporary, path)
        except FileExistsError:
            if path.is_symlink() or not path.is_file() or path.read_bytes() != data:
                raise ValueError('Existing handoff record conflicts with runtime evidence.')
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def verify_plaintext_activation(record, hash_field='sol_plaintext_activation_sha256'):
    """Verify the parent-written continuation before admitting native tools."""
    path = Path(record['handoff_path']).with_name('activation.json')
    if path.is_symlink() or sha(path.read_bytes()) != record[hash_field]:
        raise ValueError('The plaintext Sol continuation is missing or changed.' if hash_field.startswith('sol_')
                         else 'The plaintext Astra continuation is missing or changed.')


class ContentDispatch:
    def __init__(self,root=ROOT,*,ledger_path=None,runtime_home=None):
        self.root=Path(root).resolve()
        self.home=Path(runtime_home).resolve() if runtime_home is not None else self.root.parents[1]
        self.dbpath=Path(ledger_path).resolve() if ledger_path is not None else self.root/'state/tasks.sqlite3'

    @contextmanager
    def transaction(self, *, controller_lock=False):
        db=sqlite3.connect(self.dbpath,timeout=2,isolation_level=None)
        try:
            if controller_lock:
                controller=self.root/'orchestrator-control'/'runtime'/'state.sqlite'
                if not controller.is_file():raise ValueError('Historical controller database is unavailable.')
                db.execute('ATTACH DATABASE ? AS controller_guard',(str(controller),))
            db.execute('BEGIN IMMEDIATE');yield db;db.commit()
        except Exception:
            db.rollback();raise
        finally:db.close()

    def task(self,db,task_id):
        row=db.execute('SELECT data FROM tasks WHERE id=?',(task_id,)).fetchone()
        if not row:raise ValueError('Claimed fallback task is unavailable.')
        task=json.loads(row[0])
        if task['status']!='fallback_claimed':raise ValueError('Only an existing active fallback claim can prepare/activate native transport.')
        path=Path(task['native_input_path'])
        expected=self.root/'state/packages'/task_id/'subscription-input.json'
        if path.resolve()!=expected.resolve() or path.is_symlink() or sha(path.read_bytes())!=task['native_input_sha256']:
            raise ValueError('Exact claimed subscription input changed or is unavailable.')
        return task

    def require_not_maintenance(self):
        path = self.root / 'maintenance.json'
        if path.exists():
            try:
                state = json.loads(path.read_text(encoding='utf-8'))
            except (OSError, ValueError) as error:
                raise ValueError('Maintenance state unreadable; native dispatch blocked.') from error
            if state.get('enabled') is not False:
                raise ValueError('Native dispatch is disabled during maintenance.')

    @staticmethod
    def save(db,task):
        if db.execute("UPDATE tasks SET data=? WHERE id=? AND status='fallback_claimed'",(canonical(task).decode(),task['id'])).rowcount!=1:
            raise ValueError('Fallback task changed concurrently.')

    def prepare(self,task_id,parent,claim_token,task_name,project_root=None,*,host_session_id=None):
        self.require_not_maintenance()
        if not re.fullmatch(r'[a-z][a-z0-9_]{0,63}',task_name):raise ValueError('Invalid native task name.')
        from architecture_policy import load
        if task_name.startswith('direct_') and (load(self.root) or {}).get('host_spawn_effective_at_epoch'):
            raise ValueError('The direct_ prefix is reserved for built-in Codex dispatch.')
        with self.transaction() as db:
            task=self.task(db,task_id)
            if task['parent_session_id']!=parent or not secrets.compare_digest(task.get('claim_token',''),claim_token):
                raise ValueError('Only the submitting parent with its active claim can prepare transport.')
            if task.get('native_dispatch'):
                raise ValueError('Native transport is already prepared or may have executed; reconcile instead of preparing twice.')
            from architecture_policy import ASTRA_MANIFEST_DELIVERY, ASTRA_READ_RECEIPT, astra_parent_fallback
            astra_parent = astra_parent_fallback(task)
            if host_session_id is not None and (
                    astra_parent or task['native_role']!='astra_review_subscription' or parent==host_session_id
                    or not re.fullmatch(r'[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}',host_session_id)):
                raise ValueError('Invalid independent native Astra host binding.')
            transport_parent=host_session_id or parent
            for other_id, other_raw in native_parent_rows(db, transport_parent):
                other = json.loads(other_raw)
                prior_name = other.get('native_dispatch', {}).get('task_name')
                if other_id != task_id and isinstance(prior_name, str) and prior_name.casefold() == task_name.casefold():
                    raise ValueError('This parent already has a prepared native claim using that task name.')
            # A previous native child with this exact lineage/name is evidence of
            # possible execution, even if the service has no terminal result yet.
            import guard
            paths=sorted(self.home.glob('state_*.sqlite'),key=lambda p:int(p.stem.split('_')[-1]),reverse=True)
            if not paths:raise ValueError('Actual native runtime metadata is unavailable.')
            with guard.readonly(paths[0]) as native:
                rows=native.execute('SELECT source FROM threads WHERE agent_role IS NOT NULL').fetchall()
            for row in rows:
                try:lineage=json.loads(row[0]).get('subagent',{}).get('thread_spawn',{})
                except (ValueError,TypeError):continue
                if lineage.get('parent_thread_id')==transport_parent and str(lineage.get('agent_path','')).rsplit('/',1)[-1].casefold()==task_name.casefold():
                    raise ValueError('An actual native child already used this task name; reconcile its execution first.')
            readonly_ack=task['native_role']=='astra_review_subscription'
            chat_ack=readonly_ack or task.get('requires_chat_ack')
            if not chat_ack:
                raise ValueError('New managed handoffs require a chat acknowledgement; refresh the owning Worker.')
            execution = task.get('native_execution', {})
            bind_workspace = task.get('routing_policy_version') == 5 or execution.get('mode') == 'in_place'
            if bind_workspace:
                from project_handoffs import workspace_for_session
                workspace = workspace_for_session(self.home, parent)
                if (workspace is None or workspace.is_relative_to(self.home) or self.home.is_relative_to(workspace)
                        or (execution.get('mode') == 'in_place' and str(workspace) != execution['workspace'])):
                    raise ValueError('The owning chat workspace changed before preparation.')
                if project_root is not None and not workspace.is_relative_to(Path(project_root).resolve(strict=True)):
                    raise ValueError('Handoff root does not contain the owning chat workspace.')
                project_root = str(workspace)
            if readonly_ack and project_root is None:
                raise ValueError('Astra handoff preparation requires the managed project root.')
            if project_root is None:
                directory=self.root/'state/packages'/task_id/'native-dispatch'
            else:
                directory=project_handoffs(project_root,parent)/task_name
            directory.mkdir(exist_ok=False)
            native_role=json.loads(Path(task['native_input_path']).read_text(encoding='utf-8'))['context_package']
            if native_role['task'].get('astra_readonly_review')!=task.get('astra_readonly_review'):
                raise ValueError('Astra material mode differs from the frozen native input.')
            if native_role['task'].get('astra_fallback_transport') != task.get('astra_fallback_transport'):
                raise ValueError('Astra transport differs from the frozen native input.')
            data={'transport_kind':'claimed_content_fallback','transport_version':2,'task_id':task_id,
                  'parent_session_id':parent,'task_name':task_name,'native_role':task['native_role'],
                  'model':native_role['role']['exact_model'],
                  'reasoning_effort':native_role['role']['reasoning_effort'],
                  'fork_turns':'none','package_hash':task['package_hash'],
                  'native_input_path':task['native_input_path'],'native_input_sha256':task['native_input_sha256']}
            if task.get('native_execution'):
                data['native_execution']=task['native_execution']
                data['runtime_home']=str(self.home);data['ledger_path']=str(self.dbpath)
            protocol=data['handoff_protocol']={
                    'version':2,'phase':'readonly_chat_ack',
                    'acknowledgement':{
                        'status':'missing_context',
                        'Result':{'type':'handoff_received','task_id':task_id,'challenge':secrets.token_hex(16)},
                        'Evidence':[],'Validation':{},
                        'Blocker':'Awaiting parent activation.',
                        'package_sha256':task['package_hash'],'received_material_ids':[]},
                    'required_first_action':'Return exactly the acknowledgement JSON as your first reply and stop. '
                        'Use no tools or file writes before activation. After the parent activates, read the frozen '
                        'input and required originals. Follow the frozen execution scope and return the required result.'}
            if readonly_ack and not astra_parent:
                protocol['system_readonly_required']=True
                from architecture_policy import astra_direct_task
                bound=astra_direct_task(task) or bool(task.get('astra_readonly_review'))
                protocol['astra_readonly_resume' if bound else 'opaque_resume_echo']=True
                protocol['astra_plaintext_activation_path']=str(directory/'activation.json')
                protocol['plaintext_first_read_version']=2 if bound else 1
                protocol['required_first_action'] += (
                    ' After the host wake, use the exact activation-file read as your first tool action. '
                    'The Hook verifies the host delivery directly; no copied wake commentary is required. '
                    'Follow the verified plaintext activation and frozen scope.'
                    if bound else
                    ' The resumed chat message is a short wake signal. Echo exactly that entire signal '
                    'as your first commentary before any tool. Then use the local sandboxed shell '
                    'to read astra_plaintext_activation_path and follow its plaintext continuation. '
                    'Treat the frozen package as the scope authority.'
                )
            elif (task['native_role']=='sol_execution_subscription' or task.get('dispatch_mode')=='subscription_direct'
                  or task.get('requires_managed_resume_ack')):
                echo_key='sol_resume_echo' if task['native_role']=='sol_execution_subscription' else 'managed_resume_echo'
                protocol[echo_key]=True
                protocol['required_first_action'] += (
                    ' On the resumed turn, send the entire continuation you receive verbatim '
                    'as your first commentary before using any tools. The Hook verifies it.'
                )
                if task['native_role']=='sol_execution_subscription' or task.get('requires_managed_resume_ack'):
                    # Retain the wire field used by the shared Sol/Luna verifier.
                    protocol['sol_plaintext_activation_path']=str(directory/'activation.json')
                    protocol['plaintext_first_read_version']=1
                    protocol['required_first_action'] += (
                        ' The resumed chat message is only a wake signal. After echoing it, '
                        'read sol_plaintext_activation_path as your first tool action. Follow '
                        'the plaintext continuation there and the frozen task package.'
                    )
            if protocol.get('plaintext_first_read_version'):
                from receipt_order import activation_read_code
                first_read_prefix = (
                    ' After the host-delivered wake, your first tool call must be this exact code: '
                    if protocol['plaintext_first_read_version']==2 else
                    ' After the exact wake echo your first tool call must be this exact code: '
                )
                protocol['required_first_action'] += first_read_prefix + activation_read_code(directory/'activation.json')
            if astra_parent:
                protocol['astra_fallback_transport'] = task['astra_fallback_transport']
                if native_role['task'].get('astra_material_delivery') == ASTRA_MANIFEST_DELIVERY:
                    protocol['astra_material_delivery'] = ASTRA_MANIFEST_DELIVERY
            if astra_parent or (task['native_role']=='sol_qa_subscription'
                                and native_role['task'].get('native_qa_boundary')=='review_rules_v1'):
                protocol['native_qa_boundary']='review_rules_v1'
                protocol['required_first_action'] += (
                    ' This review inherits host permissions and is restricted by review rules. '
                    'After the exact first read, use one literal text(await tools.exec_command(...)); per text read, '
                    'with login=false and JSON arguments. Allowed commands are Get-Content -LiteralPath \'<frozen path>\' -Raw -Encoding UTF8, '
                    '(Get-Content -LiteralPath \'<frozen path>\' -Raw -Encoding UTF8).Substring(offset,count) with decimal values, '
                    'or Get-FileHash -LiteralPath \'<frozen path>\' -Algorithm SHA256. '
                    'For a frozen image, use image((await tools.view_image({"path":"<frozen path>"})).image_url);. '
                    'Read only the activation file, native input and exact frozen snapshot paths. '
                    'Never write, edit, run generated code, use the network/UI or delegate. Return findings in chat.'
                )
                if task['native_role']=='sol_qa_subscription':
                    protocol['frozen_text_utf16_lengths'] = frozen_text_lengths(task['native_input_path'], native_role)
                    protocol['frozen_text_utf16_slices'] = frozen_text_slices(task['native_input_path'], native_role)
                    protocol['required_first_action'] += (
                        ' For every text file, including subscription-input.json, use the exact UTF-16 '
                        'length in activation.json; do not request a separate Length query. '
                        'Then read the exact Substring(offset,count) ranges listed in frozen_text_utf16_slices, '
                        'which are at most 8000 UTF-16 units and avoid splitting non-BMP characters, '
                        'ending exactly at that length. Never request more than 16000 units. '
                        'Only complete successful nontruncated outputs count as material coverage.'
                    )
            if protocol.get('astra_material_delivery') == ASTRA_MANIFEST_DELIVERY:
                protocol['required_first_action'] += (
                    ' Keep the review focused on the requested question and the evidence that resolves it. '
                    'The native input has a complete frozen context and manifest. Read each required original '
                    'from its manifest path rather than expecting copies of their text inside the input. '
                    'For long text, get its exact length with '
                    "(Get-Content -LiteralPath '<frozen path>' -Raw -Encoding UTF8).Length. "
                    'Use the declared Substring(offset,count) command with decimal offsets and counts '
                    'within that length. Choose the slice size to suit the tool output budget. If output '
                    'is truncated, read only the missing spans in smaller slices. Avoid repeating reads.'
                )
            if native_role['task'].get('astra_read_receipt') == ASTRA_READ_RECEIPT:
                protocol['required_first_action'] += (
                    ' The collector checks which required originals were delivered in successful tool output. '
                    'Length and hash queries do not count as content reads. Track the fully returned ranges '
                    'of each required file. A failed or truncated output does not confirm the requested '
                    'range. Use smaller reads only for ranges that are still unconfirmed before returning '
                    'completed. If any required original cannot be delivered, return missing_context.'
                )
            path=directory/'handoff.json';path.write_bytes(canonical(data))
            task['native_dispatch']={'phase':'prepared','task_name':task_name,'parent':parent,'handoff_path':str(path),
                'handoff_sha256':sha(canonical(data)),'child_id':None,'native_input_sha256':task['native_input_sha256']}
            if host_session_id is not None:
                task['native_dispatch']['host_session_id']=host_session_id
            if project_root is not None:
                task['native_dispatch']['project_root']=str(Path(project_root).resolve(strict=True))
            if bind_workspace:
                task['native_dispatch']['workspace_binding'] = str(workspace)
            self.save(db,task)
            return {'task_id':task_id,'model':data['model'],'reasoning_effort':data['reasoning_effort'],
                    'native_role':task['native_role'],'fork_turns':'none','task_name':task_name,
                    'package_hash':task['package_hash'],'native_input_sha256':task['native_input_sha256'],
                    'spawn_message':canonical(data).decode(),'transport_phase':'prepared'}

    def frozen(self,task):
        record=task['native_dispatch'];path=Path(record['handoff_path'])
        if 'project_root' in record:
            directory=project_handoffs(record['project_root'],task['parent_session_id'],create=False)/record['task_name']
            check_directory(directory)
            expected=directory/'handoff.json'
        else:
            expected=self.root/'state/packages'/task['id']/'native-dispatch/handoff.json'
        if path.resolve()!=expected.resolve() or path.is_symlink() or sha(path.read_bytes())!=record['handoff_sha256']:
            raise ValueError('Frozen content transport changed or is unavailable.')
        return json.loads(path.read_text(encoding='utf-8'))

    def admit(self,parent,target,task_name,message):
        self.require_not_maintenance()
        with self.transaction() as db:
            rows=native_parent_rows(db,parent)
            matches=[]
            for tid,_ in rows:
                task=self.task(db,tid);record=task.get('native_dispatch',{})
                if task.get('native_role')==target and record.get('task_name')==task_name and record.get('phase')=='prepared':matches.append(task)
            if len(matches)!=1:raise ValueError('No unique unused receipt-first content transport matches this exact active claim.')
            task=matches[0];data=self.frozen(task)
            try:decoded=json.loads(message)
            except (ValueError,TypeError):
                if not isinstance(message,str) or not re.fullmatch(r'gAAAA[A-Za-z0-9_=-]+',message):raise ValueError('Unsupported content dispatch envelope.') from None
            else:
                if canonical(decoded)!=canonical(data):raise ValueError('Native content message differs from the frozen transport.')
            task['native_dispatch'].update(phase='dispatch_pending',envelope_sha256=sha(message.encode()))
            self.save(db,task)

    def receipt(self,received):
        received=Path(received).resolve();data=json.loads(received.read_text(encoding='utf-8'))
        with self.transaction() as db:
            task=self.task(db,data['task_id']);record=task.get('native_dispatch',{})
            if self.frozen(task)['handoff_protocol']['phase']=='readonly_chat_ack':
                raise ValueError('Chat acknowledgements are recorded by the parent.')
            if record.get('phase')!='dispatch_pending' or received!=Path(record['handoff_path']).with_name('received-message.json').resolve() or canonical(data)!=canonical(self.frozen(task)):
                raise ValueError('Content receipt does not match the active pending transport.')
            receipt={'task_id':task['id'],'phase':'receipt_verified','content_authorized':False,'package_hash':task['package_hash']}
            received.with_name('receipt.json').write_bytes(canonical(receipt))
            return receipt

    def activate(self,task_id,parent,child,observed_identity):
        self.require_not_maintenance()
        from receipt_order import verify_readonly_ack, verify_runtime_first_action, verify_system_readonly
        with closing(sqlite3.connect(self.dbpath.as_uri()+'?mode=ro',uri=True)) as peek:
            row=peek.execute('SELECT data FROM tasks WHERE id=?',(task_id,)).fetchone()
        if not row:raise ValueError('Claimed fallback task is unavailable.')
        historical_locked=bool(json.loads(row[0]).get('historical_controller_qa'))
        with self.transaction(controller_lock=historical_locked) as db:
            task=self.task(db,task_id);record=task.get('native_dispatch',{});data=self.frozen(task)
            if bool(task.get('historical_controller_qa'))!=historical_locked:
                raise ValueError('Historical review binding changed before activation.')
            if task.get('historical_controller_qa'):
                from worker_core import Engine
                engine = object.__new__(Engine)
                engine.root = self.root
                package = json.loads(Path(task['native_input_path']).read_text(encoding='utf-8'))['context_package']
                manifest = package['evidence']['source_material_manifest']
                supplied = [{'path': m['provenance_locator'], 'material_id': m['material_id']} for m in manifest]
                hashes = [(m['sha256'], m['media_type']) for m in manifest]
                if not engine.historical_astra_qa(package['task'], parent, supplied, hashes, db):
                    raise ValueError('Historical QA ownership or snapshot changed before activation.')
            expected={'id':child,'parent_id':native_parent(task),'task_name':record['task_name'],'role':task['native_role'],
                      'model':data['model'],'effort':data['reasoning_effort'],'is_child':True}
            if record.get('phase')!='dispatch_pending' or task['parent_session_id']!=parent or any(observed_identity.get(k)!=v for k,v in expected.items()):
                raise ValueError('Actual content child identity or dispatch phase differs from the frozen claim.')
            execution = task.get('native_execution', {})
            if record.get('workspace_binding') or execution.get('mode') == 'in_place':
                from project_handoffs import workspace_for_session
                workspace = Path(record['workspace_binding'])
                if execution.get('mode') == 'in_place' and str(workspace) != execution['workspace']:
                    raise ValueError('Handoff root differs from the frozen Sol workspace.')
                if any(workspace_for_session(self.home, thread) != workspace for thread in (parent, child)):
                    raise ValueError('The parent and child must have the exact frozen current workspace.')
            directory=Path(record['handoff_path']).parent
            if data['handoff_protocol']['phase']=='readonly_chat_ack':
                acknowledgement=data['handoff_protocol']['acknowledgement']
                proof=verify_readonly_ack(child,acknowledgement,self.home)
                if data['handoff_protocol'].get('system_readonly_required'):
                    proof['host_sandbox']=verify_system_readonly(child,self.home)
                write_record(directory/'receipt.json',{'acknowledgement':acknowledgement,'evidence':proof})
            else:
                received=directory/'received-message.json'
                if canonical(json.loads(received.read_text(encoding='utf-8')))!=canonical(data):
                    raise ValueError('Received content transport changed.')
                proof=verify_runtime_first_action(child,data,self.home)
            record.update(phase='active',child_id=child,receipt_order=proof)
            activation={'phase':'active','runtime_identity':observed_identity,'receipt_order':proof,
                        'package_hash':task['package_hash']}
            record['resume_message']=(
                f"Parent activation verified for task {task_id} and frozen package {task['package_hash']}. "
                "Continue the same assignment using the complete frozen subscription input and originals. "
                "Follow the frozen permissions and output contract. Return the result in chat."
            )
            if data['handoff_protocol'].get('opaque_resume_echo') or data['handoff_protocol'].get('astra_readonly_resume'):
                if data['handoff_protocol'].get('opaque_resume_echo'):
                    record['opaque_resume_echo_required']=True
                if data['handoff_protocol'].get('astra_plaintext_activation_path'):
                    activation.update(task_id=task_id, continuation=record['resume_message'] +
                                      ' Use only the local sandboxed shell within the frozen review scope.',
                                      native_input_path=task['native_input_path'],
                                      native_input_sha256=task['native_input_sha256'])
                    record['astra_plaintext_activation_sha256']=sha(canonical(activation))
                    record['resume_message']='RW-REVIEW '+acknowledgement['Result']['challenge']
                else:
                    record['resume_message'] += (
                        ' Before any tool, send this entire received message verbatim as one commentary message. '
                        'Then use only the local sandboxed shell within the frozen review scope.'
                    )
            elif data['handoff_protocol'].get('sol_resume_echo') or data['handoff_protocol'].get('managed_resume_echo'):
                if data['handoff_protocol'].get('sol_resume_echo'):
                    record['sol_resume_echo_required']=True
                if data['handoff_protocol'].get('sol_plaintext_activation_path'):
                    continuation = record['resume_message']
                    if (task['native_role']=='sol_qa_subscription'
                            and data['handoff_protocol'].get('native_qa_boundary')=='review_rules_v1'):
                        protocol = data['handoff_protocol']
                        lengths = protocol.get('frozen_text_utf16_lengths')
                        slices = protocol.get('frozen_text_utf16_slices')
                        if lengths is None or slices is None:
                            package = json.loads(Path(task['native_input_path']).read_text(encoding='utf-8'))['context_package']
                            for material in package['evidence']['source_material_manifest']:
                                path = Path(material['frozen_snapshot_reference'])
                                if path.is_symlink() or not path.is_file() or sha(path.read_bytes()) != material['sha256']:
                                    raise ValueError('Historical frozen review material changed before activation.')
                            lengths = frozen_text_lengths(task['native_input_path'], package)
                            slices = frozen_text_slices(task['native_input_path'], package)
                        continuation += (
                            ' Do not read the subscription input or any long text all at once. '
                            'Use the exact lengths in frozen_text_utf16_lengths in this activation record. '
                            'Use the exact frozen_text_utf16_slices as Substring(offset,count) reads, '
                            'ending at the exact length. The strict maximum is 16000 units per slice. '
                            'Check complete delivered coverage; read only missing spans after truncation.'
                        )
                        activation['frozen_text_utf16_lengths'] = lengths
                        activation['frozen_text_utf16_slices'] = slices
                    if data['handoff_protocol'].get('astra_fallback_transport'):
                        continuation += (' This is a strictly read-only advisory review. Read only the supplied frozen '
                                         'files, make no changes, do not run generated code, use external tools or '
                                         'delegate. Return the review in chat.')
                    if data['handoff_protocol'].get('astra_material_delivery'):
                        continuation += (' Focus on the requested question and the relevant evidence. Read the '
                                         'required originals directly from the frozen manifest. Use the frozen '
                                         'Length and Substring read commands for long files and avoid rereading '
                                         'spans already received.')
                    activation.update(task_id=task_id, continuation=continuation,
                                      native_input_path=task['native_input_path'],
                                      native_input_sha256=task['native_input_sha256'])
                    record['sol_plaintext_activation_sha256']=sha(canonical(activation))
                    record['resume_message']='RW-RESUME '+acknowledgement['Result']['challenge']
                else:
                    record['resume_message'] += (
                        ' Before any tool, send this entire received message verbatim as one commentary message.'
                    )
            self.save(db,task)
            write_record(directory/'activation.json',activation)
            return {'task_id':task_id,'phase':'active','child_id':child,'receipt_order':proof,
                    'model':data['model'],'effort':data['reasoning_effort'],'resume_message':record['resume_message']}

def main():
    p=argparse.ArgumentParser();p.add_argument('action',choices=['prepare','receipt','activate']);p.add_argument('--task-id');p.add_argument('--parent');p.add_argument('--task-name');p.add_argument('--claim-file');p.add_argument('--received');p.add_argument('--child');p.add_argument('--ledger');p.add_argument('--runtime-home');p.add_argument('--project-root');args=p.parse_args()
    store=ContentDispatch(ledger_path=args.ledger,runtime_home=args.runtime_home)
    if args.action=='prepare':
        claim=json.loads(Path(args.claim_file).read_text(encoding='utf-8'))
        result=store.prepare(args.task_id,args.parent,claim['claim_token'],args.task_name,args.project_root)
    elif args.action=='receipt':result=store.receipt(args.received)
    else:
        from desktop_dispatch import runtime_identity
        result=store.activate(args.task_id,args.parent,args.child,runtime_identity(args.child,store.home))
    print(json.dumps(result,ensure_ascii=False))

if __name__=='__main__':main()

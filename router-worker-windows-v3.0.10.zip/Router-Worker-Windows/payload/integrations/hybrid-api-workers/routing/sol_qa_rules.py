"""Verify exact frozen-material operations for rule-bound native reviews."""
import base64
import binascii
import hashlib
import json
from pathlib import Path
import re

from architecture_policy import ASTRA_MANIFEST_DELIVERY, ASTRA_READ_RECEIPT, astra_parent_fallback
from receipt_order import canonical, runtime_transcript

BOUNDARY = 'review_rules_v1'
SHELL = {'Bash', 'shell_command', 'exec_command'}
PATH = r"'((?:[^']|'')*)'"
READ = re.compile(r'Get-Content -LiteralPath ' + PATH + r' -Raw(?: -Encoding UTF8)?')
SLICE = re.compile(r'\(Get-Content -LiteralPath ' + PATH + r' -Raw -Encoding UTF8\)\.Substring\(([0-9]{1,9}),([0-9]{1,5})\)')
ASTRA_SLICE = re.compile(r'\(Get-Content -LiteralPath ' + PATH + r' -Raw -Encoding UTF8\)\.Substring\(([0-9]+),([0-9]+)\)')
LENGTH = re.compile(r'\(Get-Content -LiteralPath ' + PATH + r' -Raw -Encoding UTF8\)\.Length')
OUTPUT_PRAGMA = re.compile(r'\A[ \t]*// @exec: (\{[^\r\n]+\})\r?\n')
HASH = re.compile(r'Get-FileHash -LiteralPath ' + PATH + r' -Algorithm SHA256')
EXEC = re.compile(r'\s*text\(await tools\.exec_command\((\{[\s\S]*\})\)\);?\s*')
VIEW = re.compile(r'\s*image\(\(await tools\.view_image\((\{[\s\S]*\})\)\)\.image_url\);?\s*')


def permitted_operation(tool, args, task, package):
    """Permit a single literal read/view of an exact authorized frozen path."""
    operation, path, _ = operation_details(tool, args, task, package)
    return operation, path


def operation_details(tool, args, task, package):
    """Return the checked operation, path and optional UTF-16 slice."""
    tool = tool.rsplit('.', 1)[-1]
    manifest_delivery = (astra_parent_fallback(task)
                         and package['task'].get('astra_material_delivery') == ASTRA_MANIFEST_DELIVERY)
    if tool == 'exec':
        code = args if isinstance(args, str) else args.get('code', args.get('input', '')) if isinstance(args,dict) else ''
        pragma = OUTPUT_PRAGMA.match(code) if manifest_delivery and isinstance(code, str) else None
        if pragma:
            settings = json.loads(pragma[1])
            if (set(settings) != {'max_output_tokens'} or type(settings['max_output_tokens']) is not int
                    or settings['max_output_tokens'] <= 0):
                raise ValueError('Only a literal output-budget pragma is allowed for a frozen read.')
            code = code[pragma.end():]
        match = EXEC.fullmatch(code)
        if match:
            tool, args = 'exec_command', json.loads(match[1])
        else:
            match = VIEW.fullmatch(code)
            if not match:
                raise ValueError('Sol QA requires one literal frozen-material read or view.')
            tool, args = 'view_image', json.loads(match[1])
    if not isinstance(args, dict):
        raise ValueError('Sol QA requires structured tool arguments.')
    manifest = package['evidence']['source_material_manifest']
    paths = {item['frozen_snapshot_reference']:item['media_type'] for item in manifest}
    record = task['native_dispatch']
    paths[task['native_input_path']] = 'application/json'
    paths[str(Path(record['handoff_path']).with_name('activation.json'))] = 'application/json'
    if tool == 'view_image' and set(args)=={'path'} and isinstance(args['path'],str) and paths.get(args['path'],'').startswith('image/'):
        return 'view', args['path'], None
    login_disabled = args.get('login') is False or tool == 'Bash' and 'login' not in args
    if (tool in SHELL and set(args) <= {'cmd','command','login','max_output_tokens'}
            and len({'cmd','command'} & set(args))==1 and login_disabled):
        cmd = args.get('cmd', args.get('command'))
        if isinstance(cmd, str) and not any(c in cmd for c in '\r\n‘’‚‛“”„‟'):
            if manifest_delivery:
                length = LENGTH.fullmatch(cmd)
                if length:
                    path = length[1].replace("''", "'")
                    media = paths.get(path, '')
                    if media.startswith('text/') or media == 'application/json':
                        return 'length', path, None
            slice_pattern = ASTRA_SLICE if manifest_delivery else SLICE
            match = READ.fullmatch(cmd) or slice_pattern.fullmatch(cmd)
            if match:
                path = match[1].replace("''", "'")
                media = paths.get(path, '')
                if media.startswith('text/') or media == 'application/json':
                    if len(match.groups()) == 1:
                        return 'read', path, None
                    count = int(match[3])
                    if count > 0 and (manifest_delivery or count <= 16000):
                        return 'read', path, (int(match[2]), count)
            match = HASH.fullmatch(cmd)
            if match and match[1].replace("''", "'") in paths:
                return 'hash', match[1].replace("''", "'"), None
    raise ValueError('Sol QA rules permit only exact reads, hashes or image views of supplied frozen files.')


def pending_tool_return(value):
    """Recognize transport continuation metadata without interpreting stdout as metadata."""
    if isinstance(value, list):
        return any(pending_tool_return(part) for part in value)
    if isinstance(value, dict):
        if any(value.get(key) is not None for key in ('session_id','sessionId','cell_id','cellId')):
            return True
        if value.get('status') in ('running','in_progress','pending'):
            return True
        return any(pending_tool_return(value[key]) for key in ('text','content','result') if key in value)
    if isinstance(value, str):
        text = value.lstrip()
        if text.startswith(('Script running with cell ID', 'Process running with session ID',
                            'Command running with session ID')):
            return True
        if text.startswith(('{','[')):
            try:
                return pending_tool_return(json.loads(text))
            except ValueError:
                pass
    return False


class MaterialCoverageError(ValueError):
    """A completed review lacks verified delivery for a required original."""


def successful_stdout(output):
    """Decode a full successful shell return, with the known code-mode header if present."""
    if isinstance(output, list):
        if len(output) == 2:
            header = output[0]
            if (not isinstance(header, dict) or header.get('type') not in ('input_text', 'text')
                    or not re.fullmatch(
                    r"Script completed\r?\nWall time [0-9.]+ seconds?\r?\nOutput:\r?\n",
                    header.get("text", ""))):
                return None
            output = output[1:]
        if (len(output) != 1 or not isinstance(output[0], dict)
                or output[0].get('type') not in ('input_text', 'text')):
            return None
        output = output[0].get("text")
    if isinstance(output, str):
        try:
            output = json.loads(output)
        except ValueError:
            return None
    if (not isinstance(output, dict) or type(output.get("exit_code")) is not int
            or output["exit_code"] != 0 or output.get("isError") or output.get("truncated")
            or output.get("output_truncated") or not isinstance(output.get("output"), str)):
        return None
    return output["output"]


def required_materials(package):
    """Index the immutable required snapshots without logging their contents."""
    return {item['frozen_snapshot_reference']: item
            for item in package['evidence']['source_material_manifest'] if item['required']}


def verified_image(output, sha256):
    if not isinstance(output, list):
        return False
    for item in output:
        if not isinstance(item, dict) or item.get('type') not in ('input_image', 'image'):
            continue
        url = item.get('image_url')
        match = re.fullmatch(r'data:image/[a-zA-Z0-9.+-]+;base64,(.*)', url) if isinstance(url, str) else None
        if match:
            try:
                if hashlib.sha256(base64.b64decode(match[1], validate=True)).hexdigest() == sha256:
                    return True
            except binascii.Error:
                pass
    return False


def credit_material_read(material, operation, output, observed):
    """Credit only exact content delivered by an observed, successful read."""
    if operation[0] == 'view':
        if verified_image(output, material['sha256']):
            observed['viewed'] = True
        return
    if operation[0] != 'read':
        return
    stdout = successful_stdout(output)
    if stdout is None:
        return
    if 'text' not in observed:
        raw = Path(material['frozen_snapshot_reference']).read_bytes()
        if hashlib.sha256(raw).hexdigest() != material['sha256']:
            raise MaterialCoverageError("Frozen material changed: " + material['material_id'])
        observed['text'] = raw.decode('utf-8-sig').encode('utf-16-le')
    frozen = observed['text']
    total = len(frozen) // 2
    offset, count = operation[2] or (0, total)
    if offset + count > total:
        return
    expected = frozen[offset * 2:(offset + count) * 2]
    # PowerShell appends a line ending when writing the string to stdout.
    delivered = stdout.encode('utf-16-le', errors='surrogatepass')
    if delivered in (expected, expected + b'\r\x00\n\x00', expected + b'\n\x00'):
        observed.setdefault('ranges', []).append((offset, offset + count))


def material_read_receipt(materials, observations):
    delivered = {}
    missing = {}
    for path, material in materials.items():
        record = observations.get(path, {})
        material_id = material['material_id']
        if record.get('viewed'):
            delivered[material_id] = {'sha256': material['sha256'], 'delivery': 'exact_image'}
            continue
        ranges = record.get('ranges')
        if not ranges:
            missing[material_id] = 'no verified content read'
            continue
        total = len(record['text']) // 2
        gaps = []
        end = 0
        for start, stop in sorted(ranges):
            if start > end:
                gaps.append([end, start])
            end = max(end, stop)
        if end < total:
            gaps.append([end, total])
        if gaps:
            missing[material_id] = gaps
        else:
            delivered[material_id] = {'sha256': material['sha256'], 'delivery': 'text',
                                      'utf16_units': total, 'covered': [[0, total]]}
    if missing:
        raise MaterialCoverageError("Required material delivery missing (UTF-16 ranges): " + json.dumps(missing))
    return {'format': ASTRA_READ_RECEIPT, 'materials': delivered}


def verify_material_read_receipt(package, proof):
    """Ensure formal collection received a receipt for exactly the frozen required materials."""
    receipt = proof.get('material_read_receipt') or {}
    delivered = receipt.get('materials') or {}
    materials = required_materials(package).values()
    if (receipt.get('format') != ASTRA_READ_RECEIPT
            or set(delivered) != {item['material_id'] for item in materials}):
        raise MaterialCoverageError("Missing or mismatched required-material receipt")
    for item in materials:
        entry = delivered[item['material_id']]
        expected = {'sha256': item['sha256'], 'delivery': 'exact_image'}
        if not item['media_type'].startswith('image/'):
            raw = Path(item['frozen_snapshot_reference']).read_bytes()
            total = len(raw.decode('utf-8-sig').encode('utf-16-le')) // 2
            expected.update(delivery='text', utf16_units=total, covered=[[0, total]])
        if entry != expected:
            raise MaterialCoverageError("Invalid coverage receipt for " + item['material_id'])


def observed_review_evidence(task, package, home, expected_result):
    """Bind the authorized child's completed review turn and exact submitted result."""
    transport = task['native_dispatch']
    child = transport['child_id']
    ack_turn = transport['resume_dispatch']['ack_turn_id']
    trace = runtime_transcript(child, home)
    raw = trace.read_bytes()
    calls = {}
    completed = set()
    coverage_required = (package['task'].get('astra_read_receipt') == ASTRA_READ_RECEIPT
                         and expected_result['status'] == 'completed')
    materials = required_materials(package) if coverage_required else {}
    observations = {}
    turns = []
    final = None
    terminal = False
    expected = canonical(expected_result)
    for line in raw.decode('utf-8').splitlines():
        event = json.loads(line)
        item = event.get('payload', {})
        kind = item.get('type', '')
        if event.get('type') == 'turn_context':
            turn = item.get('turn_id')
            if not turn or turn in turns or len(turns) >= 2 or not turns and turn != ack_turn:
                raise ValueError('Sol QA trace does not identify the acknowledgement and exact resumed turn.')
            turns.append(turn)
            continue
        if event.get('type') == 'event_msg' and len(turns) == 2 and kind in ('task_complete','turn_aborted','task_failed'):
            if (kind != 'task_complete' or terminal or item.get('turn_id') != turns[1]
                    or final is None or canonical(json.loads(item['last_agent_message'])) != expected):
                raise ValueError('Sol QA review turn did not complete with the exact final result.')
            terminal = True
            continue
        if event.get('type') != 'response_item':
            continue
        if kind.endswith('_call'):
            if len(turns) != 2 or final is not None or terminal:
                raise ValueError('Sol QA tool call is outside the active review turn.')
            args = item.get('input') if kind == 'custom_tool_call' else json.loads(item['arguments'])
            operation = operation_details(item.get('name',''), args, task, package)
            call_id = item.get('call_id')
            if not call_id or call_id in calls:
                raise ValueError('Sol QA trace contains an invalid tool call identifier.')
            calls[call_id] = operation
        elif kind in ('function_call_output','custom_tool_call_output'):
            call_id = item.get('call_id')
            if call_id not in calls or call_id in completed or final is not None:
                raise ValueError('Sol QA trace contains an unmatched or late tool result.')
            if pending_tool_return(item.get('output')):
                raise ValueError('Sol QA tool returned a still-running operation.')
            completed.add(call_id)
            operation = calls[call_id]
            path = operation[1]
            if path in materials:
                credit_material_read(materials[path], operation, item.get('output'),
                                     observations.setdefault(path, {}))
        elif (len(turns) == 2 and kind == 'message' and item.get('role') == 'assistant'
              and item.get('phase') == 'final_answer'):
            if final is not None or terminal or completed != calls.keys():
                raise ValueError('Sol QA final result is duplicated or precedes tool completion.')
            final = ''.join(part.get('text','') for part in item.get('content',[]))
            if canonical(json.loads(final)) != expected:
                raise ValueError('Sol QA final result differs from the submitted result.')
    if not calls or completed != calls.keys():
        raise ValueError('Sol QA tool trace is incomplete.')
    if len(turns) != 2 or final is None or not terminal:
        raise ValueError('Sol QA trace lacks a completed review turn and final result.')
    proof = {'boundary':BOUNDARY,'native_thread_id':child,'package_hash':task['package_hash'],
            'trace_sha256':hashlib.sha256(raw).hexdigest(),'observed_tool_calls':len(calls),
            'trace_prefix_bytes':len(raw),
            'completed_review_turn_id':turns[1],'review_result_sha256':hashlib.sha256(expected).hexdigest(),
            'os_isolation_claimed':False}
    if coverage_required:
        proof['material_read_receipt'] = material_read_receipt(materials, observations)
    return proof


def verify_bound_trace(proof, home):
    """Allow normal appended runtime events while verifying the collected prefix."""
    remaining = proof.get('trace_prefix_bytes')
    if type(remaining) is not int or remaining <= 0:
        raise ValueError('Sol QA evidence lacks a valid trace prefix length.')
    path = runtime_transcript(proof['native_thread_id'], home)
    actual = hashlib.sha256()
    with path.open('rb') as stream:
        while remaining:
            chunk = stream.read(min(remaining, 1024 * 1024))
            if not chunk:
                raise ValueError('Sol QA trace is shorter than its bound prefix.')
            actual.update(chunk)
            remaining -= len(chunk)
    if actual.hexdigest() != proof['trace_sha256']:
        raise ValueError('Sol QA trace changed after the Worker recorded its evidence.')

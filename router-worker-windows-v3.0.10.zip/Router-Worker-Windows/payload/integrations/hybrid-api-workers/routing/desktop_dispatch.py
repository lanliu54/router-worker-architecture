"""Two-phase desktop handoff for hosts that encrypt native spawn messages.

An opaque message never grants UI access. A frozen, complete handoff admits a
receipt-only worker; parent-verified runtime identity and a byte-equivalent
received handoff are required before activation. No decryption or model calls.
"""
import argparse
from contextlib import closing
import hashlib
import json
from pathlib import Path
import re
import sqlite3
import time

from receipt_order import verify_runtime_first_action
from closeout_contract import contract_descriptor, validate_client_closeout

ROOT = Path(__file__).resolve().parent
HOME = ROOT.parent.parent.parent


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def sha(value):
    return hashlib.sha256(value).hexdigest()


def token(value, task=False):
    pattern = r"[a-z][a-z0-9_]{0,63}" if task else r"[A-Za-z0-9-]{1,80}"
    if not isinstance(value, str) or not re.fullmatch(pattern, value):
        raise ValueError("Invalid parent identity or desktop task name.")
    return value


class DispatchStore:
    def __init__(self, root=ROOT):
        self.root = Path(root).resolve()
        self.state = self.root / "state"
        self.dbpath = self.state / "desktop-dispatch.sqlite3"

    def connect(self):
        self.state.mkdir(exist_ok=True)
        db = sqlite3.connect(self.dbpath, timeout=2)
        db.row_factory = sqlite3.Row
        db.execute("CREATE TABLE IF NOT EXISTS dispatches(parent TEXT, task_name TEXT, role TEXT, phase TEXT, handoff_path TEXT, handoff_sha256 TEXT, child_id TEXT, envelope_sha256 TEXT, created_at REAL, PRIMARY KEY(parent,task_name))")
        return db

    def find(self, parent, task):
        if not self.dbpath.is_file():
            return None
        with closing(self.connect()) as db:
            row = db.execute("SELECT * FROM dispatches WHERE parent=? AND task_name=?", (parent, task)).fetchone()
        return dict(row) if row else None

    def has_open(self, parent):
        if not self.dbpath.is_file():
            return False
        with closing(self.connect()) as db:
            return db.execute("SELECT 1 FROM dispatches WHERE parent=? AND phase IN ('prepared','dispatch_pending','active')", (parent,)).fetchone() is not None

    def read_handoff(self, row):
        p = Path(row["handoff_path"])
        expected = self.state / "desktop-handoffs" / token(row["parent"]) / token(row["task_name"], task=True) / "handoff.json"
        if p.resolve() != expected.resolve() or any(x.is_symlink() for x in [p, p.parent, p.parent.parent, p.parent.parent.parent]):
            raise ValueError("Frozen desktop handoff path is linked or outside its task directory.")
        data = json.loads(p.read_text(encoding="utf-8"))
        if sha(canonical(data)) != row["handoff_sha256"]:
            raise ValueError("Frozen desktop handoff changed; create an explicit new package version.")
        return data

    def prepare(self, parent, task, data, validate):
        token(parent); token(task, task=True)
        data = json.loads(canonical(data))
        validate(json.dumps(data))
        directory = self.state / "desktop-handoffs" / parent / task
        data["handoff_protocol"] = {
            "version": 3, "phase": "receipt_only", "parent_id": parent,
            "task_name": task, "frozen_handoff_path": str(directory / "handoff.json"),
            "received_message_path": str(directory / "received-message.json"),
            "closeout_contract": contract_descriptor(),
            "receipt_order_policy": "literal_receipt_write_first",
            "required_first_action": "Your FIRST operational tool call must ONLY add received_message_path with the complete decoded initial task JSON including handoff_protocol. Use functions.exec with exactly text(await tools.apply_patch(<literal quoted patch>)); or a direct apply_patch call. No const variables, preliminary file/skill/README reads, inventory, metadata discovery or other operations in that first call. Transcribe from the actual received message, not the frozen file. JSON whitespace and key order may differ. Then run desktop_dispatch.py receipt --received <that path> and stop. Parent activation independently checks the actual first tool call and result; earlier reads fail activation. If the payload is unavailable, report missing_context without guessing. Read UI skills only after activation and before UI."
        }
        raw = canonical(data); fingerprint = sha(raw)
        with closing(self.connect()) as db, db:
            db.execute("BEGIN IMMEDIATE")
            existing = db.execute("SELECT * FROM dispatches WHERE parent=? AND task_name=?", (parent, task)).fetchone()
            if existing:
                if existing["phase"] == "prepared" and existing["handoff_sha256"] == fingerprint:
                    self.read_handoff(dict(existing))
                    return dict(existing)
                raise ValueError("Desktop task already exists or may have executed; reconcile it instead of spawning again.")
            # Legacy grants stay reconcilable, but the v2 coordinator owns new UI.
            import sys
            sys.path.insert(0,str(self.root.parent))
            import architecture_policy
            if architecture_policy.load(self.root.parent):
                raise ValueError('New desktop worker grants are retired; the verified Terra/high main owns new UI work.')
            if db.execute("SELECT 1 FROM dispatches WHERE parent=? AND phase IN ('prepared','dispatch_pending','active')", (parent,)).fetchone():
                raise ValueError("This parent already has an unresolved desktop dispatch; reconcile before preparing another.")
            directory.mkdir(parents=True, exist_ok=False)
            p = directory / "handoff.json"
            p.write_bytes(raw)
            db.execute("INSERT INTO dispatches VALUES(?,?,?,?,?,?,?,?,?)", (parent, task, "terra_desktop_native", "prepared", str(p), fingerprint, None, None, time.time()))
        return self.find(parent, task)

    def admit_spawn(self, parent, task, message, validate):
        token(parent); token(task, task=True)
        with closing(self.connect()) as db, db:
            db.execute("BEGIN IMMEDIATE")
            row = db.execute("SELECT * FROM dispatches WHERE parent=? AND task_name=?", (parent, task)).fetchone()
            if not row or row["phase"] != "prepared":
                raise ValueError("Opaque desktop transport requires one unused prepared handoff; do not retry an uncertain dispatch.")
            data = self.read_handoff(dict(row)); validate(json.dumps(data))
            try:
                received = json.loads(message)
            except (ValueError, TypeError):
                if not isinstance(message, str) or not re.fullmatch(r"gAAAA[A-Za-z0-9_=-]+", message):
                    raise ValueError("Unsupported desktop transport; only a verified JSON handoff or the observed opaque host envelope is admitted.") from None
            else:
                if sha(canonical(received)) != row["handoff_sha256"]:
                    raise ValueError("Spawn message differs from the frozen complete handoff.")
            db.execute("UPDATE dispatches SET phase='dispatch_pending',envelope_sha256=? WHERE parent=? AND task_name=?", (sha(message.encode()), parent, task))

    def receive(self, received_path, validate):
        received_path = Path(received_path).resolve()
        received = json.loads(received_path.read_text(encoding="utf-8"))
        validate(json.dumps(received))
        protocol = received.get("handoff_protocol", {})
        row = self.find(protocol.get("parent_id"), protocol.get("task_name"))
        if not row or row["phase"] != "dispatch_pending":
            raise ValueError("No pending desktop handoff matches this receipt.")
        expected = Path(row["handoff_path"]).with_name("received-message.json")
        if received_path != expected.resolve() or received_path.is_symlink():
            raise ValueError("Receipt must use this dispatch's received-message path.")
        frozen = self.read_handoff(row)
        if canonical(received) != canonical(frozen):
            raise ValueError("Decoded received handoff differs from the frozen original.")
        receipt = {"phase": "receipt_verified", "parent_id": row["parent"], "task_name": row["task_name"], "received_sha256": sha(canonical(received)), "ui_authorized": False,
                   "first_action_order": "required_at_parent_activation" if protocol.get("version", 1) >= 2 else "legacy_v1_not_enforced"}
        received_path.with_name("receipt.json").write_bytes(canonical(receipt))
        return receipt

    def activate(self, parent, task, child, observed_identity):
        row = self.find(parent, task)
        if not row or row["phase"] != "dispatch_pending":
            raise ValueError("Only a pending receipt-only worker can be activated.")
        expected = {"id": child, "parent_id": parent, "task_name": task, "role": "terra_desktop_native", "model": "gpt-6.1-terra", "effort": "medium", "is_child": True}
        if any(observed_identity.get(k) != v for k, v in expected.items()):
            raise ValueError("Actual child identity, parent, task name, model or effort differs from the prepared route.")
        frozen = self.read_handoff(row)
        order = {"policy": "legacy_v1_not_enforced", "passed": None}
        if frozen.get("handoff_protocol", {}).get("version", 1) >= 2:
            order = verify_runtime_first_action(child, frozen, self.root.parents[2])
        received_path = Path(row["handoff_path"]).with_name("received-message.json")
        receipt = self.receive(received_path, lambda text: json.loads(text))
        self.read_handoff(row)
        received_path.with_name("receipt-order.json").write_bytes(canonical(order))
        with closing(self.connect()) as db, db:
            changed = db.execute("UPDATE dispatches SET phase='active',child_id=? WHERE parent=? AND task_name=? AND phase='dispatch_pending'", (child, parent, task)).rowcount
            if changed != 1:
                raise ValueError("Desktop dispatch changed concurrently; activation was not repeated.")
        return {**receipt, "phase": "active", "child_id": child, "runtime_identity": observed_identity, "receipt_order": order, "ui_authorized": True}

    def check_ui(self, who):
        parent, task = who.get("parent_id"), who.get("task_name")
        row = self.find(parent, task) if parent and task else None
        if row and (row["phase"] != "active" or row["child_id"] != who["id"]):
            raise ValueError("Desktop UI is locked: dispatch phase is " + row["phase"] + "; UI requires an active grant bound to this exact child.")

    def cancel_unexecuted(self, parent, task, child, observed_identity):
        """Close only a terminal pending dispatch with independently read zero-call evidence."""
        import guard
        row = self.find(parent, task)
        if not row or row["phase"] != "dispatch_pending" or row["child_id"] is not None:
            raise ValueError("Only an unactivated pending dispatch can be reconciled as unexecuted.")
        expected = {"id": child, "parent_id": parent, "task_name": task,
                    "role": "terra_desktop_native", "model": "gpt-6.1-terra",
                    "effort": "medium", "is_child": True}
        if any(observed_identity.get(k) != v for k, v in expected.items()):
            raise ValueError("Actual child identity does not match the pending native route.")
        self.read_handoff(row)
        home = self.root.parents[2]
        databases = sorted(home.glob("state_*.sqlite"), key=lambda p: int(p.stem.split("_")[-1]), reverse=True)
        if not databases:
            raise ValueError("Native terminal-state evidence is unavailable.")
        with guard.readonly(databases[0]) as db:
            native = db.execute("SELECT rollout_path FROM threads WHERE id=?", (child,)).fetchone()
        if not native:
            raise ValueError("Actual native transcript is unavailable.")
        transcript = guard.normal_path(native[0])
        if not transcript.is_relative_to(guard.normal_path(home / "sessions")):
            raise ValueError("Native transcript is outside the session directory.")
        raw = transcript.read_bytes()
        records = [json.loads(line) for line in raw.decode("utf-8").splitlines() if line.strip()]
        if not records or records[0].get("type") != "session_meta" or records[0].get("payload", {}).get("id") != child:
            raise ValueError("Native transcript identity differs from the pending child.")
        completed = -1
        for index, record in enumerate(records):
            payload = record.get("payload", {})
            typ = payload.get("type", "")
            if isinstance(typ, str) and typ.endswith("_call"):
                raise ValueError("A native tool call occurred; unexecuted cancellation is not eligible.")
            if record.get("type") == "event_msg" and typ == "task_started":
                completed = -1
            if record.get("type") == "event_msg" and typ == "task_complete":
                completed = index
            if typ == "agent_message" and index > completed:
                completed = -1
        if completed < 0:
            raise ValueError("A terminal completed native turn has not been observed.")
        fingerprint = sha(raw)
        if sha(transcript.read_bytes()) != fingerprint:
            raise ValueError("Native execution evidence changed during reconciliation.")
        evidence = {"phase": "cancelled_unexecuted", "parent_id": parent,
                    "task_name": task, "child_id": child, "native_tool_calls": 0,
                    "native_task_complete_line": completed + 1,
                    "transcript": str(transcript), "transcript_sha256": fingerprint,
                    "frozen_handoff_sha256": row["handoff_sha256"],
                    "ui_authorized": False, "original_handoff_preserved": True}
        with closing(self.connect()) as db, db:
            changed = db.execute("UPDATE dispatches SET phase='cancelled_unexecuted',child_id=? WHERE parent=? AND task_name=? AND phase='dispatch_pending' AND child_id IS NULL", (child, parent, task)).rowcount
            if changed != 1:
                raise ValueError("Pending dispatch changed concurrently; no cancellation is claimed.")
        Path(row["handoff_path"]).with_name("cancel-unexecuted.json").write_bytes(canonical(evidence))
        return evidence

    def revoke_terminal(self, parent, task, child, observed_identity, failure):
        """Revoke a completed failed probe without inventing owned-resource cleanup.

        This closes local tool authority only. It neither cancels a worker nor
        proves cleanup/release of any client state or external side effect.
        """
        import guard
        row = self.find(parent, task)
        if not row or row['phase'] not in ('active','dispatch_pending') or row['child_id'] not in (None,child):
            raise ValueError('Only this exact active or pending child dispatch can be revoked.')
        if row['phase']=='active' and row['child_id']!=child:
            raise ValueError('Active grant child identity differs.')
        expected = {'id':child,'parent_id':parent,'task_name':task,'role':'terra_desktop_native',
                    'model':'gpt-6.1-terra','effort':'medium','is_child':True}
        if any(observed_identity.get(k) != v for k,v in expected.items()):
            raise ValueError('Actual native identity differs from the active grant.')
        if not isinstance(failure.get('reason'),str) or not failure['reason'].strip() or not failure.get('evidence_references'):
            raise ValueError('Record the actual failure and parent-observed evidence.')
        home = self.root.parents[2]
        paths = sorted(home.glob('state_*.sqlite'),key=lambda p:int(p.stem.split('_')[-1]),reverse=True)
        if not paths:
            raise ValueError('Native execution database is unavailable.')
        with guard.readonly(paths[0]) as db:
            native = db.execute('SELECT rollout_path FROM threads WHERE id=?',(child,)).fetchone()
        if not native:
            raise ValueError('Native execution record is unavailable.')
        transcript = Path(native[0]).resolve()
        if not transcript.is_relative_to(home/'sessions'):
            raise ValueError('Native transcript is outside this host session store.')
        raw = transcript.read_bytes()
        records = [json.loads(line) for line in raw.splitlines() if line.strip()]
        last_start = max((i for i,r in enumerate(records) if r.get('type')=='event_msg' and r.get('payload',{}).get('type')=='task_started'),default=-1)
        last_complete = max((i for i,r in enumerate(records) if r.get('type')=='event_msg' and r.get('payload',{}).get('type')=='task_complete'),default=-1)
        if last_complete <= last_start or last_complete < 0 or any(str(r.get('payload',{}).get('type','')).endswith('_call') for r in records[last_complete+1:]):
            raise ValueError('A terminal completed native turn has not been observed.')
        if transcript.read_bytes() != raw:
            raise ValueError('Native execution changed during revocation verification.')
        self.read_handoff(row)
        evidence = {'phase':'revoked_terminal','parent_id':parent,'task_name':task,'child_id':child,
                    'prior_phase':row['phase'],'ui_grant_ever_activated':row['phase']=='active',
                    'reason':failure['reason'],'evidence_references':failure['evidence_references'],
                    'native_transcript':str(transcript),'native_transcript_sha256':sha(raw),
                    'native_terminal_line':last_complete+1,'owned_ui_cleanup_verified':False,
                    'client_control_state_exit':'not_verified','ui_authorized':False,
                    'local_authorization_close':{'status':'revoked','state_transition_verified':False},
                    'remaining_resource_state':failure.get('remaining_resource_state','not_verified')}
        with closing(self.connect()) as db, db:
            changed = db.execute("UPDATE dispatches SET phase='revoked_terminal',child_id=? WHERE parent=? AND task_name=? AND phase=? AND (child_id IS NULL OR child_id=?)",(child,parent,task,row['phase'],child)).rowcount
            if changed != 1 or db.execute('SELECT phase FROM dispatches WHERE parent=? AND task_name=?',(parent,task)).fetchone()[0]!='revoked_terminal':
                raise ValueError('Local grant revocation read-back failed.')
        evidence['local_authorization_close']['state_transition_verified']=True
        Path(row['handoff_path']).with_name('revocation.json').write_bytes(canonical(evidence))
        return evidence

    def finish(self, parent, task, child, cleanup):
        row = self.find(parent, task)
        if not row or row["phase"] != "active" or row["child_id"] != child:
            raise ValueError("No matching active desktop grant can be closed.")
        if cleanup.get("owned_ui_cleanup_verified") is not True or not cleanup.get("tool_evidence_references"):
            raise ValueError("Parent-observed tool references and owned-state cleanup verification are required.")
        frozen=self.read_handoff(row)
        if frozen.get('handoff_protocol',{}).get('version',1)>=3:
            descriptor=frozen['handoff_protocol'].get('closeout_contract')
            if not isinstance(descriptor,dict):
                raise ValueError('Frozen closeout descriptor is missing.')
            validation=validate_client_closeout(cleanup,descriptor)
            client_exit='not_exposed' if validation['explicit_release_status']=='not_applicable' else 'not_verified'
        else:
            if cleanup.get("client_control_state_exit") not in ("verified", "not_exposed", "not_verified"):
                raise ValueError("Record client control-state exit separately from owned-window cleanup.")
            validation={'contract_version':0,'policy':'legacy_frozen_contract_not_reassessed','records_separated':False}
            client_exit=cleanup['client_control_state_exit']
        with closing(self.connect()) as db, db:
            changed=db.execute("UPDATE dispatches SET phase='completed' WHERE parent=? AND task_name=? AND phase='active' AND child_id=?", (parent, task, child)).rowcount
            if changed!=1:
                raise ValueError('Dispatch changed concurrently; no closure is claimed for this caller.')
            observed=db.execute('SELECT phase,child_id FROM dispatches WHERE parent=? AND task_name=?',(parent,task)).fetchone()
            if tuple(observed)!=('completed',child):
                raise ValueError('Local authorization closure read-back failed.')
        local={'status':'closed','phase':'completed','parent_id':parent,'task_name':task,'child_id':child,'state_transition_verified':True}
        result={**cleanup,'client_control_state_exit':client_exit,'closeout_validation':validation,
                'local_authorization_close':local,"phase":"completed","child_id":child,"ui_authorized":False}
        # A later artifact-write failure must never reopen a closed UI grant.
        Path(row['handoff_path']).with_name('closeout.json').write_bytes(canonical(result))
        return result


def runtime_identity(child, home=HOME):
    import guard
    paths = sorted(Path(home).glob("state_*.sqlite"), key=lambda p: int(p.stem.split("_")[-1]), reverse=True)
    if not paths:
        raise ValueError("Runtime identity database unavailable.")
    with guard.readonly(paths[0]) as db:
        row = db.execute("SELECT rollout_path,model FROM threads WHERE id=?", (child,)).fetchone()
    if not row:
        raise ValueError("Child runtime metadata unavailable.")
    return guard.identity({"transcript_path": row[0], "model": row[1]}, Path(home))


def main():
    import guard
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=["prepare", "receipt", "activate", "finish", "inspect", "cancel-unexecuted", "revoke-terminal"])
    parser.add_argument("--parent"); parser.add_argument("--task-name")
    parser.add_argument("--handoff"); parser.add_argument("--received")
    parser.add_argument("--child"); parser.add_argument("--cleanup")
    args = parser.parse_args(); store = DispatchStore()
    if args.action == "prepare":
        data = json.loads(Path(args.handoff).read_text(encoding="utf-8"))
        result = store.prepare(args.parent, args.task_name, data, guard.desktop_handoff)
    elif args.action == "receipt":
        result = store.receive(args.received, guard.desktop_handoff)
    elif args.action == "activate":
        result = store.activate(args.parent, args.task_name, args.child, runtime_identity(args.child))
    elif args.action == "cancel-unexecuted":
        result = store.cancel_unexecuted(args.parent, args.task_name, args.child, runtime_identity(args.child))
    elif args.action == "revoke-terminal":
        result = store.revoke_terminal(args.parent, args.task_name, args.child, runtime_identity(args.child), json.loads(Path(args.cleanup).read_text(encoding="utf-8")))
    elif args.action == "finish":
        result = store.finish(args.parent, args.task_name, args.child, json.loads(Path(args.cleanup).read_text(encoding="utf-8")))
    else:
        result = store.find(args.parent, args.task_name)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

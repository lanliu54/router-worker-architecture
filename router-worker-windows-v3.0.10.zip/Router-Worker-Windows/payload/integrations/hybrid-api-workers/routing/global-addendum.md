<!-- BEGIN HYBRID_ROUTING_OWNERSHIP_V1 -->
## Session identity and ownership

- The actual Terra/high root owns intent, task classification, UI, vision, writing, integration, acceptance and delivery. Verify the live model and effort for role-restricted actions. Desktop and browser work require supported tools, the applicable UI guidance and the exclusive main UI lease.
- Workers stay within their named role, authorized workspace and assigned effects. The owning root verifies changes and evidence and makes the acceptance decision. Workers return to the parent without recursive dispatch.
- Reconcile relevant active claims and UI leases before changing ownership. Treat Hook callbacks as evidence of observed events. Review-only child instructions operate within inherited host permissions.
<!-- END HYBRID_ROUTING_OWNERSHIP_V1 -->

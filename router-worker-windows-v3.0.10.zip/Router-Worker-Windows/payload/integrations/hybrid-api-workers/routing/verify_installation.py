"""Discover installed hook definitions without model inference or trust mutation."""
import json
from pathlib import Path
import queue
import subprocess
import threading
import time
import tomllib


def verify(cli, home, directories):
    config = tomllib.loads((home / "config.toml").read_text(encoding="utf-8"))
    args = [str(cli)]
    for name in config.get("mcp_servers", {}):
        args += ["-c", f"mcp_servers.{name}.enabled=false"]
    for name in config.get("plugins", {}):
        args += ["-c", "plugins." + json.dumps(name) + ".enabled=false"]
    process = subprocess.Popen(args + ["app-server", "--stdio"], cwd=directories[0], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding="utf-8")
    messages = queue.Queue()
    def reader():
        for line in process.stdout:
            try:
                messages.put(json.loads(line))
            except ValueError:
                pass  # Diagnostic transport lines are not protocol responses.
    threading.Thread(target=reader, daemon=True).start()
    threading.Thread(target=lambda: list(process.stderr), daemon=True).start()
    def send(identifier, method, params):
        process.stdin.write(json.dumps({"id": identifier, "method": method, "params": params}) + "\n")
        process.stdin.flush()
    def receive(identifier):
        deadline = time.time() + 30
        while time.time() < deadline:
            response = messages.get(timeout=max(0.1, deadline - time.time()))
            if response.get("id") == identifier:
                return response
        raise RuntimeError("Hook discovery timeout")
    try:
        send(1, "initialize", {"clientInfo": {"name": "hybrid-routing-verifier", "version": "1.0.0"}, "capabilities": {"experimentalApi": True}})
        if "result" not in receive(1):
            raise RuntimeError("Could not initialize fresh local client")
        process.stdin.write(json.dumps({"method": "initialized", "params": {}}) + "\n")
        process.stdin.flush()
        send(2, "hooks/list", {"cwds": [str(path) for path in directories]})
        return receive(2)
    finally:
        process.stdin.close()
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.terminate()
            process.wait(timeout=5)


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--cli", required=True)
    parser.add_argument("--directory", action="append", required=True)
    args = parser.parse_args()
    print(json.dumps(verify(Path(args.cli), Path.home() / ".codex", [Path(p) for p in args.directory]), ensure_ascii=False))

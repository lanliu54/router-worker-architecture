"""Stable Hook entrypoint for the installed Router-Worker source."""
import argparse
import json
from pathlib import Path
import re
import sys
import sqlite3
import queue
import threading

from host_context import JS_NON_CODE, WRAPPERS, identity, interpolated_templates, is_astra_host, readonly

ROUTING_MATCHER=r'(?i)(^Agent$|spawn_agent$|followup_task$|mcp__.*(cua_repl|node_repl|browser|computer|hybrid_api_workers).*|^(functions[.])?exec$|^(?:mcp__codex_app__)?(?:open_in_codex|navigate_to_codex_page)$)'
EVENTS=('SessionStart','SubagentStart','PreToolUse','PostToolUse','SubagentStop','Stop')

def deny(reason):return {'hookSpecificOutput':{'hookEventName':'PreToolUse','permissionDecision':'deny','permissionDecisionReason':reason}}

def combine(left,right,event):
    if event=='PreToolUse':
        for value in (left,right):
            if value.get('hookSpecificOutput',{}).get('permissionDecision')=='deny':return value
    result={}
    messages=[v['systemMessage'] for v in (left,right) if v.get('systemMessage')]
    if messages:result['systemMessage']='\n'.join(messages)
    contexts=[v.get('hookSpecificOutput',{}).get('additionalContext') for v in (left,right)]
    contexts=[c for c in contexts if c]
    if contexts:result['hookSpecificOutput']={'hookEventName':event,'additionalContext':'\n'.join(contexts)}
    return result

def bounded(handler,payload,seconds):
    result=queue.Queue(maxsize=1)
    def work():
        try:result.put((True,handler(payload)))
        except Exception as error:result.put((False,type(error).__name__))
    threading.Thread(target=work,daemon=True).start()
    try:ok,value=result.get(timeout=seconds)
    except queue.Empty:raise TimeoutError('Hook component exceeded its local deadline') from None
    if not ok:raise RuntimeError('Hook component failed')
    return value

def dispatch(payload,guard,bridge,*,guard_timeout=5,bridge_timeout=2):
    event=payload.get('hook_event_name') or payload.get('event_name')
    if event not in EVENTS:raise ValueError('Unsupported Hook event')
    legacy=event=='SessionStart' or event in ('PreToolUse','PostToolUse') and (
        payload.get('model') in ('gpt-6-astra','gpt-6.1-terra','gpt-6.1-sol','gpt-6-luna') or re.search(ROUTING_MATCHER,payload.get('tool_name','')))
    left={}
    if legacy:
        try:
            left=bounded(guard,payload,guard_timeout)
            if not isinstance(left,dict):raise ValueError('Invalid guard output')
        except Exception:
            if event=='PreToolUse':return deny('Routing guard unavailable; controlled execution remains blocked.')
            left={'systemMessage':'Routing audit/context unavailable; do not claim complete evidence.'}
    if event=='PreToolUse' and left.get('hookSpecificOutput',{}).get('permissionDecision')=='deny':return left
    try:
        right=bounded(bridge,payload,bridge_timeout)
        if not isinstance(right,dict):raise ValueError('Invalid bridge output')
    except Exception:
        right=deny('Controller policy unavailable; execution remains blocked.') if event=='PreToolUse' else {'systemMessage':'Controller event bridge unavailable; acceptance gates remain pending.'}
    return combine(left,right,event)

LOCAL_TOOLS = {"apply_patch", "exec_command", "write_stdin", "read_file", "view_image"}
LOCAL_TOOL_CALL = re.compile(r"\btools\s*\.\s*(?:" + "|".join(sorted(LOCAL_TOOLS)) + r")\s*\(")


def local_call(payload):
    tool = payload.get("tool_name")
    if tool in LOCAL_TOOLS:
        return True
    if tool not in WRAPPERS:
        return False
    args = payload.get("tool_input")
    code = args.get("code", args.get("input")) if isinstance(args, dict) else args
    if not isinstance(code, str) or next(interpolated_templates(code), None) is not None:
        return False
    visible = JS_NON_CODE.sub(" ", code)
    calls = list(LOCAL_TOOL_CALL.finditer(visible))
    return bool(calls) and re.search(r"\btools\b", LOCAL_TOOL_CALL.sub(" ", visible)) is None


def independent_local_call(payload, home, runtime):
    """Use host identity and durable bindings before importing mutable routing code."""
    if not local_call(payload):
        return False
    try:
        who = identity(payload, home)
        if who["is_child"] or who["role"] or who["id"] != payload.get("session_id"):
            return False
        if is_astra_host(who, home):
            return False
        database = Path(runtime) / "state.sqlite"
        if not database.is_file():
            return True
        with readonly(database) as connection:
            return connection.execute(
                "SELECT 1 FROM controller_settings WHERE key=?",
                ("session_binding:" + who["id"],),
            ).fetchone() is None
    except (OSError, ValueError, KeyError, TypeError, sqlite3.Error):
        return False


def handle(payload, runtime, home):
    event = payload.get("hook_event_name") or payload.get("event_name")
    if event in ("PreToolUse", "PostToolUse") and independent_local_call(payload, home, runtime):
        return {}

    try:
        sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "orchestrator-control"))
        from launch import use_source
        source = use_source()
        import guard
        from orchestrator.hooks import handle as controller_hook

        def bridge(actual_event):
            def primary_check(bound_event):
                import architecture_policy
                policy = architecture_policy.load(Path(__file__).resolve().parents[1])
                return architecture_policy.is_primary(guard.identity(bound_event), policy)

            return controller_hook(runtime, actual_event, primary_identity_check=primary_check)

        result = dispatch(payload, guard.handle, bridge)
        if event == "SessionStart":
            source_message = f"Router-Worker controller source: {source}."
            messages = (result.get("systemMessage"), source_message)
            result["systemMessage"] = " ".join(message for message in messages if message)
        return result
    except Exception:
        if event == "PreToolUse":
            return deny("Router-Worker policy unavailable for this call. Unbound main-session local repair remains available.")
        return {"systemMessage": "Router-Worker Hook unavailable for this event. Use local checks before restarting."}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--runtime", required=True, type=Path)
    args = parser.parse_args()
    home = Path(__file__).resolve().parents[3]
    try:
        raw = sys.stdin.buffer.read(1024 * 1024 + 1)
        if len(raw) > 1024 * 1024:
            raise ValueError("Oversized Hook input")
        payload = json.loads(raw)
        result = handle(payload, args.runtime, home)
    except (ValueError, AttributeError, TypeError):
        result = deny("Router-Worker Hook input could not be validated.")
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()

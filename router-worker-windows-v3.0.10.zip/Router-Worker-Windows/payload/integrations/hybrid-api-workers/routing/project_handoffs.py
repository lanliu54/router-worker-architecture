"""Initialize the managed project's handoff root and parent-session directory."""

import argparse
from contextlib import closing
import json
from pathlib import Path
import re
import sqlite3
import stat


def safe_component(value):
    if not isinstance(value, str) or not re.fullmatch(r'[a-zA-Z0-9][a-zA-Z0-9_-]{0,79}', value):
        raise ValueError('Invalid handoff directory identifier.')
    if re.fullmatch(r'CON|PRN|AUX|NUL|COM[0-9]|LPT[0-9]', value, re.I):
        raise ValueError('Reserved handoff directory identifier.')
    return value


def check_directory(path):
    info = path.lstat()
    if (not stat.S_ISDIR(info.st_mode) or path.is_symlink()
            or getattr(info, 'st_file_attributes', 0) & stat.FILE_ATTRIBUTE_REPARSE_POINT):
        raise ValueError(f'Handoff directory must be a regular directory: {path}')


def project_handoffs(project_root, session_id=None, *, create=True):
    project = Path(project_root)
    if not project.is_absolute():
        raise ValueError('Supply the absolute managed project root.')
    project = project.resolve(strict=True)
    if not project.is_dir():
        raise ValueError('Project root is not a directory.')
    parts = ['.codex', 'handoffs']
    if session_id is not None:
        parts.append(safe_component(session_id))
    for part in parts:
        project = project / part
        if create:
            project.mkdir(exist_ok=True)
        check_directory(project)
    return project


def workspace_for_session(runtime_home, session_id):
    """Read the current work directory from the host's exact thread record."""
    safe_component(session_id)
    databases=sorted(Path(runtime_home).glob('state_*.sqlite'),
                     key=lambda p:int(p.stem.split('_')[-1]),reverse=True)
    if not databases:
        return None
    with closing(sqlite3.connect(databases[0].as_uri()+'?mode=ro',uri=True,timeout=2)) as db:
        row=db.execute('SELECT cwd FROM threads WHERE id=?',(session_id,)).fetchone()
    if not row or not row[0]:
        return None
    raw=row[0]
    if raw.startswith('\\\\?\\UNC\\'):
        raw='\\\\'+raw[8:]
    elif raw.startswith('\\\\?\\'):
        raw=raw[4:]
    cwd=Path(raw)
    if not cwd.is_absolute() or not cwd.is_dir():
        return None
    return cwd.resolve(strict=True)


def project_for_session(runtime_home, session_id):
    """Find the nearest registered project from the host's owning thread record."""
    cwd = workspace_for_session(runtime_home, session_id)
    if cwd is None:
        return None
    for parent in (cwd,*cwd.parents):
        marker=parent/'.codex/project-management/index.json'
        if not marker.is_file() or marker.is_symlink():
            continue
        data=json.loads(marker.read_text(encoding='utf-8'))
        if data.get('project',{}).get('root')=='.':
            return parent
    return None


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project-root', required=True)
    parser.add_argument('--session-id')
    args = parser.parse_args()
    print(project_handoffs(args.project_root, args.session_id))

"""Verify a literal receipt-write first action from actual runtime records.

This verifies a bounded workflow, not arbitrary JavaScript safety. No code is
evaluated, no transcripts are modified, and no UI is called.
"""
import ast
import hashlib
import json
from pathlib import Path
import re


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def activation_read_code(path):
    """The only first tool action for newly frozen plaintext-activation claims."""
    quoted = str(path).replace("'", "''")
    args = {'cmd': "Get-Content -LiteralPath '" + quoted + "' -Raw", 'login': False}
    return 'text(await tools.exec_command(' + json.dumps(args, ensure_ascii=False, separators=(',', ':')) + '));'


def verify_activation_first_read(transcript, turn_id, dispatch, *, allow_pending=False):
    activation = dispatch['plaintext_activation']
    path = Path(activation['handoff_path']).parent / 'activation.json'
    expected_code = activation_read_code(path)
    active = False; first = None; result = None
    with Path(transcript).open(encoding='utf-8') as stream:
        for line_number, raw in enumerate(stream, 1):
            event = json.loads(raw); item = event.get('payload', {})
            if event.get('type') == 'turn_context':
                active = item.get('turn_id') == turn_id
            if not active or event.get('type') != 'response_item':
                continue
            if first is None and item.get('type') in ('function_call', 'custom_tool_call'):
                first = item
            elif first is not None and item.get('type') in ('function_call', 'custom_tool_call'):
                raise ValueError('Another tool cannot run before the first activation read completes.')
            elif first is not None and item.get('type') in ('function_call_output', 'custom_tool_call_output') and item.get('call_id') == first.get('call_id'):
                result = item
                break
    code = first.get('input', first.get('arguments')) if first else None
    if first is None or first.get('name') not in ('exec', 'functions.exec') or not isinstance(code, str) or code.strip() != expected_code:
        raise ValueError('The first native tool must perform the exact activation-file read.')
    if result is None:
        if allow_pending:
            return
        raise ValueError('The first activation-file read has no completed output.')
    if result.get('isError') or failed_output(result.get('output')):
        raise ValueError('The first activation-file read failed.')
    output = result.get('output')
    blocks = output if isinstance(output, list) else [output]
    decoded = []
    for block in blocks:
        value = block.get('text') if isinstance(block, dict) else block
        if not isinstance(value, str):
            continue
        try:
            value = json.loads(value)
        except ValueError:
            continue
        if isinstance(value, dict) and value.get('exit_code') == 0 and isinstance(value.get('output'), str):
            try:
                decoded.append(json.loads(value['output']))
            except ValueError:
                pass
    hash_field = 'astra_plaintext_activation_sha256' if 'astra_plaintext_activation_sha256' in activation else 'sol_plaintext_activation_sha256'
    if len(decoded) != 1 or hashlib.sha256(canonical(decoded[0])).hexdigest() != activation[hash_field]:
        raise ValueError('The first read output does not match the frozen activation file.')
    return line_number


def literal_patch(first):
    name = first.get("name", "")
    raw = first.get("input", first.get("arguments", ""))
    if name in ("apply_patch", "functions.apply_patch") and isinstance(raw, str):
        return raw
    if name not in ("exec", "functions.exec") or not isinstance(raw, str):
        raise ValueError("Receipt first action must be the single literal apply_patch write.")
    code = raw.strip().removesuffix(";").strip()
    if code.startswith("text(") and code.endswith(")"):
        code = code[5:-1].strip()
    match = re.fullmatch(r'''await\s+tools\s*\.\s*apply_patch\s*\(\s*("(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*')\s*\)''', code, re.S)
    if not match:
        raise ValueError("Receipt first tool must only call apply_patch with a literal patch; no preliminary reads or other code.")
    value = ast.literal_eval(match.group(1))
    if not isinstance(value, str):
        raise ValueError("Receipt patch literal is not text.")
    return value


def failed_output(value):
    if isinstance(value, dict):
        return value.get("isError") is True or any(failed_output(x) for x in value.values())
    if isinstance(value, list):
        return any(failed_output(x) for x in value)
    if isinstance(value, str):
        if any(x in value for x in ("Script error:", "Script failed", "Tool call blocked", "apply_patch verification failed")):
            return True
        try:
            decoded = json.loads(value)
        except (ValueError, TypeError):
            return False
        return not isinstance(decoded, str) and failed_output(decoded)
    return False


def inspect_first_action(transcript, expected):
    first = None; first_line = None; result = None; result_line = None
    with Path(transcript).open(encoding="utf-8") as stream:
        for line, raw in enumerate(stream, 1):
            p = json.loads(raw).get("payload", {})
            typ = p.get("type")
            if first is None and typ in ("function_call", "custom_tool_call"):
                first = p; first_line = line
            elif first is not None and typ in ("function_call_output", "custom_tool_call_output") and p.get("call_id") == first.get("call_id"):
                result = p; result_line = line; break
    if first is None or result is None:
        raise ValueError("Actual first receipt-write call and its result are required before activation.")
    patch = literal_patch(first)
    lines = patch.splitlines()
    if len(lines) < 4 or lines[0] != "*** Begin Patch" or not lines[1].startswith("*** Add File: ") or lines[-1] != "*** End Patch" or not all(x.startswith("+") for x in lines[2:-1]):
        raise ValueError("Receipt first patch must add only the received-message JSON file.")
    target = Path(lines[1][len("*** Add File: "):]).resolve()
    required = Path(expected["handoff_protocol"]["received_message_path"]).resolve()
    if target != required:
        raise ValueError("Receipt first write targeted a different file.")
    decoded = json.loads("\n".join(x[1:] for x in lines[2:-1]))
    if canonical(decoded) != canonical(expected):
        raise ValueError("The first literal receipt write did not contain the complete frozen handoff.")
    output = json.dumps(result.get("output"), ensure_ascii=False)
    if result.get("isError") or failed_output(result.get("output")):
        raise ValueError("The actual first receipt-write tool returned a failure.")
    return {"policy": "literal_receipt_write_first", "passed": True,
            "transcript": str(Path(transcript).resolve()), "first_call_id": first.get("call_id"),
            "first_call_line": first_line, "first_result_line": result_line,
            "literal_context_sha256": hashlib.sha256(canonical(decoded)).hexdigest(),
            "first_result_sha256": hashlib.sha256(output.encode("utf-8")).hexdigest()}


def runtime_transcript(child, home):
    import guard
    paths = sorted(Path(home).glob("state_*.sqlite"), key=lambda p: int(p.stem.split("_")[-1]), reverse=True)
    if not paths:
        raise ValueError("Native metadata for receipt-order verification is unavailable.")
    with guard.readonly(paths[0]) as db:
        row = db.execute("SELECT rollout_path FROM threads WHERE id=?", (child,)).fetchone()
    if not row:
        raise ValueError("Actual child transcript for receipt-order verification is unavailable.")
    path = guard.normal_path(row[0])
    if not path.is_relative_to(guard.normal_path(Path(home) / "sessions")):
        raise ValueError("Receipt-order transcript is outside the native session directory.")
    with path.open(encoding="utf-8") as stream:
        meta = json.loads(stream.readline())
    if meta.get("type") != "session_meta" or meta.get("payload", {}).get("id") != child:
        raise ValueError("Receipt-order transcript identity differs from the actual child.")
    return path


def verify_runtime_first_action(child, expected, home):
    return inspect_first_action(runtime_transcript(child, home), expected)


def verify_system_readonly(child, home):
    """Read effective host policy records for the exact native child."""
    transcript = runtime_transcript(child, home)
    turns = []
    with transcript.open(encoding='utf-8') as stream:
        for raw in stream:
            event = json.loads(raw)
            if event.get('type') != 'turn_context':
                continue
            context = event['payload']
            policy = context.get('sandbox_policy', {})
            permissions = context.get('permission_profile') or {}
            filesystem = permissions.get('file_system') or {}
            entries = filesystem.get('entries') or []
            if (policy.get('type') != 'read-only' or policy.get('network_access', False)
                    or context.get('approval_policy') != 'never' or not context.get('turn_id')
                    or permissions.get('type') != 'managed' or permissions.get('network') != 'restricted'
                    or filesystem.get('type') != 'restricted' or not entries
                    or any(entry.get('access') != 'read' for entry in entries)):
                raise ValueError('Native Astra requires a host-enforced read-only sandbox with no escalation.')
            turns.append(context['turn_id'])
    if not turns:
        raise ValueError('Actual native sandbox policy is unavailable.')
    return {'policy':'read-only','approval_policy':'never','turn_ids':turns}


def verify_resume_echo(child, message, dispatch, home, *, allow_pending_read=False):
    """Bind the resumed read-only turn to the admitted transport and actual echo."""
    proof=verify_system_readonly(child,home)
    if len(proof['turn_ids'])!=2:
        raise ValueError('Expected the acknowledgement turn and exactly one resumed read-only turn.')
    if 'plaintext_activation' in dispatch:
        from content_dispatch import verify_plaintext_activation
        verify_plaintext_activation(dispatch['plaintext_activation'],'astra_plaintext_activation_sha256')
    transcript=runtime_transcript(child,home)
    version=dispatch.get('plaintext_first_read_version')
    bound_read=version==2
    if bound_read and (dispatch.get('ack_turn_id')!=proof['turn_ids'][0] or not dispatch.get('recipient')
                       or not dispatch.get('plaintext_activation')):
        raise ValueError('The read-only wake is missing its verified acknowledgement or activation binding.')
    inspect_resume_echo(transcript, proof['turn_ids'][-1], message, dispatch, require_echo=not bound_read)
    if version in (1,2):
        verify_activation_first_read(transcript, proof['turn_ids'][-1], dispatch, allow_pending=allow_pending_read)
    return proof


def native_turn_ids(child, home):
    with runtime_transcript(child,home).open(encoding='utf-8') as stream:
        return [event['payload']['turn_id'] for event in map(json.loads,stream)
                if event.get('type')=='turn_context']


def is_parent_message(event, item, recipient, dispatch):
    """Recognize a host-routed in-turn message without interpreting its payload."""
    metadata = event.get('metadata')
    if (dispatch['transport'] != 'opaque' or not isinstance(recipient, str)
            or not recipient.startswith('/root/') or item.get('recipient') != recipient
            or item.get('author') != '/root'
            or not isinstance(metadata, dict) or metadata.get('client_authored') is not False):
        return False
    parts = item.get('content')
    if not isinstance(parts, list) or len(parts) != 2 or not all(isinstance(p, dict) for p in parts):
        return False
    header = f'Message Type: MESSAGE\nTask name: {recipient}\nSender: /root\nPayload:\n'
    envelope = parts[1].get('encrypted_content')
    return (parts[0] == {'type': 'input_text', 'text': header}
            and parts[1].get('type') == 'encrypted_content'
            and isinstance(envelope, str)
            and re.fullmatch(r'gAAAA[A-Za-z0-9_=-]{1,131072}', envelope) is not None
            and hashlib.sha256(envelope.encode()).hexdigest() != dispatch['envelope_sha256'])


def inspect_resume_echo(transcript, turn_id, message, dispatch, *, activation_read_line=None, require_echo=True):
    delivered=False
    echo=False
    resumed=False
    recipient=None
    with transcript.open(encoding='utf-8') as stream:
        for line_number, raw in enumerate(stream, 1):
            event=json.loads(raw)
            item=event.get('payload',{})
            if event.get('type')=='turn_context':
                resumed=item.get('turn_id')==turn_id
            if not resumed or event.get('type')!='response_item':
                continue
            if item.get('type')=='agent_message':
                # A later parent message neither supplies nor replaces the one-use wake.
                if (echo and activation_read_line is not None and line_number > activation_read_line
                        and is_parent_message(event, item, recipient, dispatch)):
                    continue
                if delivered or item.get('author')!='/root':
                    raise ValueError('Unexpected native resume sender or duplicate delivery.')
                if not require_echo and (item.get('recipient')!=dispatch['recipient']
                                         or (event.get('metadata') or {}).get('client_authored') is not False):
                    raise ValueError('Read-only wake delivery must be from the host to the bound child.')
                if dispatch['transport']=='opaque':
                    envelopes=[part.get('encrypted_content','') for part in item.get('content',[])
                               if part.get('type')=='encrypted_content']
                    delivered=(len(envelopes)==1
                               and hashlib.sha256(envelopes[0].encode()).hexdigest()==dispatch['envelope_sha256'])
                else:
                    parts=[part.get('text','') for part in item.get('content',[]) if isinstance(part,dict)]
                    delivered=(''.join(parts)==message) if dispatch.get('plaintext_first_read_version') in (1,2) else True
                if not delivered:
                    raise ValueError('Delivered opaque resume differs from the admitted envelope.')
                recipient=item.get('recipient')
            if require_echo and not echo and item.get('type')=='message' and item.get('role')=='assistant':
                actual=''.join(part.get('text','') for part in item.get('content',[]))
                if not delivered or actual.removesuffix('\n')!=message or item.get('phase')!='commentary':
                    raise ValueError('Native resume echo does not match the frozen continuation.')
                echo=True
            if (not delivered or require_echo and not echo) and item.get('type','').endswith('_call'):
                raise ValueError('Native tools require their verified resume delivery first.')
    if not delivered or require_echo and not echo:
        raise ValueError('Actual native resume delivery or required echo is unavailable.')


def verify_sol_resume_echo(child, message, dispatch, home, *,
                           allow_pending_read=False, allow_parent_messages=False):
    turns=native_turn_ids(child,home)
    if len(turns)!=2 or turns[0]!=dispatch['ack_turn_id'] or turns[1]==turns[0]:
        raise ValueError('Expected the bound acknowledgement and exactly one resumed Sol turn.')
    transcript=runtime_transcript(child,home)
    activation_read_line=None
    if dispatch.get('plaintext_first_read_version') == 1:
        activation_read_line=verify_activation_first_read(transcript, turns[1], dispatch,
                                                          allow_pending=allow_pending_read)
    inspect_resume_echo(transcript, turns[1], message, dispatch,
                        activation_read_line=activation_read_line if allow_parent_messages else None)


def verify_readonly_ack(child, expected, home):
    """Verify the first assistant reply directly from the child's runtime transcript."""
    transcript = runtime_transcript(child, home)
    proof = None
    completed = False
    with transcript.open(encoding='utf-8') as stream:
        for line_number, raw in enumerate(stream, 1):
            event = json.loads(raw)
            if event.get('type') == 'event_msg' and event.get('payload', {}).get('type') == 'task_complete':
                if proof is not None:
                    if completed:
                        raise ValueError('The child ran another turn before activation.')
                    completed = True
                    continue
                raise ValueError('Astra ended its first turn without the frozen acknowledgement.')
            if event.get('type') != 'response_item':
                continue
            item = event.get('payload', {})
            if item.get('type', '').endswith('_call'):
                raise ValueError('The child must acknowledge the handoff and await activation before calling tools.')
            if item.get('type') != 'message' or item.get('role') != 'assistant':
                continue
            message = ''.join(part.get('text', '') for part in item.get('content', []))
            if proof is not None or canonical(json.loads(message)) != canonical(expected):
                raise ValueError('Astra acknowledgement differs from the frozen challenge.')
            proof = {'policy':'readonly_chat_ack', 'passed':True, 'transcript':str(transcript),
                     'message_line':line_number, 'ack_sha256':hashlib.sha256(canonical(expected)).hexdigest()}
    if not completed:
        raise ValueError('A completed acknowledgement-only turn is required before activation.')
    return proof

"""Read-only native-desktop IAB preflight. Never changes browser/session state."""
import argparse
import json
from pathlib import Path
import sys

from desktop_dispatch import runtime_identity


def assess_binding(identity, inventory, parent_id):
    expected = {"role":"terra_desktop_native", "model":"gpt-6.1-terra", "effort":"medium", "is_child":True, "parent_id":parent_id}
    if not identity.get("id") or any(identity.get(k) != v for k,v in expected.items()):
        return {"ready":False, "reason":"native_identity_or_parent_mismatch"}
    browsers = inventory.get("browsers") if isinstance(inventory, dict) else None
    if not isinstance(browsers, list) or not all(isinstance(b,dict) for b in browsers):
        return {"ready":False, "reason":"invalid_inventory"}
    candidates = [b for b in browsers if b.get("type")=="iab" and isinstance(b.get("metadata"),dict) and b["metadata"].get("codexSessionId")==identity["id"] and isinstance(b.get("id"),str) and b["id"].strip()]
    if not candidates:
        return {"ready":False, "reason":"no_iab_for_actual_child_session", "actual_thread_id":identity["id"], "available_backend_types":sorted({str(b.get("type")) for b in browsers}), "next_action":"Use supported app lifecycle for the same child if authorized, refresh discovery, then recheck. Do not borrow the parent session or silently switch the UI owner."}
    if len(candidates)!=1:
        return {"ready":False, "reason":"ambiguous_matching_iab_backends", "actual_thread_id":identity["id"], "candidate_ids":[b["id"] for b in candidates]}
    browser = candidates[0]
    return {"ready":True, "browser_id":browser["id"], "backend_type":"iab", "actual_thread_id":identity["id"], "metadata_codexSessionId":browser["metadata"]["codexSessionId"], "role":identity["role"], "model":identity["model"], "effort":identity["effort"], "scope":"Current captured inventory and independently resolved native identity only; no UI call or permission change performed."}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--thread-id",required=True)
    parser.add_argument("--parent-id",required=True)
    parser.add_argument("--inventory",type=Path,required=True)
    parser.add_argument("--output",type=Path)
    args=parser.parse_args()
    who=runtime_identity(args.thread_id)
    inventory=json.loads(args.inventory.read_text(encoding="utf-8"))
    result=assess_binding(who,inventory,args.parent_id)
    text=json.dumps(result,ensure_ascii=False,indent=2)
    if args.output:
        args.output.write_text(text,encoding="utf-8")
    print(text)
    if not result["ready"]:sys.exit(2)


if __name__=="__main__":main()

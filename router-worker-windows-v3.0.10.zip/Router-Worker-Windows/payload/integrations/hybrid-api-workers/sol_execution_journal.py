"""Use the existing worker task ledger for a single Sol execution attempt."""
import hashlib
import json
import re
import time
from copy import deepcopy
import api_balance


class JournalError(Exception):
    pass


def safe_id(value):
    return value if isinstance(value, str) and re.fullmatch(r'[A-Za-z0-9_.:-]{1,160}', value) else None


def compact_rounds(task):
    keys = ('attempt', 'number', 'state', 'phase', 'started_at', 'elapsed_seconds',
            'client_request_id', 'provider_request_id', 'http_status', 'error_type',
            'response_id', 'observed_usage', 'observed_cost_micro_usd')
    return [{k: r[k] for k in keys if k in r} for r in task.get('execution_loop', {}).get('rounds', [])]


class EngineJournal:
    def __init__(self, engine, *, config=None, attempt=None, owner_token=None):
        self.engine=engine
        self.config=deepcopy(config)
        self.attempt=attempt
        self.owner_token=owner_token

    def check_owner(self, task):
        if (self.attempt is not None and task.get('api_attempt', 1) != self.attempt or
            self.owner_token is not None and task.get('owner_token') != self.owner_token or
            task.get('status') != 'api_running'):
            raise JournalError('execution attempt is no longer active')

    def change(self, task_id, operation, *, credit_rejection=None):
        with self.engine.transaction() as db:
            task=self.engine.load(db,task_id)
            self.check_owner(task)
            operation(task)
            if credit_rejection is not None:
                request_id, endpoint, number = credit_rejection
                task['api_credit_rejection_receipt']=api_balance.record_rejection(
                    db,task,request_id,endpoint=endpoint,round_number=number)
                if task['status']=='fallback_ready' and task.get('api_attempt',1)>1:
                    task.update(status='blocked',reason='credit_rejection_after_unknown_attempt')
            self.engine.save(db,task)

    def begin(self, task_id, cap):
        def apply(t):
            if t.get('role')!='api_sol_execution' or t.get('status')!='api_running' or 'execution_loop' in t:
                raise JournalError('execution task is not a unique active Sol attempt')
            if t.get('api_charge_uncertain') or type(cap) is not int or cap <= 0:
                raise JournalError('invalid or uncertain execution budget')
            t['execution_loop']={'phase':'ready','cap_micro_usd':cap,'spent_micro_usd':0,'rounds':[],'tools':[]}
        self.change(task_id,apply)

    def before_count(self, task_id, number):
        """Check the owning session before each input-count network request."""
        with self.engine.transaction() as db:
            task = self.engine.load(db, task_id)
            self.check_owner(task)
            loop = task['execution_loop']
            if task.get('cancellation_requested') or loop['phase'] != 'ready' or number != len(loop['rounds']) + 1:
                raise JournalError('input count is not authorized for this round')
            if self.config is not None:
                self.engine.require_not_maintenance()
                if self.engine.current_config() != self.config or self.engine.readiness(self.config):
                    raise JournalError('execution settings changed or request is no longer authorized')
                if not self.engine.api_route_allowed(db, task):
                    return False
            return True

    def terminal_credit_failure(self, task_id, number, response, request_id, usage, cost):
        """Record the terminal response and pin the session without replaying this task."""
        with self.engine.transaction() as db:
            task = self.engine.load(db, task_id)
            self.check_owner(task)
            loop = task['execution_loop']; row = loop['rounds'][-1]
            if loop['phase'] != 'request_dispatching' or row['number'] != number or row['state'] != 'dispatching':
                raise JournalError('terminal response does not match an active request')
            receipt = api_balance.record_terminal_rejection(db, task, response)
            row.update(state='terminal_credit_failure', phase='response_received',
                       response_id=safe_id(response['id']), provider_request_id=safe_id(request_id),
                       elapsed_seconds=max(0, time.time()-row['started_at']))
            task['api_credit_rejection_receipt'] = receipt
            loop['phase'] = 'provider_rejected'
            if usage is not None:
                row.update(observed_usage=usage, observed_cost_micro_usd=cost)
                loop['spent_micro_usd'] += cost
                task['charged_micro_usd'] = loop['spent_micro_usd']
                task['reserved_micro_usd'] = 0
                task['api_charge_uncertain'] = False
                task['status'] = 'blocked'
            else:
                task['status'] = 'unknown_execution'
                task['api_charge_uncertain'] = True
            task['reason'] = 'terminal_credit_failure_no_replay'
            self.engine.save(db, task)

    def reserve_request(self,task_id,number,reserve,spent):
        with self.engine.transaction() as db:
            t=self.engine.load(db,task_id)
            self.check_owner(t)
            x=t['execution_loop']
            if t.get('cancellation_requested'):raise JournalError('cancellation_requested')
            if (t['status']!='api_running' or x['phase']!='ready' or number!=len(x['rounds'])+1 or
                spent!=x['spent_micro_usd'] or type(reserve) is not int or reserve<=0 or spent+reserve>x['cap_micro_usd']):
                raise JournalError('request reservation conflicts with task state or cap')
            if self.config is not None:
                self.engine.require_not_maintenance()
                if self.engine.current_config()!=self.config or self.engine.readiness(self.config):
                    raise JournalError('execution settings changed or request is no longer authorized')
                if not self.engine.api_route_allowed(db,t):
                    return False
                if self.config.get('budget_mode','cumulative_and_per_task')!='per_task_only':
                    tasks=[json.loads(row[0]) for row in db.execute('SELECT data FROM tasks')]
                    if any(row['status']=='unknown_execution' or row.get('api_charge_uncertain') for row in tasks):
                        raise JournalError('cumulative budget paused for uncertain charge')
                    total=sum((row.get('charged_micro_usd',0) if
                               row.get('budget_cycle_start')==self.config['cycle_start'] or
                               'budget_cycle_start' not in row and row.get('created_at',0)>=self.config['cycle_start'] else 0)
                              +row.get('closed_attempt_charges',{}).get(str(self.config['cycle_start']),0)
                              +row.get('interaction_unsettled_micro_usd',0)
                              +(row.get('reserved_micro_usd',0) if row['id']!=task_id else 0)
                              for row in tasks)
                    if total+reserve>self.config['cycle_budget_micro_usd']:
                        raise JournalError('cumulative budget would be exceeded by this round')
            attempt=t.get('api_attempt',1)
            attempt_suffix='' if attempt==1 else f'-a{attempt}'
            x['rounds'].append({'attempt':attempt,'number':number,'state':'dispatching','phase':'dispatch_prepared',
                                'started_at':time.time(),'reserve_micro_usd':reserve,
                                'client_request_id':f'hybrid-{task_id}{attempt_suffix}-r{number}'})
            x['phase']='request_dispatching';t['reserved_micro_usd']=reserve
            self.engine.save(db,t)

    def complete_request(self,task_id,number,response_id,request_id,usage,cost):
        def apply(t):
            x=t['execution_loop'];r=x['rounds'][-1]
            if x['phase']!='request_dispatching' or r['number']!=number or not response_id or cost<0 or cost>r['reserve_micro_usd']:
                raise JournalError('request result conflicts with active reservation')
            r.update(state='completed',phase='completed',elapsed_seconds=max(0,time.time()-r['started_at']),response_id=safe_id(response_id),provider_request_id=safe_id(request_id),usage=usage,charged_micro_usd=cost)
            x['spent_micro_usd']+=cost;x['phase']='ready';t['charged_micro_usd']=x['spent_micro_usd'];t['reserved_micro_usd']=0
        self.change(task_id,apply)

    def progress(self, task_id, number, fields):
        def apply(t):
            x=t['execution_loop']; r=x['rounds'][-1]
            if x['phase']!='request_dispatching' or r['number']!=number or r['state']!='dispatching':
                raise JournalError('request not pending')
            if fields.get('transport_phase') == 'headers_received':
                r['phase']='headers_received'
                request_id=safe_id(fields.get('request_id_provider'))
                if request_id: r['provider_request_id']=request_id
                status=fields.get('http_status')
                if type(status) is int and 100 <= status <= 599: r['http_status']=status
        self.change(task_id,apply)

    def unknown_request(self,task_id,number,error_type='unknown',request_id=None,http_status=None,
                        *,response_id=None,observed_usage=None,observed_cost=None):
        def apply(t):
            x=t['execution_loop'];r=x['rounds'][-1]
            if r['number']!=number or r['state']!='dispatching':raise JournalError('request not pending')
            allowed={'HTTPError','TimeoutError','ConnectionError','RemoteDisconnected','JSONDecodeError',
                     'OSError','ValueError','KeyError','TypeError','ArithmeticError','WorkerError',
                     'malformed_response','usage_missing','usage_exceeds_reservation','unknown'}
            r.update(state='unknown',error_type=error_type if error_type in allowed else 'unknown',
                     elapsed_seconds=max(0,time.time()-r['started_at']))
            if safe_id(request_id): r['provider_request_id']=safe_id(request_id)
            if error_type in ('malformed_response','usage_missing','usage_exceeds_reservation'): r['phase']='response_received'
            if type(http_status) is int and 100 <= http_status <= 599: r['http_status']=http_status; r['phase']='http_error_headers'
            if observed_usage is not None:
                r.update(response_id=safe_id(response_id),observed_usage=observed_usage,
                         observed_cost_micro_usd=observed_cost)
            x['phase']='unknown_request';t['status']='unknown_execution';t['api_charge_uncertain']=True
        self.change(task_id,apply)

    def begin_tool(self,task_id,number,call_id,args):
        def apply(t):
            x=t['execution_loop']
            if t.get('cancellation_requested'):raise JournalError('cancellation_requested')
            if t['status']!='api_running':raise JournalError('execution owner is not active')
            if x['phase']!='ready' or any(v['call_id']==call_id for v in x['tools']):raise JournalError('tool call already exists or task is not ready')
            encoded=json.dumps(args,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8')
            x['tools'].append({'round':number,'call_id':call_id,'input_sha256':hashlib.sha256(encoded).hexdigest(),'state':'running'})
            x['phase']='tool_running'
        self.change(task_id,apply)

    def begin_collection(self,task_id,index,source):
        def apply(t):
            if t.get('cancellation_requested'):raise JournalError('cancellation_requested')
            x=t['execution_loop']
            if t['status']!='api_running' or x['phase'] not in ('awaiting_result_validation','artifact_collection_complete'):
                raise JournalError('artifact collection is not authorized')
            x.update(phase='artifact_collecting',collection_index=index,collection_source=source)
        self.change(task_id,apply)

    def reject_request(self,task_id,number,code,request_id,allow_fallback,http_status=None):
        def apply(t):
            x=t['execution_loop'];r=x['rounds'][-1]
            if x['phase']!='request_dispatching' or r['number']!=number or r['state']!='dispatching':
                raise JournalError('rejected request is not pending')
            r.update(state='confirmed_rejected',phase='http_error_headers',error_type='HTTPError',elapsed_seconds=max(0,time.time()-r['started_at']),rejection_code=code,provider_request_id=safe_id(request_id))
            if type(http_status) is int and 100 <= http_status <= 599: r['http_status']=http_status
            x['phase']='provider_rejected';t['reserved_micro_usd']=0;t['api_charge_uncertain']=False
            if t.get('cancellation_requested'):
                t.update(status='cancelled',reason='cancelled_after_confirmed_rejection')
            elif allow_fallback and len(x['rounds'])==1 and not x['tools'] and x['spent_micro_usd']==0:
                t.update(status='fallback_ready',reason=code)
            else:t.update(status='blocked',reason='later_round_provider_rejection_no_replay')
        credit=(request_id,'responses',number) if code==api_balance.CREDIT_ERROR and http_status==429 else None
        self.change(task_id,apply,credit_rejection=credit)

    def reject_count_for_credit(self,task_id,number,request_id):
        def apply(t):
            loop=t['execution_loop']
            if loop['phase']!='ready' or number!=len(loop['rounds'])+1:
                raise JournalError('input count rejection is not for the next round')
            loop['rounds'].append({'attempt':t.get('api_attempt',1),'number':number,
                                  'state':'confirmed_rejected','phase':'input_count_rejected',
                                  'error_type':'HTTPError','http_status':429,
                                  'rejection_code':api_balance.CREDIT_ERROR,
                                  'provider_request_id':safe_id(request_id)})
            loop['phase']='provider_rejected'
            t.update(reserved_micro_usd=0,api_charge_uncertain=False)
            if t.get('cancellation_requested'):
                t.update(status='cancelled',reason='cancelled_after_confirmed_rejection')
            elif number==1 and not loop['tools'] and loop['spent_micro_usd']==0:
                t.update(status='fallback_ready',reason=api_balance.CREDIT_ERROR)
            else:
                t.update(status='blocked',reason='later_round_provider_rejection_no_replay')
        self.change(task_id,apply,credit_rejection=(request_id,'responses/input_tokens',number))

    def complete_tool(self,task_id,number,call_id,result):
        def apply(t):
            x=t['execution_loop'];v=x['tools'][-1]
            if x['phase']!='tool_running' or v['call_id']!=call_id or v['round']!=number:raise JournalError('tool call is not active')
            v.update(state='completed',receipt=result);x['phase']='ready'
        self.change(task_id,apply)

    def unknown_tool(self,task_id,number,call_id):
        def apply(t):
            x=t['execution_loop'];v=x['tools'][-1]
            if v['call_id']!=call_id or v['round']!=number or v['state']!='running':raise JournalError('tool call is not active')
            v['state']='unknown';x['phase']='unknown_tool';t['status']='unknown_execution';t['reason']='tool_execution_unreconciled'
        self.change(task_id,apply)

    def stop(self,task_id,reason):
        def apply(t):
            x=t['execution_loop']
            if x['phase']!='ready':raise JournalError('cannot stop an uncertain in-flight call')
            # Ready proves no request or tool is in flight. This also clears the
            # outer preflight reservation when the complete first round cannot start.
            x.update(phase='stopped',reason=reason);t['status']='blocked';t['reason']=reason
            t['reserved_micro_usd']=0
        self.change(task_id,apply)

    def finish(self,task_id,spent):
        def apply(t):
            x=t['execution_loop']
            if x['phase']!='ready' or x['spent_micro_usd']!=spent:raise JournalError('completion accounting mismatch')
            x['phase']='awaiting_result_validation'
        self.change(task_id,apply)

"""Exact, expiring, user-approved QA canary authority; absent/closed is denied."""
import json
from pathlib import Path
import time
import hashlib

def digest(value):
    return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()

def grant(root):
    path=Path(root)/'state/qa-validation-grant.json'
    if not path.is_file():return None
    data=json.loads(path.read_text(encoding='utf-8'))
    if data.get('version')!=1 or data.get('state')!='active' or time.time()>=data.get('expires_at',0):return None
    if not data.get('user_approval_verbatim') or data.get('api_total_cap_micro_usd')!=1000000:return None
    return data

def operation(root,who,tool,args):
    data=grant(root)
    if not data or not who or who.get('is_child') or who.get('role') or who.get('id')!=data['parent_id']:return False
    if who.get('model')!=data['parent_model'] or who.get('effort')!=data['parent_effort']:return False
    if tool.endswith('submit_task'):
        spec=data['requests'].get(args.get('request_id'))
        return bool(spec and args.get('role')=='api_sol_qa' and args.get('parent_session_id')==data['parent_id'] and digest(args)==spec['submission_sha256'])
    if any(tool.endswith(x) for x in ('claim_subscription_fallback','complete_subscription_fallback')):
        return any(x.get('task_id')==args.get('task_id') and x['case']=='B' for x in data['requests'].values())
    return False

def validate_submission(root,role,request_id,parent,context,materials):
    data=grant(root)
    if not data or data['parent_id']!=parent:raise ValueError('QA validation authority is absent, closed or expired.')
    args={'role':role,'request_id':request_id,'parent_session_id':parent,'context':context,'materials':materials or []}
    spec=data['requests'].get(request_id)
    if role!='api_sol_qa' or not spec or digest(args)!=spec['submission_sha256']:raise ValueError('QA validation payload differs from the exact user-authorized frozen canary.')
    for material in materials or []:
        path=Path(material['path']);expected=spec['material_sha256'].get(str(path))
        if not expected or hashlib.sha256(path.read_bytes()).hexdigest()!=expected:raise ValueError('Authorized QA canary material changed.')
    return spec

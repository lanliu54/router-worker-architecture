"""Candidate Sol sandbox transport; never loaded by the currently installed service."""
import json
from pathlib import Path
import shutil
import sys
from sol_execution_loop import execute
from sol_execution_journal import EngineJournal
from sol_api_adapter import ToolAwareAdapter
from windows_sol_runner import WindowsSolRunner, RunnerError


def run_sol(engine,task,package,payload,adapter,config):
    task_id=task['id']
    stage='maintenance_gate'
    attempt=task.get('api_attempt',1)
    collecting=None
    try:
        engine.require_not_maintenance()
        stage='sandbox_discovery'
        codex=shutil.which('codex')
        if not codex:raise RuntimeError('Codex sandbox executable is unavailable')
        folder=Path(task['package_path']).parent
        stage='prepare_workspace'
        workspace_name='candidate-workspace' if attempt==1 else f'candidate-workspace-a{attempt}'
        workspace=folder/workspace_name;workspace.mkdir(exist_ok=False)
        inputs=workspace/'inputs';inputs.mkdir()
        rows=[]
        for item in package['evidence']['source_material_manifest']:
            source=Path(item['frozen_snapshot_reference'])
            destination=inputs/(item['material_id']+source.suffix)
            if destination.exists():raise RuntimeError('Duplicate candidate input name')
            shutil.copyfile(source,destination)
            rows.append({'material_id':item['material_id'],'candidate_path':'inputs/'+destination.name,'sha256':item['sha256']})
        sandbox=package['task']['execution_sandbox']
        payload['input'].append({'role':'user','content':'Candidate workspace inputs and required output paths: '+json.dumps({'inputs':rows,'artifact_paths':sandbox['artifact_paths']},ensure_ascii=False)})
        runner=WindowsSolRunner(workspace,codex_executable=codex,python_executable=sys.executable)
        journal=EngineJournal(engine,config=config,attempt=attempt,owner_token=task.get('owner_token'))
        rates=config['price_card']['api_sol_execution']
        from worker_core import package_limits
        policy=package_limits(task['role'],package)
        input_limit=policy['input'] if policy['version']==3 else min(policy['input'],config['max_input_tokens'])
        stage='model_and_tool_loop'
        result=execute(task_id=task_id,payload=payload,adapter=ToolAwareAdapter(adapter,attempt=attempt),runner=runner,journal=journal,
                       cap_micro_usd=engine.effective_api_cap(config,task,package),
                       input_rate=max(rates['input_usd_per_million'],rates['cache_write_usd_per_million']),
                       output_rate=rates['output_usd_per_million'],input_limit=input_limit,
                       output_limit=policy['output'],max_rounds=policy['rounds'])
        loop=engine.get_task(task_id)['execution_loop']
        if not result['tool_calls'] or not any(item.get('state')=='completed' and item.get('receipt',{}).get('exit_code')==0
                                               and not item['receipt'].get('timed_out') and not item['receipt'].get('output_truncated')
                                               for item in loop['tools']):
            raise RuntimeError('No successful bounded execution receipt')
        stage='validate_model_output'
        output=json.loads(result['text'])
        engine.validate_result(task,output,package)
        artifacts=[]
        if output['status']=='completed':
            stage='collect_artifacts'
            artifact_folder='candidate-artifacts' if attempt==1 else f'candidate-artifacts-a{attempt}'
            dest=folder/artifact_folder;dest.mkdir(exist_ok=False)
            for i,path in enumerate(sandbox['artifact_paths']):
                journal.begin_collection(task_id,i,path)
                loop=engine.get_task(task_id)['execution_loop']
                # Capture this operation before invoking the runner, not from a later ledger read.
                collecting=(i,path)
                artifacts.append(runner.collect_file(path,(dest/('artifact-'+str(i)+Path(path).suffix)).resolve()))
                collecting=None
                loop.update(phase='artifact_collection_complete')
                engine.update(task_id,execution_loop=loop,candidate_artifacts=artifacts)
        stage='save_terminal_result'
        loop=engine.get_task(task_id)['execution_loop']
        loop['phase']='result_validated' if output['status']=='completed' else 'missing_context'
        aggregate={key:sum(row['usage'][key] for row in loop['rounds']) for key in ('input_tokens','output_tokens')}
        engine.update(task_id,status='missing_context' if output['status']=='missing_context' else 'completed',
                      result=output,route='api',actual_model='gpt-6.1-sol',requested_reasoning_effort='high',
                      returned_reasoning_effort=None,candidate_artifacts=artifacts,
                      execution_loop=loop,api_usage=aggregate,billing_status='conservative_local_estimate_not_platform_credit_attribution',
                      execution_scope='sandbox_only; parent validation and application required')
        return True
    except Exception as exc:
        current=engine.get_task(task_id)
        if current['status']=='api_running':
            loop=current.get('execution_loop',{})
            collecting_unknown=(loop.get('phase')=='artifact_collecting' and
                                (not isinstance(exc,RunnerError) or exc.execution_unknown))
            pending=loop.get('phase') in ('request_dispatching','tool_running') or collecting_unknown
            cancelled=bool(current.get('cancellation_requested')) and not pending
            known_collection_failure=(collecting if isinstance(exc,RunnerError) and not exc.execution_unknown else None)
            engine.update_owned_failure(task_id,task.get('owner_token'),expected_attempt=attempt,
                          known_collection_failure=known_collection_failure,status='unknown_execution' if pending else 'cancelled' if cancelled else 'blocked',
                          reason='sol_runtime_unreconciled' if pending else 'cancelled_after_completed_operation' if cancelled else 'sol_runtime_failed',
                          api_charge_uncertain=loop.get('phase')=='request_dispatching',
                          reserved_micro_usd=current.get('reserved_micro_usd',0) if pending else 0,
                          local_error_type=type(exc).__name__,local_error_stage=stage)
        return False

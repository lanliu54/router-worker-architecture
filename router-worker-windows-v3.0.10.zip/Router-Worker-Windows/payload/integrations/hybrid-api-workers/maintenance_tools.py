"""Check, snapshot, or restore the installed routing source and owned configuration."""
import argparse
import json
import os
from pathlib import Path, PurePosixPath
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parent
BACKUP = ROOT / ".maintenance" / "previous-source.zip"
PATTERNS = (
    "*.py", "RUNBOOK.md", "architecture-policy.json", "astra-review-policy.json",
    "context-package-spec.json", "maintenance.json", "personalization-policy.json",
    "role-manifest.json", "settings.json", "policies/*.txt", "prompts/*.txt",
    "routing/*.py", "routing/README.md", "routing/profiles/*.json",
    ".codex/project-management/index.json", ".codex/project-management/code-structure.json",
    "orchestrator-control/launch.py", "orchestrator-control/RUNBOOK.md",
    "orchestrator-control/runtime/config.json",
    "orchestrator-control/source/orchestrator/*.py",
    "orchestrator-control/source/orchestrator/contracts/*.json",
    "orchestrator-control/source/orchestrator/contracts/*.sql",
)


def source_files():
    files = {path for pattern in PATTERNS for path in ROOT.glob(pattern) if path.is_file()}
    for path in files:
        if path.resolve() != path or not path.is_relative_to(ROOT):
            raise ValueError(f"Source path resolves outside its owned location: {path}")
    return sorted(files)


HOST_ROLLBACK_FILES = {
    "codex-home/AGENTS.md",
    "codex-home/skills/hybrid-worker-routing/SKILL.md",
    "codex-home/agents/sol_execution_subscription.toml",
    "codex-home/agents/sol_qa_subscription.toml",
    "codex-home/agents/luna_batch_subscription.toml",
    "codex-home/agents/astra_review_subscription.toml",
}


def owned(name):
    if name in HOST_ROLLBACK_FILES:
        return True
    path = PurePosixPath(name)
    if path.is_absolute() or path.as_posix() != name or ".." in path.parts or ":" in name or chr(92) in name:
        return False
    return any(path.match(pattern) and len(path.parts) == len(PurePosixPath(pattern).parts)
               for pattern in PATTERNS)


def atomic_write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=path.parent, delete=False) as stream:
        temporary = Path(stream.name)
        stream.write(data)
    try:
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def check():
    from architecture_policy import load

    files = source_files()
    for relative in ("service.py", "routing/guard.py", "routing/hook_chain.py",
                     "orchestrator-control/launch.py", "orchestrator-control/source/orchestrator/__main__.py"):
        if ROOT / relative not in files:
            raise ValueError(f"Missing runtime entrypoint: {relative}")
    for path in files:
        data = path.read_bytes()
        if path.suffix == ".py":
            compile(data, str(path), "exec")
        elif path.suffix == ".json":
            json.loads(data)
    if load(ROOT) is None:
        raise ValueError("Missing architecture-policy.json")
    print(f"Checked {len(files)} source and configuration files in {ROOT}")


def snapshot():
    check()
    BACKUP.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=BACKUP.parent, delete=False) as stream:
        temporary = Path(stream.name)
    try:
        with zipfile.ZipFile(temporary, "w", zipfile.ZIP_DEFLATED) as archive:
            for path in source_files():
                archive.write(path, path.relative_to(ROOT).as_posix())
        with zipfile.ZipFile(temporary) as archive:
            if archive.testzip() is not None:
                raise ValueError("Rollback snapshot failed its integrity check")
        os.replace(temporary, BACKUP)
    finally:
        temporary.unlink(missing_ok=True)
    print(f"Saved {BACKUP}")


def restore():
    with zipfile.ZipFile(BACKUP) as archive:
        names = archive.namelist()
        if len(names) != len(set(names)) or not names or not all(map(owned, names)):
            raise ValueError("Rollback snapshot contains invalid or duplicate paths")
        entries = {}
        for name in names:
            path = (ROOT.parents[1] / name.removeprefix("codex-home/")
                    if name in HOST_ROLLBACK_FILES else ROOT / name)
            if path.resolve() != path:
                raise ValueError(f"Rollback path resolves outside its owned location: {path}")
            entries[path] = archive.read(name)

    added = set(source_files()) - entries.keys()
    for path, data in entries.items():
        atomic_write(path, data)
    check()
    if added:
        print("Review files created after the snapshot:")
        for path in sorted(added):
            print(path.relative_to(ROOT))
    print("Restored saved source and configuration. Restart Codex to reload long-lived processes.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("check", "snapshot", "restore"))
    args = parser.parse_args()
    {"check": check, "snapshot": snapshot, "restore": restore}[args.action]()

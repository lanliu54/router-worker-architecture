"""Bounded hybrid workers. Standard-library-only; live access is disabled by default."""
from __future__ import annotations

import base64
import contextlib
import copy
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import sqlite3
import stat
import subprocess
import time
from datetime import datetime, timezone
from decimal import Decimal, ROUND_CEILING
import uuid
import architecture_policy
import api_balance

ROLES = {
    "api_sol_execution": ("gpt-6.1-sol", "high", "sol_execution_subscription", 16384),
    "api_sol_qa": ("gpt-6.1-sol", "high", "sol_qa_subscription", 16384),
    "api_luna_batch": ("gpt-6-luna", "high", "luna_batch_subscription", 8192),
    "api_astra_review": ("gpt-6-astra", "high", "astra_review_subscription", 32768),
}
MAX_INPUT_TOKENS = 128000  # Explicit user approval 2026-11-04; decimal 128k.
ROLE_POLICY_V3 = {
    'api_astra_review': {'input': 128000, 'output': 32768, 'rounds': 1, 'cap': 3500000},
    'api_sol_qa': {'input': 256000, 'output': 16384, 'rounds': 1, 'cap': 1000000},
    'api_sol_execution': {'input': 256000, 'output': 16384, 'rounds': 3, 'cap': 2500000},
    'api_luna_batch': {'input': 512000, 'output': 16384, 'rounds': 1, 'cap': 200000},
}
LEGACY_CAPS = {'api_astra_review': 3500000, 'api_sol_qa': 1000000,
               'api_sol_execution': 2000000, 'api_luna_batch': 100000}

def frozen_role_policy(role, config):
    if config.get('role_policy_version', 2) == 3 and role in ROLE_POLICY_V3:
        return {'version': 3, **ROLE_POLICY_V3[role]}
    return {'version': 2, 'input': config.get('max_input_tokens', MAX_INPUT_TOKENS),
            'output': 4096 if role == 'api_sol_execution' else ROLES[role][3],
            'rounds': 3 if role == 'api_sol_execution' else 1, 'cap': LEGACY_CAPS[role]}

def package_role_policy(role, package):
    policy = package.get('task', {}).get('role_policy')
    if policy is None:
        return frozen_role_policy(role, {})
    if isinstance(policy, dict) and policy.get('version') == 2:
        legacy = frozen_role_policy(role, {})
        need(set(policy) == set(legacy) and type(policy['input']) is int and 0 < policy['input'] <= legacy['input']
             and policy['output'] == legacy['output'] and policy['rounds'] == legacy['rounds']
             and policy['cap'] == legacy['cap'], 'role_policy_invalid', 'Invalid frozen legacy policy.')
        return policy
    need(policy == {'version': 3, **ROLE_POLICY_V3.get(role, {})},
         'role_policy_invalid', 'Frozen role policy does not match an approved policy.')
    return policy

def package_limits(role, package):
    policy = dict(package_role_policy(role, package))
    limits = package.get('task', {}).get('authorized_token_limits', {})
    need(isinstance(limits, dict) and set(limits) <= {'input', 'output'},
         'role_policy_invalid', 'Token limits may only tighten approved bounds.')
    for key in ('input', 'output'):
        if key in limits:
            need(type(limits[key]) is int and 0 < limits[key] <= policy[key],
                 'role_policy_invalid', 'Token limits may only tighten approved bounds.')
            policy[key] = limits[key]
    return policy

def request_rates(role, prices, token_count):
    input_rate = max(Decimal(str(prices['input_usd_per_million'])), Decimal(str(prices['cache_write_usd_per_million'])))
    output_rate = Decimal(str(prices['output_usd_per_million']))
    if role == 'api_luna_batch' and token_count > 272000:
        input_rate *= 2
        output_rate *= Decimal('1.5')
    return input_rate, output_rate
MAX_API_CONCURRENCY = 5
PARENT_FIELDS = ("task_relevant_background", "research_or_project_positioning",
                 "relevant_user_requirements_with_verbatim_wording_and_provenance",
                 "confirmed_decisions", "later_corrections_and_superseded_decisions",
                 "approved_terminology", "constraints_and_immutable_items", "current_work_state",
                 "known_unknowns_and_conflicts")
ACTIVE = ("preparing", "api_running", "fallback_claimed", "unknown_execution")
NO_DUPLICATE = ACTIVE + ("queued", "validation_ready", "fallback_ready", "completed", "completed_observed", "missing_context", "incomplete", "quality_failure", "blocked", "refused", "parent_closed_unknown", "interaction_failed")
ELIGIBLE_CODES = {"credit_balance_exhausted", "organization_spend_limit_exceeded",
                  "project_spend_limit_exceeded", "organization_usage_limit_exceeded",
                  "rate_limit_exceeded", "model_not_found"}


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def digest(value):
    return hashlib.sha256(value if isinstance(value, bytes) else canonical(value).encode("utf-8")).hexdigest()


NATIVE_SOL_ARTIFACT_LIMIT = 16 * 1024 * 1024
NATIVE_SOL_TOTAL_ARTIFACT_LIMIT = 32 * 1024 * 1024
LEGACY_ARTIFACT_LIMIT = 65536


def native_artifact_digest(path, root, limit):
    error='native_artifact_integrity'
    message='Native artifact is missing, linked, over its byte limit or outside its task root.'
    path=path.absolute()

    def snapshot():
        need('..' not in path.parts and path.is_relative_to(root)
             and path.resolve(strict=True).is_relative_to(root),error,message)
        for component in (path,*path.parents):
            need(not component.is_symlink() and not component.is_junction(),error,message)
            if component==root:
                break
        return path.stat()

    def identity(info):
        return (info.st_dev,info.st_ino,info.st_size,info.st_mtime_ns,info.st_nlink)

    try:
        before=snapshot()
        need(stat.S_ISREG(before.st_mode) and before.st_nlink==1 and before.st_size<=limit,error,message)
        value=hashlib.sha256()
        with path.open('rb') as stream:
            opened=os.fstat(stream.fileno())
            need(stat.S_ISREG(opened.st_mode) and identity(opened)==identity(before),
                 error,'Native artifact was replaced before opening.')
            remaining=opened.st_size
            while remaining:
                chunk=stream.read(min(remaining,1024*1024))
                need(bool(chunk),error,'Native artifact changed size during collection.')
                value.update(chunk)
                remaining-=len(chunk)
            need(not stream.read(1) and identity(os.fstat(stream.fileno()))==identity(opened)
                 and identity(snapshot())==identity(opened),
                 error,'Native artifact changed during collection.')
        return opened.st_size,value.hexdigest()
    except (OSError,ValueError) as exc:
        raise WorkerError(error,message) from exc


def verify_workspace_artifacts(task, package, artifacts):
    """Verify a direct result in place without copying working files into the ledger."""
    frozen = package['task']
    workspace = Path(frozen['execution_workspace'])
    execution = task.get('native_execution', {})
    expected = frozen['execution_sandbox']['artifact_paths']
    need(execution.get('mode') == 'in_place' and execution.get('workspace') == str(workspace),
         'native_artifact_integrity', 'The task lacks its exact frozen workspace binding.')
    need(isinstance(artifacts, list) and all(isinstance(item, dict) for item in artifacts)
         and [item.get('source') for item in artifacts] == expected,
         'native_artifact_manifest_mismatch', 'Report every declared in-place artifact in order.')
    remaining = NATIVE_SOL_TOTAL_ARTIFACT_LIMIT
    for artifact in artifacts:
        source = workspace / artifact['source']
        need(artifact.get('path') == str(source), 'native_artifact_integrity',
             'Artifact path must be the original file in the declared workspace.')
        size, actual = native_artifact_digest(source, workspace, min(NATIVE_SOL_ARTIFACT_LIMIT, remaining))
        need(actual == artifact.get('sha256'), 'native_artifact_integrity', 'Workspace artifact hash differs.')
        remaining -= size


def verify_native_candidate_artifacts(task, package, candidates):
    frozen=package['task']
    expected=frozen['execution_sandbox']['artifact_paths']
    need(isinstance(candidates,list) and all(isinstance(x,dict)
         and isinstance(x.get('path'),str) and isinstance(x.get('sha256'),str) for x in candidates)
         and [x.get('source') for x in candidates]==expected,
         'native_artifact_manifest_mismatch','Collect every exact requested native candidate.')
    root=Path(task['package_path']).resolve().parent
    folder=root/'candidate-artifacts'
    direct=(task.get('dispatch_mode')=='subscription_direct' and task.get('reason')=='native_direct'
            and frozen.get('dispatch_mode')=='subscription_direct' and frozen['execution_contract']['version']==4)
    if not direct:
        for artifact in candidates:
            path=Path(artifact['path'])
            need(path.is_file() and not path.is_symlink() and path.resolve().is_relative_to(folder)
                 and path.stat().st_size<=LEGACY_ARTIFACT_LIMIT and digest(path.read_bytes())==artifact['sha256'],
                 'native_artifact_integrity','Native collected artifact is missing, changed or outside its collection root.')
        return
    workspace=root/'native-workspace'
    need(Path(task.get('native_execution',{}).get('workspace',''))==workspace,
         'native_artifact_integrity','Artifacts lack the exact claimed native workspace.')
    remaining=NATIVE_SOL_TOTAL_ARTIFACT_LIMIT
    for artifact in candidates:
        limit=min(NATIVE_SOL_ARTIFACT_LIMIT,remaining)
        size,actual=native_artifact_digest(Path(artifact['path']),folder,limit)
        need(actual==artifact['sha256'],'native_artifact_integrity','Collected artifact hash differs.')
        source_size,source_hash=native_artifact_digest(workspace/artifact['source'],workspace,limit)
        need((source_size,source_hash)==(size,actual),'native_artifact_integrity',
             'Collected artifact differs from the declared native workspace original.')
        remaining-=size


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".writing-" + secrets.token_hex(4))
    temp.write_text(canonical(value) + "\n", encoding="utf-8")
    os.replace(temp, path)


class WorkerError(Exception):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = code


def need(condition, code, message):
    if not condition:
        raise WorkerError(code, message)


def meaningful(value):
    return bool(value) and value not in ("unknown", "TODO", "TBD")


def process_alive(pid):
    if pid == os.getpid():
        return True
    if os.name == "nt":
        import ctypes
        from ctypes import wintypes
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel.OpenProcess.restype = wintypes.HANDLE
        handle = kernel.OpenProcess(0x1000, False, int(pid))
        if not handle:
            return False
        try:
            code = wintypes.DWORD()
            return bool(kernel.GetExitCodeProcess(handle, ctypes.byref(code))) and code.value == 259
        finally:
            kernel.CloseHandle(handle)
    try:
        os.kill(int(pid), 0)
        return True
    except OSError:
        return False






class Engine:
    def __init__(self, root, *, config=None, parent_close_verifier=None):
        self.root = Path(root).resolve()
        # No default verifier exists: an idle chat or a dead process is not a
        # session-closure signal. The host must supply a trusted verifier.
        self.parent_close_verifier = parent_close_verifier
        self.config_from_file = config is None
        self.config = config if config is not None else json.loads((self.root / "settings.json").read_text(encoding="utf-8"))
        self.state = self.root / "state"
        self.state.mkdir(parents=True, exist_ok=True)
        self.database = self.state / "tasks.sqlite3"
        with self.transaction() as db:
            db.execute("CREATE TABLE IF NOT EXISTS tasks (id TEXT PRIMARY KEY, request_id TEXT UNIQUE, fingerprint TEXT, role TEXT, parent TEXT, issue TEXT, evidence TEXT, status TEXT, data TEXT)")
            db.execute("CREATE TABLE IF NOT EXISTS control (key TEXT PRIMARY KEY, value TEXT)")
            for row in db.execute("SELECT * FROM tasks WHERE status IN ('preparing','api_running')").fetchall():
                task = json.loads(row["data"])
                if not process_alive(task.get("owner_pid", 0)):
                    # A dead count-only request cannot have generated model output.
                    task["status"] = "unknown_execution" if row["status"] == "api_running" else "fallback_ready"
                    task["reason"] = "owner_lost_after_dispatch" if row["status"] == "api_running" else "owner_lost_before_inference"
                    task["api_charge_uncertain"] = row["status"] == "api_running"
                    self.save(db, task)

    def current_config(self):
        """New attempts observe saved controls; an in-flight attempt keeps its snapshot."""
        try:
            config = json.loads((self.root / "settings.json").read_text(encoding="utf-8")) if self.config_from_file else self.config
            need(isinstance(config, dict), "settings_invalid", "Worker settings must be an object.")
            limit = config.get("max_input_tokens", MAX_INPUT_TOKENS)
            need(type(limit) is int and 1 <= limit <= MAX_INPUT_TOKENS,
                 "input_limit_config_invalid", "max_input_tokens must be an integer from 1 to the approved 128000-token ceiling.")
            need(type(config.get('role_policy_version', 2)) is int and config.get('role_policy_version', 2) in (2, 3),
                 'input_limit_config_invalid', 'Unsupported role policy version.')
            timeout = config.get('api_request_timeout_seconds',900)
            need(type(timeout) in (int,float) and not isinstance(timeout,bool) and 30 <= timeout <= 3600,
                 'transport_config_invalid','API request timeout must be between30 and3600 seconds.')
            streaming = config.get('api_streaming_roles',['api_astra_review'])
            need(isinstance(streaming,list) and all(role in ROLES for role in streaming),
                 'transport_config_invalid','Streaming roles must use the fixed role identifiers.')
            return copy.deepcopy(config)
        except (OSError, ValueError) as error:
            raise WorkerError("settings_unavailable", "Saved worker settings could not be read; no API dispatch is allowed.") from error

    def require_not_maintenance(self):
        path = self.root / 'maintenance.json'
        if path.exists():
            try:
                state = json.loads(path.read_text(encoding='utf-8'))
            except (OSError, ValueError) as error:
                raise WorkerError('maintenance_invalid', 'Maintenance state is unreadable; dispatch is blocked.') from error
            need(state.get('enabled') is False, 'maintenance_active', 'New dispatch and fallback activation are disabled during maintenance.')

    @contextlib.contextmanager
    def transaction(self, *, controller_lock=False):
        db = sqlite3.connect(self.database, timeout=20, isolation_level=None)
        db.row_factory = sqlite3.Row
        try:
            db.execute("PRAGMA journal_mode=WAL")
            db.execute("PRAGMA busy_timeout=20000")
            if controller_lock:
                controller = self.root / 'orchestrator-control' / 'runtime' / 'state.sqlite'
                need(controller.is_file(), 'historical_controller_unavailable', 'Historical controller database is unavailable.')
                db.execute('ATTACH DATABASE ? AS controller_guard', (str(controller),))
            db.execute("BEGIN IMMEDIATE")
            yield db
            db.commit()
        except BaseException:
            db.rollback()
            raise
        finally:
            db.close()

    @staticmethod
    def save(db, task):
        task["updated_at"] = time.time()
        db.execute("INSERT INTO tasks VALUES (?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET status=excluded.status,data=excluded.data",
                   (task["id"], task["request_id"], task["fingerprint"], task["role"], task["parent_session_id"],
                    task.get("issue", ""), task["evidence_hash"], task["status"], canonical(task)))

    def load(self, db, task_id):
        row = db.execute("SELECT data FROM tasks WHERE id=?", (task_id,)).fetchone()
        need(row, "not_found", "Task was not found in the shared ledger.")
        return json.loads(row["data"])

    def prompt(self, role):
        need(role in ROLES, "role_invalid", "Use a named API role.")
        return (self.root / "prompts" / (role + ".txt")).read_text(encoding="utf-8")

    def workspace_for_owner(self, parent):
        from routing.project_handoffs import workspace_for_session

        try:
            workspace = workspace_for_session(self.root.parents[1], parent)
        except (OSError, ValueError, sqlite3.Error) as exc:
            raise WorkerError('native_workspace_unverified', 'Could not verify the owning chat workspace.') from exc
        home = self.root.parents[1].resolve()
        need(workspace is not None and not workspace.is_relative_to(home) and not home.is_relative_to(workspace),
             'native_workspace_unverified', 'An existing owning-chat workspace outside Codex home is required.')
        return workspace

    def freeze(self, task_id, role, context, selected_materials, local_bundle=None, astra_review=None, *, native_direct=False, routing_policy=None):
        need(isinstance(context, dict), "context_missing", "Provide the complete task context object.")
        self.execution_contract(role, context)
        for field in ("objective", "deliverables", "authorized_scope", "output_format", "acceptance_criteria"):
            need(meaningful(context.get(field)), "context_missing", "Required task field missing: " + field)
        parent = context.get("parent_context", {})
        for field in PARENT_FIELDS:
            need(meaningful(parent.get(field)), "context_missing", "Required parent context field missing: " + field)
        coverage = context.get("coverage", {})
        need(coverage.get("ready_for_dispatch") is True and coverage.get("requirements_map") and
             not coverage.get("unresolved_required_gaps"), "context_missing", "Resolve and map required background/evidence before dispatch.")
        need(context.get("destination_authorized") is True, "permission_denied", "Material delivery must be authorized for the selected destinations.")
        folder = self.state / "packages" / task_id
        folder.mkdir(parents=True, exist_ok=False)
        manifest = []
        for index, (material, raw, material_hash) in enumerate(selected_materials):
            source = Path(material["path"])
            media = material.get("media_type", "text/plain")
            need(media in ("text/plain", "text/markdown", "application/json", "text/csv", "image/png", "image/jpeg", "image/webp", "image/gif", "application/pdf"),
                 "unsupported_material", "Supply a supported original image/PDF/text or an explicitly derived supported artifact with provenance.")
            if media.startswith("text/") or media == "application/json":
                try:
                    raw.decode("utf-8")
                except UnicodeDecodeError as error:
                    raise WorkerError("unsupported_material", "Text evidence must be UTF-8; preserve the original and supply a documented conversion.") from error
            material_id = material.get("material_id", "material-" + str(index + 1))
            need(re.fullmatch(r"[A-Za-z0-9_-]{1,80}", material_id), "materials_invalid", "Material IDs must be simple unique identifiers.")
            need(material_id not in {x["material_id"] for x in manifest}, "materials_invalid", "Duplicate material ID.")
            frozen = folder / (material_id + source.suffix[:16])
            frozen.write_bytes(raw)
            need(digest(frozen.read_bytes()) == material_hash, "integrity_failure", "Snapshot hash verification failed.")
            manifest.append({"material_id": material_id, "original_name": source.name, "media_type": media,
                             "provenance_locator": str(source), "source_version_or_capture_time": material.get("source_version", "sha256:" + material_hash),
                             "byte_length": len(raw), "sha256": material_hash, "required": material.get("required", True),
                             "frozen_snapshot_reference": str(frozen), "task_relevance": material.get("task_relevance", "Required task evidence")})
        expected = set(coverage.get("required_material_ids", []))
        need(expected.issubset({x["material_id"] for x in manifest}), "material_missing", "Required material IDs were not supplied.")
        model, effort, _, _ = ROLES[role]
        prompt = self.prompt(role)
        package = {"identity": {"package_id": context.get("package_id", task_id), "version": context.get("version", "1"),
                                "task_id": task_id, "parent_task_reference": context.get("parent_task_reference", "parent_dispatch"),
                                "created_at": datetime.now(timezone.utc).isoformat(), "supersedes_version_or_null": context.get("supersedes_version")},
                   "task": {x: context[x] for x in ("objective", "deliverables", "authorized_scope", "output_format", "acceptance_criteria")},
                   "parent_context": parent, "evidence": {"source_material_manifest": manifest},
                   "role": {"role_name": role, "exact_model": model, "reasoning_effort": effort,
                            "canonical_role_prompt": prompt, "role_prompt_sha256": digest(prompt.encode("utf-8"))},
                   "completeness_review": coverage}
        # Retention is frozen per new package; historical packages without this
        # field retain their original store=false behavior.
        package['task']['response_store'] = True
        qa_boundary=context.get('native_qa_boundary')
        if role=='api_sol_qa' and (qa_boundary=='review_rules_v1' or qa_boundary is None and 'qa_binding' not in context):
            policy=architecture_policy.load(self.root) or {}
            if policy.get('independent_qa',{}).get('native_review_boundary')=='review_rules_v1':
                package['task']['native_qa_boundary']='review_rules_v1'
        if native_direct:
            package['task']['dispatch_mode']='subscription_direct'
        trusted_config = self.current_config()
        package['task']['role_policy'] = frozen_role_policy(role, trusted_config)
        if routing_policy and routing_policy.get('version') == 5:
            package['task']['routing_policy_version'] = 5
        configured_cap = 0 if native_direct else trusted_config['per_task_budget_micro_usd'].get(role, 0)
        need(type(configured_cap) is int and configured_cap >= 0,
             'authorized_budget_invalid', 'Configured role cap must be nonnegative.')
        package['task']['frozen_role_cap_micro_usd'] = min(configured_cap, package['task']['role_policy']['cap'])
        if 'authorized_token_limits' in context:
            package['task']['authorized_token_limits'] = copy.deepcopy(context['authorized_token_limits'])
            package_limits(role, package)
        # Preserve ownership/effect limits in both API and native delivery, not
        # just in the input hash. Older frozen packages remain unchanged.
        for field in ("routing_decision", "execution_contract", "qa_binding", "execution_sandbox", "authorized_api_cap_micro_usd", "native_fallback", "readonly_probe", "astra_readonly_review", "execution_workspace"):
            if field in context:
                package["task"][field] = context[field]
        if role == 'api_astra_review' and astra_review is not None:
            package['task']['astra_admission'] = copy.deepcopy(astra_review)
            if (context.get('astra_readonly_review') and 'readonly_probe' not in context
                    and ('qa_binding' not in context or qa_boundary == 'review_rules_v1')):
                package['task']['astra_fallback_transport'] = architecture_policy.ASTRA_PARENT_FALLBACK
                package['task']['astra_material_delivery'] = architecture_policy.ASTRA_MANIFEST_DELIVERY
                package['task']['astra_read_receipt'] = architecture_policy.ASTRA_READ_RECEIPT
        if local_bundle is not None:
            from personalization_loader import LocalPersonalization, PersonalizationError
            try:
                LocalPersonalization.freeze(local_bundle, folder)
            except (OSError, ValueError) as error:
                raise WorkerError("personalization_missing", str(error)) from error
            package["local_personalization"] = local_bundle
        package["integrity"] = {"package_sha256": digest(package), "task_input_sha256": digest(context), "material_manifest_sha256": digest(manifest)}
        atomic_json(folder / "context-package.json", package)
        return package

    def _read_package_metadata(self, task):
        package = json.loads(Path(task["package_path"]).read_text(encoding="utf-8"))
        body = {k: v for k, v in package.items() if k != "integrity"}
        need(digest(body) == task["package_hash"] == package["integrity"]["package_sha256"], "integrity_failure", "Frozen context package changed.")
        need(digest(package["role"]["canonical_role_prompt"].encode("utf-8")) == package["role"]["role_prompt_sha256"], "integrity_failure", "Frozen role prompt changed.")
        need(package['task'].get('astra_readonly_review')==task.get('astra_readonly_review'),
             'astra_readonly_mode_mismatch','The Astra material mode differs from its immutable package.')
        need(package['task'].get('astra_fallback_transport') == task.get('astra_fallback_transport'),
             'astra_fallback_transport_mismatch', 'The Astra transport differs from its immutable package.')
        if "local_personalization" in package:
            from personalization_loader import LocalPersonalization
            try:
                LocalPersonalization.verify(package["local_personalization"])
            except (OSError, ValueError) as error:
                raise WorkerError("integrity_failure", str(error)) from error
        return package

    @staticmethod
    def _read_frozen_material(material):
        path = Path(material["frozen_snapshot_reference"])
        message = "A frozen material is missing or changed."
        need(path.is_file() and not path.is_symlink(), "integrity_failure", message)
        raw = path.read_bytes()
        need(digest(raw) == material["sha256"], "integrity_failure", message)
        return raw

    def read_package(self, task):
        package = self._read_package_metadata(task)
        for material in package["evidence"]["source_material_manifest"]:
            self._read_frozen_material(material)
        return package

    def payload(self, task, package):
        content = [{"type": "input_text", "text": "Frozen task context package:\n" + canonical(package)}]
        for material in package["evidence"]["source_material_manifest"]:
            raw = self._read_frozen_material(material)
            media = material["media_type"]
            if media.startswith("image/"):
                content.append({"type": "input_image", "image_url": "data:" + media + ";base64," + base64.b64encode(raw).decode("ascii"), "detail": "high"})
            elif media == "application/pdf":
                content.append({"type": "input_file", "filename": material["original_name"], "file_data": "data:application/pdf;base64," + base64.b64encode(raw).decode("ascii")})
            else:
                content.append({"type": "input_text", "text": "Original material " + material["material_id"] + ":\n" + raw.decode("utf-8")})
        model, effort, _, _ = ROLES[task["role"]]
        limit = package_limits(task['role'], package)['output']
        return {"model": model, "reasoning": {"effort": effort}, "instructions": package["role"]["canonical_role_prompt"],
                "input": [{"role": "user", "content": content}], "max_output_tokens": limit,
                "store": package.get('task',{}).get('response_store',False), "background": False, "service_tier": "default", "truncation": "disabled",
                "prompt_cache_options": {"ttl": "30m"}}

    @staticmethod
    def execution_contract(role, context):
        contract = context.get("execution_contract")
        if contract is None and role not in ("api_astra_review","api_sol_qa", "api_sol_execution"):
            return  # Existing Luna/Terra callers remain compatible.
        need(isinstance(contract, dict) and contract.get("version") in ((3,4) if role=='api_sol_execution' else (1,2)),
             "execution_contract_invalid", "Supply execution_contract version1 legacy or version2 parent_main; Astra remains advisory only.")
        if role == 'api_sol_execution':
            native=contract['version']==4
            need(contract.get('mode') in (('candidate_implementation', 'workspace_implementation') if native else ('sandbox_implementation',))
                 and contract.get('allowed_effects')==(['workspace_execution','return_result']
                     if contract.get('mode')=='workspace_implementation' else
                     ['candidate_execution','return_result'] if native else ['sandbox_execution','return_result'])
                 and contract.get('worker_may_apply_changes') is (contract.get('mode')=='workspace_implementation')
                 and contract.get('implementation_owner')=='api_sol_execution'
                 and contract.get('final_acceptance_owner')=='parent_main',
                 'execution_contract_invalid','Sol may execute only in the bounded workspace; the owning parent validates and accepts.')
            if native:
                fallback=context.get('native_fallback',{})
                need(fallback.get('transport')=='native_subagent' and fallback.get('permission_boundary')=='inherits_parent'
                     and fallback.get('authorized') is True and meaningful(fallback.get('authorization_provenance')),
                     'native_execution_not_authorized','Explicitly authorize inherited-permission native execution for this frozen task.')
            sandbox=context.get('execution_sandbox')
            need(isinstance(sandbox,dict) and isinstance(sandbox.get('artifact_paths'),list) and 1<=len(sandbox['artifact_paths'])<=8
                 and all(isinstance(x,str) and x and not Path(x).is_absolute() and '..' not in Path(x).parts for x in sandbox['artifact_paths'])
                 and len(set(sandbox['artifact_paths']))==len(sandbox['artifact_paths']),
                 'execution_contract_invalid','Specify one to eight unique workspace-relative artifact paths.')
            if contract.get('mode') == 'workspace_implementation':
                paths = [Path(value) for value in sandbox['artifact_paths']]
                need(all(path.parts and not path.anchor and ':' not in str(path)
                         and path.parts[0].lower() not in ('.git', '.codex') for path in paths)
                     and len(set(paths)) == len(paths), 'execution_contract_invalid',
                     'In-place outputs must be distinct project-relative files outside protected metadata.')
            return
        owner='parent_main' if contract['version']==2 else 'parent_sol'
        need(contract.get("worker_may_apply_changes") is False and
             contract.get("allowed_effects") == ["return_result"] and
             contract.get("final_acceptance_owner") == owner,
             "execution_contract_invalid", "Content workers return results; the parent coordinator applies changes and accepts them.")
        need(contract.get("implementation_owner") in
             ((owner, "api_luna_batch") if contract['version']==2 else (owner, "api_luna_batch", "terra_desktop_native")),
             "execution_contract_invalid", "Name a non-Astra implementation owner within the authorized scope.")
        if role == "api_astra_review":
            need(contract.get("mode") in ("analysis", "review", "planning"),
                 "astra_implementation_forbidden", "Astra may analyze, review or plan; assign implementation to Sol/Luna/Terra.")
        if role == 'api_sol_qa':
            need(contract['version']==2 and contract.get('mode')=='review','qa_review_only',
                 'Sol QA must use version2 review/return_result only; main applies changes and accepts.')

    def astra_gate(self, review):
        need(isinstance(review, dict), "astra_not_admitted", "Provide the four-condition Astra justification and prior-review lookup.")
        for field in ("normalized_issue_identity", "project_or_artifact_scope", "substantive_question", "decision_impact",
                      "difficulty_justification", "acceptance_criteria", "prior_review_lookup", "route_budget_record"):
            need(meaningful(review.get(field)), "astra_not_admitted", "Missing Astra admission record: " + field)
        need(review.get("ordinary_task") is False and review.get("materials_sufficient") is True,
             "astra_not_admitted", "Routine work or missing required evidence cannot enter Astra.")
        need(review.get("all_four_conditions_met") is True, "astra_not_admitted", "All four substantive admission conditions are required.")
        normalized = re.sub(r"\s+", " ", review["normalized_issue_identity"].strip().casefold())
        scope = re.sub(r"\s+", " ", review["project_or_artifact_scope"].strip().casefold())
        return digest({"issue": normalized, "scope": scope})

    @staticmethod
    def duplicate_uncertain_work(tasks, *, task_id=None, parent, role, issue, evidence_hash):
        """Keep an unresolved execution authoritative for the same frozen work."""
        if not issue or not evidence_hash:
            return False
        return any(x.get('id') != task_id and x.get('parent_session_id') == parent
                   and x.get('role') == role and x.get('issue') == issue
                   and x.get('evidence_hash') == evidence_hash
                   and (x.get('status') == 'unknown_execution' or x.get('api_charge_uncertain') is True
                        or x.get('provider_execution_status') == 'unknown'
                        or x.get('prior_execution_unresolved') is True
                        or (x.get('api_attempt', 1) > 1 and bool(x.get('retry_started_in'))))
                   for x in tasks)

    @staticmethod
    def duplicate_active_work(tasks, *, task_id, parent, role, issue, evidence_hash):
        if not issue or not evidence_hash:
            return False
        return any(x.get('id') != task_id and x.get('parent_session_id') == parent
                   and x.get('role') == role and x.get('issue') == issue
                   and x.get('evidence_hash') == evidence_hash
                   and x.get('status') in ('preparing', 'api_running', 'unknown_execution')
                   for x in tasks)

    def historical_astra_qa(self, context, parent, materials, material_content, worker_db):
        """Admit only an exact, still-current pre-v5 controller QA binding."""
        binding = context.get('qa_binding')
        if not isinstance(binding, dict) or binding.get('reviewer_role') != 'qa_astra':
            return False
        path = self.root / 'orchestrator-control' / 'runtime' / 'state.sqlite'
        if not path.is_file():
            return False
        try:
            attached = any(row[1] == 'controller_guard' for row in worker_db.execute('PRAGMA database_list'))
            query = ('SELECT t.state,t.contract_version,t.risk,m.data,a.provider_request_id '
                     'FROM {schema}tasks t JOIN {schema}task_meta m ON m.task_id=t.task_id '
                     'JOIN {schema}attempts a ON a.task_id=t.task_id AND a.attempt_id=? '
                     'AND a.status=? WHERE t.task_id=?')
            arguments = (binding.get('author_attempt_id'), 'completed', binding.get('task_id'))
            if attached:
                row = worker_db.execute(query.format(schema='controller_guard.'), arguments).fetchone()
            else:
                with contextlib.closing(sqlite3.connect(path.as_uri() + '?mode=ro', uri=True)) as db:
                    row = db.execute(query.format(schema=''), arguments).fetchone()
            if not row:
                return False
            state, version, risk, raw, provider_id = row
            meta = json.loads(raw)
            author = meta.get('author') or {}
            snapshot = meta.get('snapshot') or {}
            owner = worker_db.execute('SELECT parent,role FROM tasks WHERE id=?', (provider_id,)).fetchone()
            rows = [('original', x) for x in meta.get('input_snapshots', [])] + [
                ('artifact', x) for x in snapshot.get('manifest', [])]
            expected = {f'{kind}-{index}': (str(Path(item['path']).resolve()), item['sha256'])
                        for index, (kind, item) in enumerate(rows)}
            if any(not Path(path).is_file() or Path(path).is_symlink()
                   or digest(Path(path).read_bytes()) != expected_hash
                   for path, expected_hash in expected.values()):
                return False
            focus = binding.get('astra_focus')
            if focus is not None:
                ids = focus.get('material_ids', []) if isinstance(focus, dict) else []
                if not ids or not set(ids).issubset(expected):
                    return False
                expected = {key: expected[key] for key in ids}
            actual = {item.get('material_id'): (str(Path(item['path']).resolve()), content[0])
                      for item, content in zip(materials, material_content)}
            return bool(len(materials) == len(material_content) == len(actual)
                        and actual == expected and owner and tuple(owner) == (parent, 'api_sol_execution')
                        and state in ('VALIDATING', 'REVIEWING') and risk in ('L2', 'L3')
                        and meta.get('architecture_profile') == 'mandatory_delegation_v3'
                        and author.get('role') == 'executor_sol'
                        and binding.get('contract_version') == version
                        and binding.get('author_attempt_id') == author.get('attempt_id')
                        and binding.get('author_session_id') == author.get('session_id')
                        and binding.get('artifact_hash') == snapshot.get('hash')
                        and all(binding.get(k) for k in ('task_id', 'artifact_hash', 'author_attempt_id', 'author_session_id')))
        except (OSError, ValueError, TypeError, sqlite3.Error):
            return False

    def astra_focus_gate(self, db, review, context, materials, material_content, parent):
        focus = review.get('focus')
        need(isinstance(focus, dict), 'astra_focus_required',
             'Submit one bounded question with explicitly selected criteria and evidence.')
        trigger = focus.get('trigger')
        fields = {'trigger', 'basis', 'criterion_ids', 'material_ids'}
        if trigger == 'sol_qa_uncertainty':
            fields |= {'sol_qa_task_id', 'sol_qa_result_sha256'}
        need(set(focus) == fields and meaningful(focus.get('basis'))
             and isinstance(focus['basis'], str)
             and isinstance(review['substantive_question'], str),
             'astra_focus_invalid', 'Record the concrete trigger, question and scope basis.')
        for field in ('criterion_ids', 'material_ids'):
            values = focus[field]
            need(isinstance(values, list) and bool(values)
                 and all(isinstance(value, str) and value.strip() for value in values)
                 and len(set(values)) == len(values), 'astra_focus_invalid',
                 'Criterion and material IDs must be explicit, nonempty and unique.')
        need(set(focus['material_ids']) == {material.get('material_id') for material in materials}
             and len(focus['material_ids']) == len(materials), 'astra_focus_material_mismatch',
             'Send exactly the selected frozen evidence for this question.')
        binding = context.get('qa_binding')
        if trigger == 'sol_authored_independence':
            need(isinstance(binding, dict) and binding.get('reviewer_role') == 'qa_astra'
                 and binding.get('astra_focus') == focus, 'astra_focus_binding_missing',
                 'The formal independent check must bind this focus to the current author and snapshot.')
            criteria = context.get('acceptance_criteria')
            need(isinstance(criteria, list)
                 and [row.get('id') for row in criteria if isinstance(row, dict)] == focus['criterion_ids'],
                 'astra_focus_criteria_mismatch', 'Deliver only the selected formal review criteria.')
            return focus
        need(trigger == 'sol_qa_uncertainty' and binding is None
             and isinstance(focus['sol_qa_task_id'], str), 'astra_focus_trigger_invalid',
             'Supplementary review is advisory and must reference a completed Sol QA finding.')
        prior = self.load(db, focus['sol_qa_task_id'])
        prior_result = prior.get('result') or {}
        report = prior_result.get('Result')
        need(prior['role'] == 'api_sol_qa' and prior['parent_session_id'] == parent
             and prior['status'] == 'completed' and isinstance(report, dict)
             and digest(prior_result) == focus['sol_qa_result_sha256'],
             'astra_focus_sol_receipt_invalid', 'Use the exact completed Sol QA result from this owning session.')
        uncertain = set(report.get('checked_criteria', [])) if report.get('verdict') == 'inconclusive' else {
            item.get('criterion_id') for item in report.get('findings', [])
            if item.get('certainty') == 'hypothesis' and item.get('status') == 'open'
        }
        need(set(focus['criterion_ids']) <= uncertain, 'astra_focus_sol_uncertainty_missing',
             'Escalate only criteria for which Sol recorded a concrete unresolved judgement.')
        prior_hashes = {item['sha256'] for item in self.read_package(prior)['evidence']['source_material_manifest']}
        need(bool(prior_hashes & {sha for sha, _ in material_content}), 'astra_focus_sol_evidence_mismatch',
             'Include evidence tied to the referenced Sol QA scope.')
        return focus

    def api_dispatch_retired(self):
        return True

    def readiness(self, config=None):
        return "api_route_retired"

    @staticmethod
    def public(task, reused=False):
        result = {k: v for k, v in task.items() if k not in ("fingerprint", "astra_review", "claim_token")}
        result["reused_existing_task"] = reused
        result["execution_evidence_scope"] = "local_ledger; native metadata must come from parent-observed execution records"
        return result

    def get_task(self, task_id):
        with self.transaction() as db:
            return self.public(self.load(db, task_id))


    def api_route_allowed(self, db, task, *, retry_preflight=False):
        receipt = api_balance.pinned_native_receipt(db,task['parent_session_id'])
        if receipt is None:
            return True
        task['api_credit_rejection_receipt'] = receipt
        if retry_preflight:
            return False
        loop=task.get('execution_loop',{})
        before_inference=(task['status'] in ('queued','preparing') or
                          (task['role']=='api_sol_execution' and loop.get('phase')=='ready'
                           and not loop['rounds'] and not loop['tools']))
        native=(before_inference and task.get('credit_route_version')==1
                and task.get('api_attempt',1)==1 and not task.get('validation_probe')
                and not task.get('api_charge_uncertain') and not task.get('charged_micro_usd'))
        if task.get('astra_readonly_review'):
            native=native and api_balance.confirmed_credit_receipt(receipt) and not task.get('api_dispatch_started_at')
        if native and task['role']=='api_sol_execution':
            try:
                native=self.read_package(task)['task']['execution_contract']['version']==4
            except (OSError, ValueError, KeyError, TypeError, WorkerError):
                native=False
        task.update(status='fallback_ready' if native else 'blocked',
                    reason=api_balance.SESSION_NATIVE_REASON,reserved_micro_usd=0)
        self.save(db,task)
        return False


    def update(self, task_id, **changes):
        with self.transaction() as db:
            task = self.load(db, task_id)
            task.update(changes)
            self.save(db, task)
            return task

    def update_owned_failure(self, task_id, owner_token, *, expected_attempt=None,
                             known_collection_failure=None, credit_rejection=None,
                             terminal_credit_response=None, **changes):
        """Settle only the owning attempt; local uncertainty otherwise wins."""
        with self.transaction() as db:
            task=self.load(db,task_id)
            if (task.get('owner_token')!=owner_token or
                expected_attempt is not None and task.get('api_attempt',1)!=expected_attempt or
                task['status'] not in ('preparing','api_running')):
                return task
            loop=task.get('execution_loop',{})
            # Only an explicit known runner failure for this exact collection
            # may release its slot. Recheck the operation inside the transaction;
            # a stale runtime snapshot must not settle another owner or attempt.
            known_collection=(owner_token is not None and expected_attempt is not None and
                              task.get('role')=='api_sol_execution' and task['status']=='api_running' and
                              loop.get('phase')=='artifact_collecting' and
                              known_collection_failure is not None and
                              known_collection_failure==(loop.get('collection_index'),loop.get('collection_source')) and
                              task.get('reason')!='tool_execution_unreconciled')
            if self.has_uncertain_local_execution(task) and not known_collection:
                # The journal's local execution phase is authoritative even if
                # the delegated runtime could not record its own failure.
                changes.update(status='unknown_execution',reason='sol_local_execution_unreconciled',
                               reserved_micro_usd=task.get('reserved_micro_usd',0),
                               api_charge_uncertain=task.get('api_charge_uncertain',False))
            elif credit_rejection is not None or terminal_credit_response is not None:
                if terminal_credit_response is not None:
                    receipt=api_balance.record_terminal_rejection(db,task,terminal_credit_response)
                else:
                    request_id, endpoint=credit_rejection
                    receipt=api_balance.record_rejection(db,task,request_id,endpoint=endpoint)
                changes['api_credit_rejection_receipt']=receipt
                if changes.get('status')!='unknown_execution':
                    if task.get('cancellation_requested'):
                        changes.update(status='cancelled',reason='cancelled_after_confirmed_rejection')
                    elif task.get('api_attempt',1)>1:
                        changes.update(status='blocked',reason='credit_rejection_after_unknown_attempt')
            if task.get('astra_readonly_review') and changes.get('status')=='fallback_ready' and (
                    changes.get('reason')!=api_balance.CREDIT_ERROR or credit_rejection is None
                    or credit_rejection[1]!='responses/input_tokens' or task.get('api_dispatch_started_at')):
                changes['status']='blocked'
            task.update(changes);self.save(db,task)
            return task

    @staticmethod
    def accounting_totals(tasks, cycle_start):
        # Outstanding reservations never disappear at a reporting-window change.
        # Known charges belong to the cycle in which dispatch was authorized.
        charged=sum(x.get('charged_micro_usd',0) for x in tasks
                    if x.get('budget_cycle_start')==cycle_start or
                    'budget_cycle_start' not in x and x.get('created_at',0)>=cycle_start)
        reserved=sum(x.get('reserved_micro_usd',0) for x in tasks)
        charged+=sum(x.get('closed_attempt_charges',{}).get(str(cycle_start),0) for x in tasks)
        return charged,reserved

    @staticmethod
    def dispatch_blocker(config,tasks,role=None,parent_session_id=None,*,routing_policy_version=None):
        """An uncertain execution retains its global slot and parent/role ownership."""
        uncertain=any(x['status']=='unknown_execution' or x.get('api_charge_uncertain') for x in tasks)
        if config.get('budget_mode','cumulative_and_per_task')!='per_task_only' and uncertain:
            return 'api_paused_for_uncertain_charge'  # Preserve legacy cumulative-budget semantics.
        if routing_policy_version == 5:
            return None
        if role and parent_session_id and any(x['role']==role and x.get('parent_session_id')==parent_session_id and x['status'] in ACTIVE for x in tasks):
            return 'role_busy_or_execution_unknown'
        occupied=sum(x['status'] in ('preparing','api_running','unknown_execution') for x in tasks)
        if occupied>=MAX_API_CONCURRENCY:return 'api_capacity_occupied'
        return None

    @staticmethod
    def effective_api_cap(config,task,package):
        role_cap=config['per_task_budget_micro_usd'].get(task['role'],0)
        policy=package_role_policy(task['role'],package)
        frozen=package['task'].get('frozen_role_cap_micro_usd', policy['cap'])
        requested=package['task'].get('authorized_api_cap_micro_usd',frozen)
        need(type(role_cap) is int and role_cap>0 and type(requested) is int and requested>0,
             'authorized_budget_invalid','Role and frozen task API caps must be positive integers.')
        need(type(frozen) is int and 0 < frozen <= policy['cap'], 'authorized_budget_invalid', 'Invalid frozen role cap.')
        return min(role_cap,requested,frozen,policy['cap'])


    @staticmethod
    def validate_result(task, result, package):
        need(isinstance(result, dict) and result.get("status") in ("completed", "missing_context"), "quality_failure", "Worker must return completed or missing_context.")
        need(all(k in result for k in ("Result", "Evidence", "Validation", "Blocker", "package_sha256", "received_material_ids")), "quality_failure", "Worker result contract is incomplete.")
        need(result["package_sha256"] == task["package_hash"], "quality_failure", "Worker did not acknowledge the frozen package identity.")
        required = {x["material_id"] for x in package["evidence"]["source_material_manifest"] if x["required"]}
        need(isinstance(result["received_material_ids"], list), "quality_failure", "Material receipts must be a list.")
        if result["status"] == "completed":
            need(required.issubset(set(result["received_material_ids"])), "quality_failure", "Required material receipts are incomplete.")
            if "local_personalization" in package:
                local = package["local_personalization"]
                validation = result.get("Validation")
                receipt = validation.get("local_personalization", {}) if isinstance(validation, dict) else {}
                for key, expected in (("instruction_source_ids", [x["source_id"] for x in local["instructions"]]), ("selected_rule_ids", local["selected_rule_ids"]), ("selected_skills", local["selected_skills"])):
                    actual = receipt.get(key)
                    need(isinstance(actual, list) and set(expected).issubset(set(actual)), "quality_failure", "Local personalization receipt missing: " + key)
        else:
            need(meaningful(result["Blocker"]), "quality_failure", "Specify the exact missing or unreadable context.")

    def claim_subscription_fallback(self, task_id, parent_session_id):
        self.require_not_maintenance()
        with self.transaction() as db:
            task = self.load(db, task_id)
            need(task["parent_session_id"] == parent_session_id, "claim_owner", "Only the submitting parent can claim this fallback.")
            need(task["status"] == "fallback_ready", "fallback_not_eligible", "Task is not eligible; do not repeat completed, claimed or uncertain work.")
            need(task['role'] in ROLES, 'role_retired', 'Retired worker records are available for history only.')
            need(task.get('api_attempt',1)==1, 'fallback_after_unknown_retry_forbidden',
                 'An API retry after an unknown attempt cannot authorize native fallback.')
            policy=architecture_policy.load(self.root)
            cutoff = (policy or {}).get('host_spawn_effective_at_epoch')
            need(not (cutoff and task['created_at'] >= cutoff), 'host_spawn_required',
                 'New eligible subscription work uses the owning Codex root and built-in spawn_agent. Review the recorded provider outcome first.')
            package = self.read_package(task)
            if task.get('historical_controller_qa'):
                manifest = package['evidence']['source_material_manifest']
                supplied = [{'path': m['provenance_locator'], 'material_id': m['material_id']} for m in manifest]
                hashes = [(m['sha256'], m['media_type']) for m in manifest]
                need(self.historical_astra_qa(package['task'], parent_session_id, supplied, hashes, db),
                     'historical_qa_binding_changed', 'Historical review scope or ownership changed before native claim.')
            native_direct = (
                task.get('reason')=='native_direct' and task.get('dispatch_mode')=='subscription_direct'
                and package['task'].get('dispatch_mode')=='subscription_direct'
                and (task['role'] in architecture_policy.NATIVE_DIRECT_ROLES or architecture_policy.astra_direct_task(task))
                and task.get('api_attempt',1)==1 and not task.get('execution_loop')
                and not task.get('api_dispatch_started_at') and not task.get('charged_micro_usd')
                and not task.get('reserved_micro_usd') and not task.get('api_charge_uncertain')
            )
            if task.get('dispatch_mode')=='subscription_direct':
                need(native_direct,'native_only_task','Direct native claim does not match its frozen route.')
            if task.get('reason')==api_balance.CREDIT_ERROR:
                need(task.get('api_attempt',1)==1,'credit_rejection_after_unknown_attempt',
                     'A new credit rejection cannot authorize native replay of a previously unknown attempt.')
            credit_route = (
                task.get('reason')==api_balance.SESSION_NATIVE_REASON and task.get('api_attempt',1)==1
                and task.get('credit_route_version')==1 and not task.get('api_dispatch_started_at')
                and not task.get('execution_loop',{}).get('rounds')
                and not task.get('execution_loop',{}).get('tools')
                and not task.get('reserved_micro_usd') and not task.get('charged_micro_usd')
                and task.get('api_credit_rejection_receipt') is not None
                and task['api_credit_rejection_receipt']==api_balance.pinned_native_receipt(db,parent_session_id)
            )
            if task.get('astra_readonly_review'):
                receipt=task.get('api_credit_rejection_receipt') or {}
                exact_count_rejection=(task.get('reason')==api_balance.CREDIT_ERROR and receipt.get('task_id')==task_id
                                       and receipt.get('attempt')==1 and receipt.get('http_status')==429
                                       and receipt.get('endpoint')=='responses/input_tokens')
                need(package['task'].get('astra_readonly_review')==task['astra_readonly_review']
                     and api_balance.confirmed_credit_receipt(receipt)
                     and (credit_route or exact_count_rejection) and task.get('api_attempt',1)==1
                     and not task.get('native_dispatch') and not task.get('api_dispatch_started_at') and not task.get('api_charge_uncertain')
                     and not task.get('charged_micro_usd') and not task.get('reserved_micro_usd'),
                     'astra_readonly_credit_required','Only confirmed API credit exhaustion can authorize this read-only fallback.')
            if policy and policy.get('profile') in ('mandatory_delegation_v3', 'simplified_workflow_v5') and task.get('created_at',0)>=policy['effective_at_epoch']:
                eligible=ELIGIBLE_CODES | {'api_budget_insufficient_before_dispatch','confirmed_pre_inference_provider_unavailable'}
                need((task.get('reason') in eligible or credit_route or native_direct) and not task.get('api_charge_uncertain'), 'fallback_reason_ineligible',
                     'Disabled, changed, refused, uncertain, or unverified execution is not a fallback authorization.')
            if task['role']=='api_sol_execution':
                self.execution_contract(task['role'],package['task'])
                need(package['task']['execution_contract']['version']==4,'native_execution_parity_unverified',
                     'Historical v3 sandbox-only tasks cannot change their frozen permission boundary.')
                need((credit_route or native_direct or task.get('reason') in ELIGIBLE_CODES | {'api_budget_insufficient_before_dispatch','confirmed_pre_inference_provider_unavailable'})
                     and not task.get('api_charge_uncertain'),'fallback_reason_ineligible',
                     'Native execution requires a confirmed eligible fallback reason or a session credit rejection.')
            active_rows = db.execute("SELECT data FROM tasks WHERE parent=? AND status IN ('preparing','api_running','fallback_claimed','unknown_execution')", (parent_session_id,)).fetchall()
            active_tasks = [json.loads(row[0]) for row in active_rows]
            if task.get('routing_policy_version') == 5:
                all_rows = db.execute('SELECT data FROM tasks WHERE parent=? AND role=? AND issue=?',
                                      (parent_session_id, task['role'], task.get('issue', ''))).fetchall()
                need(not self.duplicate_uncertain_work((json.loads(row[0]) for row in all_rows),
                         task_id=task['id'], parent=parent_session_id, role=task['role'],
                         issue=task.get('issue'), evidence_hash=task.get('evidence_hash')),
                     'duplicate_uncertain_execution', 'Reconcile the same unresolved execution before native claim.')
                # Existing pre-v5 ownership remains exclusive; an unknown same-role
                # execution is retained until reconciled, never silently superseded.
                need(not any(x.get('routing_policy_version') != 5 and x['status'] == 'fallback_claimed' for x in active_tasks),
                     'native_slot_busy', 'A historical native claim retains its frozen exclusive ownership.')
                need(not any(x['role'] == task['role'] and x['status'] == 'unknown_execution' for x in active_tasks),
                     'role_busy', 'Reconcile the existing uncertain execution before same-role continuation.')
            else:
                need(not any(x['status'] == 'fallback_claimed' for x in active_tasks), "native_slot_busy", "The parent session already has a claimed native fallback.")
                need(not any(x['role'] == task['role'] for x in active_tasks), "role_busy", "The same parent and role have active or uncertain work.")
            model, effort, native, _ = ROLES[task["role"]]
            token = secrets.token_urlsafe(24)
            native_input = {"canonical_role_prompt": package["role"]["canonical_role_prompt"], "context_package": package}
            if package['task'].get('astra_material_delivery') != architecture_policy.ASTRA_MANIFEST_DELIVERY:
                native_input["text_materials"] = [
                    {"material_id": item["material_id"],
                     "content": Path(item["frozen_snapshot_reference"]).read_text(encoding="utf-8")}
                    for item in package["evidence"]["source_material_manifest"]
                    if item["media_type"].startswith("text/") or item["media_type"] == "application/json"
                ]
            in_place_workspace = None
            frozen = package['task']
            if task['role'] == 'api_sol_execution':
                need(frozen['execution_contract']['mode'] == 'workspace_implementation',
                     'legacy_native_workspace_creation_disabled',
                     'The old contract is preserved. This installation no longer creates legacy native workspaces.')
            if task['role'] == 'api_sol_execution' and frozen['execution_contract']['mode'] == 'workspace_implementation':
                in_place_workspace = self.workspace_for_owner(parent_session_id)
                need(str(in_place_workspace) == frozen.get('execution_workspace'), 'native_workspace_changed',
                     'The owning chat workspace changed after submission.')
                paths = {in_place_workspace / name for name in frozen['execution_sandbox']['artifact_paths']}
                for output in paths:
                    need(output.resolve().is_relative_to(in_place_workspace) and all(
                         not path.is_symlink() and not path.is_junction()
                         for path in (output, *output.parents) if path.is_relative_to(in_place_workspace)),
                         'native_workspace_output_invalid', 'A declared output escapes the workspace or traverses a link.')
                for row in db.execute("SELECT data FROM tasks WHERE status IN ('fallback_claimed','unknown_execution')"):
                    other = json.loads(row[0]).get('native_execution', {})
                    if other.get('mode') != 'in_place':
                        continue
                    occupied = {Path(other['workspace']) / name for name in other['artifact_paths']}
                    need(not any(a.is_relative_to(b) or b.is_relative_to(a) for a in paths for b in occupied),
                         'native_workspace_output_busy', 'An active claim already owns an overlapping output path.')
            native_file = Path(task["package_path"]).with_name("subscription-input.json")
            atomic_json(native_file, native_input)
            native_input_hash = digest(native_file.read_bytes())
            task.update(status="fallback_claimed", claim_token=token, route="subscription", native_role=native,
                        native_input_path=str(native_file), native_input_sha256=native_input_hash)
            if native=='astra_review_subscription':
                task['requires_readonly_ack']=True
            if native in ('sol_qa_subscription','luna_batch_subscription') or architecture_policy.astra_parent_fallback(task):
                task['requires_managed_resume_ack']=True
            if native=='sol_execution_subscription' or native_direct or task.get('requires_managed_resume_ack'):
                task['requires_chat_ack']=True
            if task['role']=='api_sol_execution':
                task['native_execution']={'workspace':str(in_place_workspace),'permission_boundary':'inherits_parent',
                                          'os_isolation_claimed':False,'transport_receipt_required':True}
                task['native_execution'].update(mode='in_place', artifact_paths=frozen['execution_sandbox']['artifact_paths'])
            self.save(db, task)
            return {"task_id": task_id, "logical_review_id": task["logical_review_id"], "claim_token": token,
                    "model": model, "reasoning_effort": effort, "fork_turns": "none", "native_role": native,
                    "package_hash": task["package_hash"], "native_input_path": str(native_file), "native_input_sha256": native_input_hash,
                    "frozen_materials": package["evidence"]["source_material_manifest"],
                    "spawn_message": None if task.get('requires_readonly_ack') or task.get('requires_chat_ack') else "Use independent context. Read the complete UTF-8 JSON file at " + str(native_file) +
                    ". Apply canonical_role_prompt and context_package as supplied. Read/view every required frozen original listed there, including binary images/PDFs, before substantive work. Return the specified JSON output and exact package hash. If essential context is missing, return missing_context. Do not recursively delegate, run generated code, edit originals or fetch unrelated sources. The parent integrates the result."}

    def prepare_subscription_dispatch(self, task_id, parent_session_id, claim_token, task_name, project_root=None):
        """Return exact frozen receipt-first transport for the existing claim."""
        self.require_not_maintenance()
        import importlib.util
        import sys
        routing_dir = str(self.root / 'routing')
        if routing_dir not in sys.path:
            sys.path.insert(0, routing_dir)
        module_path = self.root / 'routing/content_dispatch.py'
        spec = importlib.util.spec_from_file_location('hybrid_content_dispatch', module_path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module.ContentDispatch(self.root,ledger_path=self.database,
                                      runtime_home=Path(os.environ.get('CODEX_HOME',str(Path.home()/'.codex')))).prepare(task_id, parent_session_id, claim_token, task_name, project_root)

    def complete_subscription_fallback(self, task_id, claim_token, native_evidence, result):
        with self.transaction() as db:
            task = self.load(db, task_id)
            if task["status"] in ("completed", "missing_context") and secrets.compare_digest(task.get("claim_token", ""), claim_token):
                need(task.get("result") == result and task.get("native_evidence") == native_evidence, "completion_conflict", "A completed claim cannot be replaced by different output.")
                return self.public(task, reused=True)
            need(task['role'] in ROLES,'role_retired','Retired worker records are available for history only.')
            need(task["status"] == "fallback_claimed" and secrets.compare_digest(task.get("claim_token", ""), claim_token), "claim_invalid", "Fallback claim is not active or token differs.")
            transport = task.get('native_dispatch')
            if task.get('requires_readonly_ack') or task.get('requires_chat_ack'):
                need(transport and transport.get('receipt_order',{}).get('policy')=='readonly_chat_ack',
                     'native_transport_not_activated','This native attempt requires parent-verified chat acknowledgement.')
            if task['role']=='api_sol_execution':
                need(transport is not None,'native_transport_not_activated','Execution fallback requires receipt-first activation.')
            if transport is not None:
                need(transport.get('phase') == 'active' and transport.get('child_id') == native_evidence.get('native_thread_id')
                     and transport.get('native_input_sha256') == task['native_input_sha256']
                     and transport.get('receipt_order', {}).get('passed') is True,
                     'native_transport_not_activated', 'Receipt-first content transport must be activated for this exact native child and frozen input.')
            native_path = Path(task["native_input_path"])
            need(native_path.is_file() and digest(native_path.read_bytes()) == task["native_input_sha256"],
                 "integrity_failure", "Subscription handoff input was modified after the claim.")
            model, effort, _, _ = ROLES[task["role"]]
            need(native_evidence.get("native_thread_id") and native_evidence.get("execution_record_reference") and
                 native_evidence.get("actual_model") == model and native_evidence.get("actual_reasoning_effort") == effort,
                 "native_metadata_missing", "Record actual parent-observed native thread/model/effort evidence; self-description is insufficient.")
            package = self.read_package(task)
            self.validate_result(task, result, package)
            astra_direct=architecture_policy.astra_direct_task(task)
            astra_parent=architecture_policy.astra_parent_fallback(task)
            if astra_parent:
                need(transport and not transport.get('host_session_id')
                     and transport.get('sol_plaintext_activation_sha256')
                     and transport.get('resume_dispatch', {}).get('plaintext_first_read_version') == 1
                     and native_evidence.get('permission_boundary') == 'inherits_parent'
                     and native_evidence.get('os_isolation_claimed') is False
                     and native_evidence.get('reviewed_artifacts_read_only_verified') in (None, False)
                     and 'isolation_evidence_ref' not in native_evidence,
                     'native_astra_parent_boundary_mismatch',
                     'Record the direct child and its inherited permissions without an isolation claim.')
            if astra_parent or (package['task'].get('dispatch_mode')=='subscription_direct' and not astra_direct) or (
                    result['status']=='completed' and (task.get('requires_managed_resume_ack') or
                    transport and transport.get('sol_resume_echo_required'))):
                import sys
                routing_dir=str(self.root/'routing')
                if routing_dir not in sys.path:
                    sys.path.insert(0,routing_dir)
                from receipt_order import verify_sol_resume_echo
                from sol_qa_rules import MaterialCoverageError, observed_review_evidence
                try:
                    runtime_home=Path(os.environ.get('CODEX_HOME',str(Path.home()/'.codex')))
                    if transport.get('sol_plaintext_activation_sha256'):
                        from content_dispatch import verify_plaintext_activation
                        verify_plaintext_activation(transport)
                    direct_sol_execution = (package['task'].get('dispatch_mode') == 'subscription_direct'
                                            and task['role'] == 'api_sol_execution')
                    verify_sol_resume_echo(transport['child_id'], transport['resume_message'],
                                           transport['resume_dispatch'], runtime_home,
                                           allow_parent_messages=direct_sol_execution)
                    if astra_parent:
                        from desktop_dispatch import runtime_identity
                        from receipt_order import runtime_transcript
                        child = transport['child_id']
                        actual = runtime_identity(child, runtime_home)
                        need(actual.get('parent_id') == task['parent_session_id']
                             and actual.get('task_name') == transport['task_name']
                             and actual.get('role') == 'astra_review_subscription'
                             and (actual.get('model'), actual.get('effort')) == (model, effort)
                             and actual.get('is_child') is True
                             and Path(native_evidence['execution_record_reference']).resolve()
                             == runtime_transcript(child, runtime_home).resolve(),
                             'native_astra_parent_identity_mismatch',
                             'Actual child identity and trace must bind the owning parent.')
                    if astra_parent or (task['role']=='api_sol_qa' and result['status']=='completed'
                            and package['task'].get('native_qa_boundary')=='review_rules_v1'):
                        transport['qa_rule_evidence']=observed_review_evidence(task,package,runtime_home,result)
                except MaterialCoverageError as error:
                    raise WorkerError('native_material_coverage_incomplete', str(error)) from error
                except (ValueError,OSError,KeyError,TypeError,sqlite3.Error) as error:
                    raise WorkerError('native_resume_unverified',
                                      'Actual managed native continuation could not be verified.') from error
            astra_bound=astra_direct or bool(task.get('astra_readonly_review')) and not astra_parent
            if astra_bound or (transport and transport.get('opaque_resume_echo_required') and result['status']=='completed'):
                need(transport and transport.get('resume_dispatch')
                     and (not astra_bound or transport['resume_dispatch'].get('plaintext_first_read_version')==2),
                     'native_readonly_resume_unverified',
                     'Completed native Astra review requires its one-shot read-only continuation.')
                import sys
                routing_dir=str(self.root/'routing')
                if routing_dir not in sys.path:
                    sys.path.insert(0,routing_dir)
                from receipt_order import verify_resume_echo
                try:
                    runtime_home=Path(os.environ.get('CODEX_HOME',str(Path.home()/'.codex')))
                    transport['system_readonly']=verify_resume_echo(
                        transport['child_id'],transport['resume_message'],transport['resume_dispatch'],runtime_home)
                    if astra_bound and result['status']=='completed':
                        path=Path(transport['handoff_path']).with_name('readonly-isolation-evidence.json')
                        need(native_evidence.get('reviewed_artifacts_read_only_verified') is True
                             and native_evidence.get('isolation_evidence_ref')==str(path)
                             and path.is_file() and not path.is_symlink(),
                             'native_readonly_evidence_missing','Use the verified owning carrier collection.')
                        isolated=json.loads(path.read_bytes())
                        need(isolated.get('owner_session_id')==task['parent_session_id']
                             and isolated.get('host_session_id')==transport.get('host_session_id')
                             and isolated.get('child_identity',{}).get('id')==transport['child_id']
                             and isolated.get('package_sha256')==task['package_hash'],
                             'native_readonly_evidence_missing','The carrier evidence does not bind the frozen owner and child.')
                    if astra_direct and result['status']=='completed':
                        from readonly_host import verify_public_probe
                        from receipt_order import runtime_transcript
                        trace=runtime_transcript(transport['child_id'],runtime_home)
                        with trace.open(encoding='utf-8') as stream:
                            probe=verify_public_probe(package,[json.loads(line) for line in stream],task)
                        need(probe and native_evidence.get('reviewed_artifacts_read_only_verified') is True,
                             'native_readonly_probe_missing','Direct qualification requires an actual system write denial.')
                except (ValueError,OSError,KeyError,TypeError,sqlite3.Error) as error:
                    raise WorkerError('native_readonly_resume_unverified',
                                      'Actual native Astra read-only resume could not be verified.') from error
            if task['role']=='api_sol_execution':
                need(package['task']['execution_contract']['version']==4
                     and native_evidence.get('permission_boundary')=='inherits_parent'
                     and native_evidence.get('os_isolation_claimed') is False,
                     'native_execution_boundary_mismatch','Record the actual inherited native permission boundary.')
                if result['status']=='completed':
                    need(native_evidence.get('actual_execution_verified') is True,
                         'native_execution_unverified','Parent must inspect actual native execution records.')
                    if package['task']['execution_contract']['mode'] == 'workspace_implementation':
                        artifacts = native_evidence.get('workspace_artifacts')
                        verify_workspace_artifacts(task, package, artifacts)
                        task['workspace_artifacts'] = artifacts
                    else:
                        candidates=native_evidence.get('candidate_artifacts')
                        verify_native_candidate_artifacts(task,package,candidates)
                        task['candidate_artifacts']=candidates
            task.update(status="missing_context" if result["status"] == "missing_context" else "completed", result=result,
                        native_evidence=native_evidence, native_metadata_verification="parent_observed_not_independently_queried_by_service",
                        subscription_usage=native_evidence.get("usage", "unknown"))
            if transport is not None:
                task['native_dispatch']['phase'] = 'completed'
            self.save(db, task)
            return self.public(task)

    def finish_interaction_task(self, task_id, parent_session_id, interaction_id,
                                expected_attempt, retry_mode):
        """Parent finalization, after the last task observation in an interaction."""
        need(isinstance(interaction_id,str) and interaction_id.strip()
             and retry_mode in ('ask','goal_next_interaction'),
             'interaction_invalid','Supply the current interaction and its retry mode.')
        with self.transaction() as db:
            task=self.load(db,task_id)
            need(task['parent_session_id']==parent_session_id,'interaction_owner','Only the owning parent may finalize.')
            attempt=task.get('api_attempt',1)
            need(type(expected_attempt) is int and attempt==expected_attempt,
                 'interaction_attempt_changed','The current API attempt differs from the observed attempt.')
            if task['status']=='interaction_failed' and task['retry_after_interaction']==interaction_id:
                return self.public(task,reused=True)
            need(task['status']=='unknown_execution','interaction_state','Only an observed unknown API task may be finalized.')
            if task['role']=='api_astra_review':
                self.read_package(task)
            self.require_no_uncertain_local_execution(task)
            charges=dict(task.get('closed_attempt_charges',{}))
            charge=task.get('charged_micro_usd',0)
            if charge:
                cycle=str(task.get('budget_cycle_start',self.current_config().get('cycle_start') or 0))
                charges[cycle]=charges.get(cycle,0)+charge
            # Replace attempt state in the same row. Keep only stable package and accounting fields.
            keys=('id','request_id','fingerprint','role','parent_session_id','issue','evidence_hash',
                  'logical_review_id','astra_review','package_path','package_hash','created_at',
                  'personalization_receipt','validation_probe','credit_route_version','api_credit_rejection_receipt',
                  'astra_readonly_review','astra_fallback_transport','routing_policy_version','historical_controller_qa',
                  'prior_execution_unresolved')
            failed={key:task[key] for key in keys if key in task}
            response_id=task.get('response_id')
            if isinstance(response_id,str) and re.fullmatch(r'resp_[A-Za-z0-9_]{1,160}',response_id):
                failed['pending_stored_response_id']=response_id
            unsettled=task.get('reserved_micro_usd',0)
            if task.get('role') == 'api_sol_execution':
                from sol_execution_journal import compact_rounds
                history=list(task.get('request_forensics', []))
                rounds=compact_rounds(task)
                if rounds: history.append({'attempt':attempt,'rounds':rounds})
                failed['request_forensics']=history
                unsettled=max([unsettled, *(row.get('observed_cost_micro_usd',0) for row in rounds)])
            failed.update(status='interaction_failed',reason='api_result_unknown_at_interaction_end',
                          api_attempt=attempt,retry_after_interaction=interaction_id,retry_mode=retry_mode,
                          closed_attempt_charges=charges,charged_micro_usd=0,reserved_micro_usd=0,
                          interaction_unsettled_micro_usd=task.get('interaction_unsettled_micro_usd',0)+unsettled,
                          provider_execution_status='unknown',actual_provider_charge='unknown',
                          prior_execution_unresolved=True)
            self.save(db,failed)
            return self.public(failed)

    @staticmethod
    def has_uncertain_local_execution(task):
        phase=task.get('execution_loop',{}).get('phase')
        return (phase in ('unknown_tool','tool_running','artifact_collecting')
                or task.get('reason')=='tool_execution_unreconciled')

    def require_no_uncertain_local_execution(self,task):
        need(not self.has_uncertain_local_execution(task),
             'local_execution_unreconciled',
             'Preserve the task and slot until the local tool or collection process is reconciled.')


    def release_unknown_after_parent_closed(self, task_id, evidence):
        """Release local capacity only; retain provider outcome/cost uncertainty.

        Internal candidate method, not a public MCP endpoint or automatic hook.
        A trusted host-supplied verifier must confirm the exact parent is closed.
        """
        need(callable(self.parent_close_verifier), 'parent_closure_unverified',
             'No trusted session-closure verifier is available; retain the task.')
        with self.transaction() as db:
            task=self.load(db,task_id)
            need(task['status']=='unknown_execution', 'cleanup_state_invalid', 'Only unknown execution can use this closeout.')
            self.require_no_uncertain_local_execution(task)
            try:
                verified=self.parent_close_verifier(task['parent_session_id'],evidence)
            except Exception as error:
                raise WorkerError('parent_closure_unverified','Parent closure verification failed; retain the task.') from error
            need(isinstance(verified,dict) and verified.get('parent_session_id')==task['parent_session_id']
                 and verified.get('closed') is True and isinstance(verified.get('evidence_reference'),str)
                 and meaningful(verified.get('evidence_reference')),
                 'parent_closure_unverified','Trusted evidence must prove closure of this exact parent session.')
            amount=task.get('reserved_micro_usd',0)
            need(type(amount) is int and amount>=0,'cleanup_accounting_invalid','Original reservation is invalid.')
            task.update(status='parent_closed_unknown',local_outcome='failed_no_result',
                        provider_execution_status='unknown',actual_provider_charge='unknown',
                        unsettled_liability_micro_usd=amount,reserved_micro_usd=0,api_charge_uncertain=True,
                        parent_closeout={'evidence_reference':verified['evidence_reference'],'verified_parent_session_id':task['parent_session_id']})
            self.save(db,task)
            return self.public(task)

    def cancel_task(self, task_id, reconciliation=None):
        with self.transaction() as db:
            task = self.load(db, task_id)
            if reconciliation:
                need(task["status"] in ("unknown_execution", "fallback_claimed"), "reconcile_state", "Only uncertain or abandoned claims need explicit reconciliation.")
                need(reconciliation.get("evidence_reference") and reconciliation.get("confirmed_not_running") is True,
                     "reconcile_evidence", "An actual execution-status evidence reference is required; elapsed time alone is insufficient.")
                need(reconciliation.get("outcome") in ("terminal_unsuccessful", "completed", "cancelled"), "reconcile_outcome", "Specify the observed terminal outcome.")
                outcome = reconciliation["outcome"]
                task["reconciliation"] = reconciliation
                task["status"] = "fallback_ready" if outcome == "terminal_unsuccessful" else "completed_observed" if outcome == "completed" else "cancelled"
                task.pop("claim_token", None)
                if "confirmed_api_charge_micro_usd" in reconciliation:
                    charge = reconciliation["confirmed_api_charge_micro_usd"]
                    need(type(charge) is int and charge >= 0 and reconciliation.get("billing_evidence_reference"),
                         "billing_evidence", "A reconciled charge requires a nonnegative micro-USD amount and billing evidence.")
                    task.update(reserved_micro_usd=0, charged_micro_usd=charge, api_charge_uncertain=False)
                # Uncertain API charges remain reserved until separately reconciled.
            elif task["status"] in ("queued", "preparing", "fallback_ready"):
                task.update(status="cancelled", reason="user_cancellation")
            elif task["status"] in ("api_running", "unknown_execution", "fallback_claimed"):
                task["cancellation_requested"] = True
                task["reason"] = "stop_requested_execution_not_confirmed_stopped"
            self.save(db, task)
            return self.public(task)

    def get_usage(self):
        config = self.current_config()
        policy=architecture_policy.load(self.root)
        v5=(policy or {}).get('version')==5
        with self.transaction() as db:
            tasks = [json.loads(x[0]) for x in db.execute("SELECT data FROM tasks")]
            credit_pins = {row[0] for row in db.execute("SELECT key FROM control WHERE key GLOB 'api_credit_exhausted_v1:*'")}
        start = config.get("cycle_start") or 0
        charged,reserved=self.accounting_totals(tasks,start)
        uncertain = [x['id'] for x in tasks if x['status']=='unknown_execution' or x.get('api_charge_uncertain')]
        return {"live_enabled": False, "api_blocker": self.readiness(config),
                "runtime_root": str(self.root), "runbook_path": str(self.root / "RUNBOOK.md"),
                "budget_mode": config.get("budget_mode", "cumulative_and_per_task"),
                "local_cumulative_cap_enabled": config.get("cycle_budget_micro_usd") is not None,
                "local_cycle_budget_micro_usd": config.get("cycle_budget_micro_usd"),
                "per_task_budget_micro_usd": {role:cap for role,cap in (config.get("per_task_budget_micro_usd") or {}).items() if role in ROLES},
                "conservative_api_estimate_micro_usd": charged,
                "reserved_micro_usd": reserved,
                "closed_parent_unsettled_liability_micro_usd": sum(x.get('unsettled_liability_micro_usd',0) for x in tasks),
                "interaction_unsettled_liability_micro_usd": sum(x.get('interaction_unsettled_micro_usd',0) for x in tasks),
                "interaction_retries": [],
                "states": {state: sum(x["status"] == state for x in tasks) for state in sorted({x["status"] for x in tasks})},
                "subscription_tasks": sum(x.get("route") == "subscription" for x in tasks),
                "official_promotional_balance": "unknown", "platform_billing_reconciled": False,
                "api_credit_route": {"trigger":"HTTP 429 or confirmed terminal failure with credit_balance_exhausted",
                                     "native_pinned_sessions":len(credit_pins)},
                "astra_readonly_api_first": (policy or {}).get("astra_readonly_api_first") is True,
                "native_direct_roles": sorted((policy or {}).get('native_direct_roles',[])),
                "native_direct_qualification": (policy or {}).get('release_status')=='qualification_in_progress',
                "native_slots": ("V5 allows separate native claims; historical claims and actual exclusive resources retain their ownership." if v5 else "One fallback claim per parent; desktop native work must share the Codex parent concurrency cap."),
                "semantic_admission": "The parent evaluates substantive merit; service checks records, identity and budget.",
                "cost_unit": "micro_USD; estimates are conservative, not provider billing or credit-pool attribution",
                "personalization_loader_version": 1,
                "execution_contract_version": 1,
                "supported_execution_contract_versions": [1,2,3,4],
                "execution_capabilities": {
                    "api_sol_execution": {
                        "contract_versions": [3,4],
                        "enabled_for_new_tasks": bool(policy and policy.get('profile') in ('mandatory_delegation_v3','simplified_workflow_v5')
                                                      and not architecture_policy.native_direct(policy,'api_sol_execution')),
                        "effect_scope": "owning_chat_workspace_for_new_v5; frozen_legacy_scope_preserved",
                        "native_fallback_verified": False,
                        "native_inherited_permission_route_supported": True,
                        "native_fallback_requires": "explicit v4 authorization, eligible API failure, atomic claim, receipt activation and actual execution evidence",
                        "native_fallback_blocker": "v3_requires_os_parity; v4_requires_explicit_inherited_permission_authorization",
                    },
                },
                "coordinator_policy": policy,
                "max_input_tokens": config.get("max_input_tokens", MAX_INPUT_TOKENS),
                "role_policy_version": config.get('role_policy_version', 2),
                "role_request_limits": {role: frozen_role_policy(role, config) for role in ROLES},
                "effective_role_budget_micro_usd": {role: min(frozen_role_policy(role, config)['cap'], config.get('per_task_budget_micro_usd', {}).get(role, 0)) for role in ROLES},
                "approved_input_token_ceiling": MAX_INPUT_TOKENS,
                "input_limit_version": config.get('role_policy_version', 2),
                "scalar_input_limit_scope": "legacy metadata; role_request_limits governs new version 3 tasks",
                "subscription_transport_version": 1,
                "api_transport_version": 2,
                "api_request_timeout_seconds": config.get('api_request_timeout_seconds',900),
                "api_streaming_roles": config.get('api_streaming_roles',['api_astra_review']),
                "api_dispatch_blocker": self.readiness(config) or self.dispatch_blocker(config,tasks,routing_policy_version=5 if v5 else None),
                "api_dispatch_blockers_by_role": {role:('native_direct_for_new_tasks' if architecture_policy.native_direct(policy,role)
                    else 'main_owned_work' if not architecture_policy.new_api_role_allowed(policy,role)
                    else self.readiness(config) or self.dispatch_blocker(config,tasks,routing_policy_version=5 if v5 else None)) for role in ROLES},
                "active_parent_sessions_by_role": {role: sorted({x['parent_session_id'] for x in tasks if x['role']==role and x['status'] in ACTIVE}) for role in ROLES},
                "role_limit_scope": ("V5 has no general parent-role count limit; unknown and legacy ownership are preserved." if v5 else "one active task per parent session and role"),
                "api_occupied_slots": sum(x['status'] in ('preparing','api_running','unknown_execution') for x in tasks),
                "max_api_concurrency": None if v5 else MAX_API_CONCURRENCY,
                "legacy_max_api_concurrency": MAX_API_CONCURRENCY,
                "uncertainty_scope": 'parent interaction finalization releases local reservations; provider cost uncertainty is separate',
                "uncertain_task_ids": uncertain,
                "personalization_enabled": (self.root / "personalization-policy.json").is_file()}

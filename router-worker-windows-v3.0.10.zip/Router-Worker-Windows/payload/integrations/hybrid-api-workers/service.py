"""Minimal MCP stdio entrypoint. stdout is reserved exclusively for JSON-RPC."""
import argparse
import json
from pathlib import Path
import sys

from worker_core import Engine, WorkerError

def object_schema(properties, required):
    return {"type": "object", "properties": properties, "required": required, "additionalProperties": False}


STR = {"type": "string", "minLength": 1}
OBJ = {"type": "object"}
TOOLS = [
    {"name": "finish_interaction_task", "description": "Owning parent only: replace an observed unknown API attempt with a failed state before finalizing this interaction, release its local reservation, and record the next-interaction retry policy.",
     "inputSchema": object_schema({"task_id": STR, "parent_session_id": STR, "interaction_id": STR, "expected_attempt": {"type":"integer","minimum":1}, "retry_mode": {"enum":["ask","goal_next_interaction"]}}, ["task_id","parent_session_id","interaction_id","expected_attempt","retry_mode"])},
    {"name": "get_task", "description": "Read durable task state/result; never calls a model.", "inputSchema": object_schema({"task_id": STR}, ["task_id"])},
    {"name": "cancel_task", "description": "Cancel undispatched work or record a stop request. Optional reconciliation needs actual terminal-status evidence; timeout alone cannot release a claim or unknown execution.", "inputSchema": object_schema({"task_id": STR, "reconciliation": OBJ}, ["task_id"])},
    {"name": "get_usage", "description": "Read local reservations/estimates and setup blockers; not an official balance query.", "inputSchema": object_schema({}, [])},
    {"name": "claim_subscription_fallback", "description": "Atomically claim only eligible, unexecuted/terminal-unsuccessful work for the exact same model/effort/package/originals. Parent alone starts one independent native agent.", "inputSchema": object_schema({"task_id": STR, "parent_session_id": STR}, ["task_id", "parent_session_id"])},
    {"name": "complete_subscription_fallback", "description": "Complete a claimed native task with parent-observed actual thread/model/effort records and result JSON; no fabricated API usage.", "inputSchema": object_schema({"task_id": STR, "claim_token": STR, "native_evidence": OBJ, "result": OBJ}, ["task_id", "claim_token", "native_evidence", "result"])},
    {"name": "prepare_subscription_dispatch", "description": "Freeze native transport for an active exact fallback claim. Supply the managed project_root to store handoffs under its parent-session directory. Astra requires project_root and acknowledges in chat before parent activation. If astra_fallback_transport is parent_subagent_review_v1, the main chat spawns the named Astra child directly and verifies its rule-bound read-only review.", "inputSchema": object_schema({"task_id": STR, "parent_session_id": STR, "claim_token": STR, "task_name": STR, "project_root": STR}, ["task_id", "parent_session_id", "claim_token", "task_name"])},
]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--stdio", action="store_true")
    parser.add_argument("--root", default=str(Path(__file__).resolve().parent))
    parser.add_argument("--read-only", action="store_true")
    args = parser.parse_args()
    engine = Engine(args.root)
    tools = [tool for tool in TOOLS if not args.read_only or tool["name"] in ("get_task", "get_usage")]
    instructions = ("Historical task queries and recovery only. For new work the owning Codex root "
                    "uses built-in spawn_agent. This service has no provider dispatch.")
    for line in sys.stdin.buffer:
        request = None
        try:
            if len(line) > 8 * 1024 * 1024:
                raise WorkerError("request_size", "MCP request exceeded the 8 MiB bound; use explicit source files.")
            request = json.loads(line)
            if "id" not in request:
                continue
            method = request.get("method")
            if method == "initialize":
                offered = request.get("params", {}).get("protocolVersion", "2024-11-05")
                result = {"protocolVersion": offered if offered in ("2024-11-05", "2025-03-26", "2025-06-18", "2025-11-25") else "2024-11-05",
                          "capabilities": {"tools": {"listChanged": False}}, "serverInfo": {"name": "hybrid_api_workers", "version": "1.7.0"},
                          "instructions": "Runtime and canonical context/role specifications: " + str(engine.root) + ". Read " + str(engine.root / "RUNBOOK.md") + " for complete required handoff fields. " + instructions}
            elif method == "ping":
                result = {}
            elif method == "tools/list":
                result = {"tools": tools}
            elif method == "tools/call":
                params = request["params"]
                name = params["name"]
                if name not in {x["name"] for x in tools}:
                    raise WorkerError("tool_unknown", "Unknown hybrid worker tool.")
                try:
                    data = getattr(engine, name)(**params.get("arguments", {}))
                    result = {"content": [{"type": "text", "text": json.dumps(data, ensure_ascii=False)}], "isError": False}
                except WorkerError as error:
                    result = {"content": [{"type": "text", "text": json.dumps({"error": error.code, "message": str(error)})}], "isError": True}
            else:
                raise WorkerError("method_unknown", "Unsupported MCP method.")
            message = {"jsonrpc": "2.0", "id": request["id"], "result": result}
        except Exception as error:
            # Never echo arbitrary exceptions, supplied arguments, secrets, or file bodies.
            message = {"jsonrpc": "2.0", "id": request.get("id") if isinstance(request, dict) else None,
                       "error": {"code": -32602, "message": error.code if isinstance(error, WorkerError) else "invalid_request_or_local_failure"}}
        sys.stdout.buffer.write((json.dumps(message, ensure_ascii=False) + "\n").encode("utf-8"))
        sys.stdout.buffer.flush()


if __name__ == "__main__":
    main()

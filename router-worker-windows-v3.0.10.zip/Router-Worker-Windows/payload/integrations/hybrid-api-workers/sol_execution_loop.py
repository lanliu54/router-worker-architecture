"""Bounded stateless tool-loop candidate; not wired to production dispatch.

All side effects are mediated by injected, independently authorized components.
The durable journal must atomically reserve and mark each request before network
dispatch and each tool before execution. Uncertain attempts are never replayed.
"""
from copy import deepcopy
from decimal import Decimal, ROUND_CEILING
import json
import urllib.error
import api_balance


class ExecutionError(Exception):
    pass


class ProviderRejected(ExecutionError):
    def __init__(self,code,request_id,http_status=None):
        super().__init__('Confirmed pre-generation provider rejection')
        self.code=code;self.request_id=request_id;self.http_status=http_status


TOOL = {'type':'function','name':'run_python','description':'Run Python in the task candidate workspace.',
        'strict':True,'parameters':{'type':'object','properties':{'code':{'type':'string'}},
                                   'required':['code'],'additionalProperties':False}}


def _micro_cost(input_tokens, output_tokens, input_rate, output_rate):
    return int((Decimal(input_tokens)*Decimal(str(input_rate)) +
                Decimal(output_tokens)*Decimal(str(output_rate))).to_integral_value(rounding=ROUND_CEILING))


def execute(*, task_id, payload, adapter, runner, journal, cap_micro_usd,
            input_rate, output_rate, input_limit=128000, max_rounds=3, max_tools=2,
            output_limit=4096, max_tool_output_bytes=16384):
    """Run once. Journal is the ownership/budget source; caller owns acceptance.

    adapter.count takes an entire Responses payload including tools; adapter.run
    returns the terminal response and provider request id. runner.run_python
    returns a JSON-serializable bounded actual execution receipt. journal methods
    are strict atomic operations, not best-effort logs. This function does not
    auto-retry, reset, resume uncertain work, or apply files to user projects.
    """
    if (not task_id or type(cap_micro_usd) is not int or cap_micro_usd <= 0 or
        type(max_rounds) is not int or not 1 <= max_rounds <= 3 or
        type(max_tools) is not int or not 0 <= max_tools <= 2 or
        type(output_limit) is not int or not 1 <= output_limit <= 16384 or
        type(input_limit) is not int or not 1 <= input_limit <= 256000 or
        Decimal(str(input_rate)) <= 0 or Decimal(str(output_rate)) <= 0):
        raise ExecutionError('invalid bounded execution contract')
    base = deepcopy(payload)
    if base.get('model') != 'gpt-6.1-sol' or base.get('reasoning',{}).get('effort') != 'high':
        raise ExecutionError('wrong execution model or effort')
    if type(base.get('store')) is not bool or base.get('background') is not False:
        raise ExecutionError('explicit retention and foreground response required')
    if not isinstance(base.get('input'),list) or 'tools' in base:
        raise ExecutionError('invalid source payload')
    base['tools'] = [deepcopy(TOOL)]
    base['parallel_tool_calls'] = False
    base['include'] = ['reasoning.encrypted_content']
    base['max_output_tokens'] = output_limit
    spent = 0
    used_tools = 0
    journal.begin(task_id, cap_micro_usd)
    for round_no in range(1,max_rounds+1):
        if journal.before_count(task_id, round_no) is False:
            raise ExecutionError('This parent has a confirmed provider credit rejection')
        try:
            count = adapter.count(base)
        except ProviderRejected as error:
            if error.code=='credit_balance_exhausted' and error.http_status==429:
                journal.reject_count_for_credit(task_id,round_no,error.request_id)
            else:
                journal.stop(task_id,'input_count_failed')
            raise
        except Exception:
            journal.stop(task_id,'input_count_failed')
            raise
        if type(count) is not int or count < 0 or count > input_limit:
            journal.stop(task_id,'input_limit')
            raise ExecutionError('complete input exceeds limit')
        reserved = _micro_cost(count, output_limit, input_rate, output_rate)
        if spent + reserved > cap_micro_usd:
            journal.stop(task_id,'budget_exhausted')
            raise ExecutionError('per-task API cap would be exceeded')
        if journal.reserve_request(task_id,round_no,reserved,spent) is False:
            raise ExecutionError('This parent has a confirmed provider credit rejection')
        try:
            if hasattr(adapter,'run_round'):
                response, request_id = adapter.run_round(
                    deepcopy(base),task_id,round_no,lambda fields, n=round_no: journal.progress(task_id,n,fields))
            else:
                response, request_id = adapter.run(deepcopy(base))
        except ProviderRejected as error:
            journal.reject_request(task_id,round_no,error.code,error.request_id,round_no==1 and used_tools==0 and spent==0,error.http_status)
            raise
        except Exception as error:
            headers=error.headers if isinstance(error,urllib.error.HTTPError) else None
            journal.unknown_request(task_id,round_no,type(error).__name__,headers.get('x-request-id') if headers else None,
                                    error.code if isinstance(error,urllib.error.HTTPError) else None)
            raise
        if not isinstance(response,dict) or not response.get('id'):
            journal.unknown_request(task_id,round_no,'malformed_response',request_id)
            raise ExecutionError('provider response is malformed')
        if api_balance.is_terminal_credit_failure(response):
            reported=response.get('usage')
            valid=(isinstance(reported,dict) and all(type(reported.get(k)) is int and reported[k]>=0
                                                       for k in ('input_tokens','output_tokens')))
            usage={k:reported[k] for k in ('input_tokens','output_tokens')} if valid else None
            cost=_micro_cost(usage['input_tokens'],usage['output_tokens'],input_rate,output_rate) if valid else None
            journal.terminal_credit_failure(task_id,round_no,response,request_id,usage,cost)
            raise ExecutionError('Terminal credit rejection; the original task cannot be replayed')
        usage=response.get('usage',{})
        if not isinstance(usage,dict) or any(type(usage.get(k)) is not int or usage[k] < 0
                                            for k in ('input_tokens','output_tokens')):
            journal.unknown_request(task_id,round_no,'usage_missing',request_id)
            raise ExecutionError('provider usage unavailable; preserve reservation')
        usage={key:usage[key] for key in ('input_tokens','output_tokens')}
        cost=_micro_cost(usage['input_tokens'],usage['output_tokens'],input_rate,output_rate)
        if cost > reserved:
            journal.unknown_request(task_id,round_no,'usage_exceeds_reservation',request_id,
                                    response_id=response['id'],observed_usage=usage,observed_cost=cost)
            raise ExecutionError('reported usage exceeds reserved estimate')
        spent += cost
        journal.complete_request(task_id,round_no,response.get('id'),request_id,usage,cost)
        if (response.get('status') != 'completed' or response.get('model') != 'gpt-6.1-sol' or
            (response.get('reasoning') or {}).get('effort','high') != 'high'):
            journal.stop(task_id,'invalid_terminal_response')
            raise ExecutionError('unexpected provider status, model or effort')
        outputs=response.get('output',[])
        if not isinstance(outputs,list) or any(not isinstance(item,dict) for item in outputs):
            journal.stop(task_id,'invalid_output')
            raise ExecutionError('provider output is malformed')
        if any(part.get('type')=='refusal' for item in outputs if item.get('type')=='message'
               for part in item.get('content',[]) if isinstance(part,dict)):
            journal.stop(task_id,'provider_refusal')
            raise ExecutionError('provider refused the request')
        calls=[item for item in outputs if item.get('type')=='function_call']
        if not calls:
            texts=[content.get('text','') for item in outputs if item.get('type')=='message'
                   for content in item.get('content',[]) if content.get('type')=='output_text']
            if not texts:
                journal.stop(task_id,'missing_final_output')
                raise ExecutionError('missing final output')
            journal.finish(task_id,spent)
            return {'text':''.join(texts),'cost_micro_usd':spent,'tool_calls':used_tools,'rounds':round_no}
        if len(calls)!=1 or used_tools>=max_tools or round_no==max_rounds:
            journal.stop(task_id,'tool_limit')
            raise ExecutionError('tool count or round limit exceeded')
        call=calls[0]
        try:
            args=json.loads(call['arguments'])
            if (call.get('name')!='run_python' or not isinstance(call.get('call_id'),str) or
                not isinstance(args,dict) or set(args)!={'code'} or not isinstance(args['code'],str) or
                not 0<len(args['code'].encode('utf-8'))<=32768):
                raise ValueError('unsupported tool input')
        except (KeyError,ValueError,TypeError):
            journal.stop(task_id,'invalid_tool_call')
            raise ExecutionError('invalid tool call') from None
        call_id=call['call_id']
        journal.begin_tool(task_id,round_no,call_id,args)
        try:
            result=runner.run_python(args['code'])
            encoded=json.dumps(result,ensure_ascii=False,allow_nan=False)
            if len(encoded.encode('utf-8'))>max_tool_output_bytes:
                raise ExecutionError('tool output exceeds bound')
        except Exception:
            journal.unknown_tool(task_id,round_no,call_id)
            raise
        journal.complete_tool(task_id,round_no,call_id,result)
        used_tools += 1
        # Replay the complete original input and returned items in either retention mode.
        base['input'].extend(deepcopy(outputs))
        base['input'].append({'type':'function_call_output','call_id':call_id,'output':encoded})
    raise ExecutionError('unreachable round termination')

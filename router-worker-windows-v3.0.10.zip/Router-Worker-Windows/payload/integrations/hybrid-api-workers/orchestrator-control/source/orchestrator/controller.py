"""Sole trusted state writer. Workers submit results, never acceptance decisions.

This local control plane is not an OS security boundary against its own user.
Keep its runtime directory out of untrusted worker mounts. Remote HTTP is absent.
"""
from __future__ import annotations
import json
from pathlib import Path
import secrets
import shutil
import time
import uuid
from .common import ControlError, atomic_json, canonical, digest, file_hash, require, safe_id, validate_schema, within, artifact_manifest_hash, copy_verified_exclusive
from .policy import ROLE_TARGETS, API_ROLE, api_cap, MANDATORY_ASSIGNMENTS, SIMPLIFIED_ASSIGNMENTS, permission, reviewer_for, same_model_family
from .store import Store

class Controller:
    def __init__(self, runtime, *, config=None):
        self.root=Path(runtime).resolve()
        self.contract_dir=Path(__file__).parent/'contracts'
        self.store=Store(self.root,self.contract_dir)
        settings_path=self.root/'config.json'
        saved=json.loads(settings_path.read_text(encoding='utf-8')) if settings_path.is_file() else {}
        self.config={'mode':'observe','max_workers_total':2,'max_writers_per_project':1,
                     'max_desktop_operators':1,'max_solver_jobs':1,'max_parallel_qa':1,
                     'events_enabled':False,'dispatch_enabled':False, **saved, **(config or {})}
        require(self.config.get('native_astra_qa_boundary') in (None, 'review_rules_v1'),
                'invalid_native_astra_qa_boundary')
        self.transitions=json.loads((self.contract_dir/'state-machine.json').read_text(encoding='utf-8'))['transitions']

    def schema(self,name,value):
        validate_schema(value,json.loads((self.contract_dir/f'{name}.schema.json').read_text(encoding='utf-8')))
        require(value.get('provenance')=='runtime','example_is_not_runtime_evidence')

    @staticmethod
    def enforce_assignment(profile,contract):
        if profile in ('terra_main_v2','mandatory_delegation_v3','simplified_workflow_v5'):
            require(contract['assigned_role'] not in ('writer_terra','qa_terra','desktop_terra'),'main_owned_work')
        if profile in ('mandatory_delegation_v3','simplified_workflow_v5'):
            kind=contract.get('work_kind')
            assignments=SIMPLIFIED_ASSIGNMENTS if profile=='simplified_workflow_v5' else MANDATORY_ASSIGNMENTS
            require(kind in assignments,'mandatory_classification_required')
            require(contract['assigned_role']==assignments[kind],'mandatory_assignment_mismatch')
        if profile not in ('mandatory_delegation_v3','simplified_workflow_v5'):
            require(contract['assigned_role']!='executor_sol','role_not_enabled_for_profile')

    def _audit(self,db,t,old,new,reason,evidence,attempt=None):
        db.execute('INSERT INTO audit(task_id,actor,prior_state,next_state,state_version,reason,evidence_ref,contract_version,attempt_id,occurred_at) VALUES(?,?,?,?,?,?,?,?,?,?)',
                   (t['task_id'],'controller',old,new,t['state_version']+1,reason,evidence,t['contract_version'],attempt,time.time()))

    def _transition(self,db,t,new,reason,evidence,*,expected=None,attempt=None):
        require(new in self.transitions.get(t['state'],[]),'illegal_transition',f"{t['state']} -> {new}")
        require(expected is None or expected==t['state_version'],'stale_state_version')
        require(reason and evidence,'transition_evidence_required')
        old=t['state']
        cur=db.execute('UPDATE tasks SET state=?,state_version=state_version+1,updated_at=? WHERE task_id=? AND state_version=?',
                       (new,str(time.time()),t['task_id'],t['state_version']))
        require(cur.rowcount==1,'state_conflict')
        self._audit(db,t,old,new,reason,evidence,attempt)
        t['state']=new
        t['state_version']+=1

    def transition(self,task_id,new,*,expected,reason,evidence,actor='controller'):
        require(actor=='controller','sole_writer_only')
        # Protected phases are reached only by their evidence-checked methods.
        require(new not in ('RUNNING','SUBMITTED','ACCEPTED','PUBLISHED','AWAITING_ACCEPTANCE'),'use_guarded_operation')
        with self.store.transaction() as db:
            t=self.store.task(task_id,db)
            self._transition(db,t,new,reason,evidence,expected=expected)
        return self.inspect(task_id)

    def create(self,contract,*,actor='parent_main'):
        require(actor in ('parent_main','parent_sol'),'plan_authority_required')
        self.schema('task',contract)
        task_id=safe_id(contract['task_id'])
        safe_id(contract['project_id'])
        require(contract['assigned_role'] in ROLE_TARGETS,'unknown_role')
        require(contract['contract_version']==1,'initial_contract_version')
        require(len({a['id'] for a in contract['acceptance']})==len(contract['acceptance']),'duplicate_criterion')
        with self.store.read() as db:
            old=db.execute('SELECT contract_hash FROM tasks WHERE task_id=?',(task_id,)).fetchone()
        if old:
            require(old['contract_hash']==digest(contract),'task_contract_conflict')
            return self.inspect(task_id)
        profile=self.config.get('architecture_profile','legacy_v1')
        api_policy_version=self.config.get('role_policy_version',2)
        require(type(api_policy_version) is int and api_policy_version in (2,3),'api_policy_invalid')
        self.enforce_assignment(profile,contract)
        protected=[self.root,Path(__file__).parent]
        frozen=[]
        for i,item in enumerate(contract['inputs']):
            p=permission(contract,item['path'],'read',protected)
            require(p.is_file() and file_hash(p)==item['sha256'],'input_hash_mismatch')
            dest=self.root/'tasks'/task_id/'v1'/'inputs'/f'{i}-{p.name}'
            dest.parent.mkdir(parents=True,exist_ok=True)
            if dest.exists():
                require(file_hash(dest)==item['sha256'],'orphan_snapshot_conflict')
            else:
                shutil.copyfile(p,dest)
            require(file_hash(dest)==item['sha256'] and file_hash(p)==item['sha256'],'input_changed_while_freezing')
            frozen.append({'path':str(dest),'sha256':item['sha256'],'original':str(p)})
        stamp=str(time.time())
        ch=digest(contract)
        meta={'architecture_profile':profile,'api_policy_version':api_policy_version,'input_snapshots':frozen,'snapshot':None,'author':None,'accepted_hash':None,'hold':None,
              'resource_limits':{'wall_seconds':None,'disk_bytes':None,'attempts':8},'rework_rounds':0}
        if profile in ('mandatory_delegation_v3','simplified_workflow_v5'):
            meta['native_sol_qa_boundary']='review_rules_v1'
            if profile=='mandatory_delegation_v3':
                meta['astra_focus_required']=True
            if profile=='mandatory_delegation_v3' and self.config.get('native_astra_qa_boundary') == 'review_rules_v1':
                meta['native_astra_qa_boundary']='review_rules_v1'
        with self.store.transaction() as db:
            require(not db.execute('SELECT 1 FROM tasks WHERE task_id=?',(task_id,)).fetchone(),'task_exists')
            db.execute('INSERT INTO tasks VALUES(?,?,?,?,?,?,?,?,?,?,?)',
                       (task_id,contract['project_id'],'NEW',1,1,ch,canonical(contract),contract['risk'],contract['complexity'],stamp,stamp))
            db.execute('INSERT INTO task_versions VALUES(?,?,?,?)',(task_id,1,canonical(contract),ch))
            db.execute('INSERT INTO task_meta VALUES(?,?)',(task_id,canonical(meta)))
            db.execute('INSERT INTO resource_usage(task_id) VALUES(?)',(task_id,))
            t=self.store.task(task_id,db)
            self._transition(db,t,'TRIAGED','contract_validated',ch)
            self._transition(db,t,'READY','inputs_frozen',digest(frozen))
        atomic_json(self.root/'tasks'/task_id/'v1'/'task.json',contract)
        return self.inspect(task_id)

    def inspect(self,task_id):
        t=self.store.task(task_id)
        with self.store.read() as db:
            t['attempts']=[dict(r) for r in db.execute('SELECT * FROM attempts WHERE task_id=? ORDER BY started_at',(task_id,))]
        return t

    def _resource_available(self,db,t):
        usage=db.execute('SELECT * FROM resource_usage WHERE task_id=?',(t['task_id'],)).fetchone()
        for key in ('wall_seconds','disk_bytes','attempts'):
            limit=t['meta']['resource_limits'].get(key)
            if limit is not None and usage[key]>=limit:
                return False
        return t['meta'].get('hold') is None

    def set_resource_limits(self,task_id,limits,*,actor='parent_main'):
        require(actor in ('parent_main','parent_sol'),'plan_authority_required')
        require(set(limits)<={'wall_seconds','disk_bytes','attempts'} and all(v is None or type(v) in (int,float) and v>=0 for v in limits.values()),'invalid_resource_limit')
        with self.store.transaction() as db:
            t=self.store.task(task_id,db)
            t['meta']['resource_limits'].update(limits)
            self.store.meta(db,task_id,t['meta'])

    def prepare_attempt(self,task_id,channel_name,role_prompt,*,session_id=None,model_reported=None,
                        identity_evidence='not_observable',resources=(),api_reservation=0,external_id=None,
                        native_sol_authorized=False):
        # This does not launch an agent. The adapter fills transport-owned identity.
        require(channel_name in ('api_worker','subscription_codex','native_desktop','validator_process','solver_job'),'unknown_adapter')
        aid=str(uuid.uuid4())
        with self.store.transaction() as db:
            t=self.store.task(task_id,db)
            require(t['state']=='READY','task_not_ready')
            require(self._resource_available(db,t),'total_task_budget_exhausted')
            role=t['contract']['assigned_role']
            model,effort,primary=ROLE_TARGETS[role]
            if role=='executor_sol':
                require(channel_name=='api_worker' or channel_name=='subscription_codex' and native_sol_authorized,
                        'native_execution_parity_unverified')
            if role=='desktop_terra':
                require(channel_name=='native_desktop','desktop_native_only')
            if channel_name=='api_worker':
                require(role in API_ROLE,'role_has_no_api_route')
                budget=t['contract']['budget']['api_usd']
                require(budget is not None and api_reservation>0 and api_reservation<=int(budget*1000000)
                        and api_reservation<=api_cap(t,API_ROLE[role]),'api_budget_not_authorized')
            else:
                require(api_reservation==0,'subscription_is_not_api_cost')
            require(not db.execute("SELECT 1 FROM attempts WHERE task_id=? AND status IN ('starting','running','waiting_external','unknown')",(task_id,)).fetchone(),'active_attempt_exists')
            active=db.execute("SELECT a.*,t.project_id FROM attempts a JOIN tasks t USING(task_id) WHERE a.status IN ('starting','running','waiting_external','unknown')").fetchall()
            if t['meta'].get('architecture_profile') != 'simplified_workflow_v5':
                require(len(active)<self.config['max_workers_total'],'worker_capacity')
            keys=list(resources)
            if t['contract']['permissions']['write_paths']:
                keys.append('project-writer:'+t['project_id'])
            if role=='desktop_terra':
                keys.append('desktop-global')
            if channel_name=='solver_job':
                keys.append('solver-global')
            fences={}
            for key in sorted(set(keys)):
                key=self.resource_key(key)
                old=db.execute('SELECT * FROM resource_leases WHERE resource_key=?',(key,)).fetchone()
                # An expired lease remains occupied until its owner is reconciled.
                require(old is None or not old['owner_attempt_id'],'resource_busy')
                token=old['fencing_token']+1 if old else 1
                db.execute('INSERT INTO resource_leases VALUES(?,?,?,?,?) ON CONFLICT(resource_key) DO UPDATE SET owner_attempt_id=excluded.owner_attempt_id,fencing_token=excluded.fencing_token,lease_expires_at_epoch=excluded.lease_expires_at_epoch,last_confirmed_at_epoch=excluded.last_confirmed_at_epoch',
                           (key,aid,token,int(time.time())+90,int(time.time())))
                fences[key]=token
            data={'session_id':session_id,'fences':fences,'identity':identity_evidence,'external_id':external_id}
            db.execute('INSERT INTO attempts(attempt_id,task_id,contract_version,role,status,model_requested,model_reported,effort_requested,identity_evidence_level,channel,adapter_version,role_hash,permission_hash,input_manifest_hash,provider_request_id,started_at,usage_json) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
                       (aid,task_id,t['contract_version'],role,'starting',model,model_reported,effort,identity_evidence,channel_name,'1.0',digest(role_prompt.encode()),digest(t['contract']['permissions']),digest(t['contract']['inputs']),external_id,str(time.time()),canonical(data)))
            db.execute('INSERT INTO budget_reservations VALUES(?,?,?,?,?,?)',(aid,task_id,api_reservation,None,'reserved',canonical({'subscription_quota':'unknown'})))
            db.execute('UPDATE resource_usage SET attempts=attempts+1 WHERE task_id=?',(task_id,))
            self._transition(db,t,'RUNNING','attempt_prepared',aid,attempt=aid)
            return {'attempt_id':aid,'task_id':task_id,'contract_version':t['contract_version'],'model_requested':model,
                    'effort_requested':effort,'channel':channel_name,'fences':fences,'session_id':session_id,
                    'identity_evidence_level':identity_evidence,'status':'starting'}

    @staticmethod
    def resource_key(key):
        return 'path:'+str(Path(key[5:]).resolve()).casefold() if key.startswith('path:') else key

    def bind_attempt(self,attempt_id,*,session_id=None,external_id=None,process_id=None,process_started_at=None,working_directory=None,model_reported=None,effort_reported=None,evidence='not_observable'):
        with self.store.transaction() as db:
            row=db.execute('SELECT * FROM attempts WHERE attempt_id=?',(attempt_id,)).fetchone()
            require(row is not None and row['status']=='starting','attempt_not_starting')
            require(model_reported in (None,row['model_requested']) and effort_reported in (None,row['effort_requested']),'actual_identity_mismatch')
            data=json.loads(row['usage_json'])
            data['session_id']=session_id
            if session_id:
                key='session_binding:'+session_id
                prior=db.execute('SELECT value FROM controller_settings WHERE key=?',(key,)).fetchone()
                require(prior is None or json.loads(prior[0]).get('attempt_id')==attempt_id,'session_already_bound')
                binding={'task_id':row['task_id'],'attempt_id':attempt_id,'contract_version':row['contract_version'],'role':row['role']}
                db.execute('INSERT INTO controller_settings VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',(key,canonical(binding)))
            db.execute('UPDATE attempts SET status=?,provider_request_id=?,process_id=?,process_started_at=?,working_directory=?,model_reported=?,effort_reported=?,identity_evidence_level=?,usage_json=? WHERE attempt_id=?',
                       ('running',external_id,process_id,process_started_at,working_directory,model_reported,effort_reported,evidence,canonical(data),attempt_id))

    @staticmethod
    def _unbind(db,row):
        session=json.loads(row['usage_json']).get('session_id')
        if session:
            key='session_binding:'+session
            bound=db.execute('SELECT value FROM controller_settings WHERE key=?',(key,)).fetchone()
            if bound and json.loads(bound[0]).get('attempt_id')==row['attempt_id']:
                db.execute('DELETE FROM controller_settings WHERE key=?',(key,))

    def _attempt(self,db,task_id,aid,version,fences):
        t=self.store.task(task_id,db)
        require(version==t['contract_version'],'stale_contract')
        row=db.execute('SELECT * FROM attempts WHERE attempt_id=? AND task_id=?',(aid,task_id)).fetchone()
        require(row and row['contract_version']==version and row['status'] in ('running','starting','waiting_external','unknown'),'attempt_not_active')
        expected=json.loads(row['usage_json']).get('fences',{})
        require(fences==expected,'fence_mismatch')
        for key,token in expected.items():
            lease=db.execute('SELECT * FROM resource_leases WHERE resource_key=?',(key,)).fetchone()
            require(lease and lease['owner_attempt_id']==aid and lease['fencing_token']==token,'stale_fence')
        return t,row

    def submit_result(self,result,*,session_id,fences,in_place_workspace=None):
        self.schema('result',result)
        with self.store.transaction() as db:
            t,row=self._attempt(db,result['task_id'],result['attempt_id'],result['contract_version'],fences)
            aid=row['attempt_id']
            require(result['role']==row['role'],'result_role_mismatch')
            known_session=json.loads(row['usage_json']).get('session_id')
            require(session_id and (known_session is None or known_session==session_id),'session_mismatch')
            if result['status']=='blocked':
                db.execute('UPDATE attempts SET status=? WHERE attempt_id=?',('unknown',aid))
                self._transition(db,t,'BLOCKED','worker_reported_blocker',aid,attempt=aid)
                return {'state':'BLOCKED'}
            require(result['artifacts'],'artifact_missing')
            manifest=[]
            for index,item in enumerate(result['artifacts']):
                p=permission(t['contract'],item['path'],'write',[self.root,Path(__file__).parent])
                require(p.is_file() and file_hash(p)==item['sha256'],'artifact_hash_mismatch')
                if in_place_workspace is not None:
                    require(row['role']=='executor_sol' and row['channel']=='subscription_codex'
                            and p.is_relative_to(in_place_workspace), 'workspace_artifact_outside_scope')
                    dest = p
                else:
                    dest=self.root/'tasks'/t['task_id']/f"v{t['contract_version']}"/'artifacts'/aid/f'{index}-{p.name}'
                    dest.parent.mkdir(parents=True,exist_ok=True)
                    if dest.exists():
                        require(file_hash(dest)==item['sha256'],'orphan_artifact_conflict')
                    else:
                        copy_verified_exclusive(p,dest,item['sha256'])
                require(file_hash(dest)==item['sha256'] and file_hash(p)==item['sha256'],'artifact_changed_during_snapshot')
                manifest.append({'path':str(dest),'source':str(p),'sha256':item['sha256'],'size_bytes':dest.stat().st_size})
                db.execute('INSERT INTO artifacts VALUES(?,?,?,?,?,?,?,?)',
                           (str(uuid.uuid4()),t['task_id'],aid,str(dest),item['sha256'],dest.stat().st_size,'project',str(time.time())))
            sh=artifact_manifest_hash(manifest)
            t['meta'].update(snapshot={'hash':sh,'manifest':manifest},author={'attempt_id':aid,'session_id':session_id,'role':row['role']},accepted_hash=None)
            t['meta']['result_unresolved']=result['unresolved']
            self.store.meta(db,t['task_id'],t['meta'])
            db.execute('UPDATE attempts SET status=?,finished_at=? WHERE attempt_id=?',('completed',str(time.time()),aid))
            self._unbind(db,row)
            db.execute('UPDATE resource_leases SET owner_attempt_id=? WHERE owner_attempt_id=?',('',aid))
            self._transition(db,t,'SUBMITTED','worker_result_frozen',sh,attempt=aid)
            self._receipt(db,t,'result',sh,result)
            self._transition(db,t,'VALIDATING','begin_validation',sh,attempt=aid)
            return {'state':t['state'],'artifact_hash':sh,'attempt_id':aid}

    def _receipt(self,db,t,kind,sh,value):
        rid=str(uuid.uuid4())
        db.execute('INSERT INTO receipts VALUES(?,?,?,?,?,?,?)',(rid,t['task_id'],t['contract_version'],kind,sh,canonical(value),time.time()))
        path=self.root/'tasks'/t['task_id']/f"v{t['contract_version']}"/'receipts'/f'{kind}-{rid}.json'
        atomic_json(path,value)
        return rid

    def record_validation(self,report,*,trusted_runner):
        self.schema('validation',report)
        require(trusted_runner==report['runner_id'],'untrusted_validator')
        with self.store.transaction() as db:
            t=self.store.task(report['task_id'],db)
            require(t['state'] in ('VALIDATING','REVIEWING','AWAITING_ACCEPTANCE'),'not_validating')
            require(t['meta']['snapshot'] and t['meta']['snapshot']['hash']==report['artifact_hash'],'stale_validation')
            require(t['meta']['author']['attempt_id']==report['attempt_id'],'validation_attempt_mismatch')
            criteria={a['id'] for a in t['contract']['acceptance']}
            require(len({a['criterion_id'] for a in report['results']})==len(report['results']),'duplicate_validation')
            for item in report['results']:
                require(item['criterion_id'] in criteria,'unknown_criterion')
                self._check_evidence(item['evidence_refs'],required=item['status']=='pass')
                sealed={**item,'evidence_hashes':{ref:file_hash(ref) for ref in item['evidence_refs']}}
                db.execute('INSERT INTO validations VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',
                           (str(uuid.uuid4()),t['task_id'],report['artifact_hash'],item['criterion_id'],item['status'],trusted_runner,report['runner_version'],canonical(item['evidence_refs']),canonical(sealed),str(time.time()),t['contract_version'],report['attempt_id']))
            self._receipt(db,t,'validation',report['artifact_hash'],report)

    @staticmethod
    def _check_evidence(refs,*,required=True):
        require(bool(refs) or not required,'evidence_missing')
        # Local evidence must exist. Network citations are leads, not executable receipts.
        for ref in refs:
            require(Path(ref).is_absolute() and Path(ref).is_file(),'evidence_unreadable')

    def qa_handoff(self,task_id):
        t=self.store.task(task_id)
        require(t['meta']['snapshot'],'no_snapshot')
        profile=t['meta'].get('architecture_profile','legacy_v1')
        author_role=t['meta']['author']['role'] if profile in ('mandatory_delegation_v3','simplified_workflow_v5') else t['contract']['assigned_role']
        hard_expert=any(x['hard'] and x['kind']=='expert_review' for x in t['contract']['acceptance'])
        role=reviewer_for(author_role,t['risk'],profile,hard_expert=hard_expert)
        # Deliberately exclude result.summary, author self-evaluation and other QA votes.
        boundary_key = {'qa_sol': 'native_sol_qa_boundary', 'qa_astra': 'native_astra_qa_boundary'}.get(role)
        rule_bound = t['meta'].get(boundary_key) == 'review_rules_v1'
        return {'task_id':task_id,'contract_version':t['contract_version'],'contract':t['contract'],
                'artifact_hash':t['meta']['snapshot']['hash'],'artifacts':t['meta']['snapshot']['manifest'],
                'originals':t['meta']['input_snapshots'],'reviewer_role':role,
                'model':ROLE_TARGETS[role][0] if role else None,'effort':ROLE_TARGETS[role][1] if role else None,
                'required_execution':'independent_rule_bound_review' if rule_bound else 'independent_root_read_only','author_session_id':t['meta']['author']['session_id']}

    def record_review(self,report,*,session_id,execution_receipt,verified_astra_binding=None,expected_contract_version=None):
        self.schema('review',report)
        api_independent=(execution_receipt.get('channel')=='api_worker' and execution_receipt.get('independent_context') is True
            and execution_receipt.get('actual_model') in ('gpt-6.1-sol','gpt-6-astra') and execution_receipt.get('requested_effort')=='high'
            and execution_receipt.get('tools_disabled') is True and execution_receipt.get('response_id'))
        rule_proof=execution_receipt.get('qa_rule_evidence') or {}
        rule_bound=(execution_receipt.get('channel')=='subscription_codex'
            and execution_receipt.get('actual_model') in ('gpt-6.1-sol', 'gpt-6-astra')
            and execution_receipt.get('read_only_verified') is False
            and rule_proof.get('boundary')=='review_rules_v1' and rule_proof.get('os_isolation_claimed') is False
            and rule_proof.get('package_hash')==execution_receipt.get('package_hash')
            and session_id=='native:'+str(rule_proof.get('native_thread_id',''))
            and bool(rule_proof.get('trace_sha256')) and bool(rule_proof.get('observed_tool_calls'))
            and execution_receipt.get('provider_task_id')==report['reviewer_attempt_id'])
        native_independent=(execution_receipt.get('channel')=='subscription_codex' and execution_receipt.get('independent_context') is True
            and execution_receipt.get('exact_package_verified') is True and (execution_receipt.get('read_only_verified') is True or rule_bound)
            and execution_receipt.get('actual_model') in ('gpt-6.1-sol','gpt-6-astra') and execution_receipt.get('requested_effort')=='high')
        require((execution_receipt.get('independent_root') or api_independent or native_independent)
            and (execution_receipt.get('read_only') or rule_bound) and execution_receipt.get('evidence_ref'),'qa_execution_isolation_unverified')
        self._check_evidence([execution_receipt['evidence_ref']])
        with self.store.transaction() as db:
            t=self.store.task(report['task_id'],db)
            author=t['meta']['author']
            if execution_receipt.get('actual_model')=='gpt-6-astra':
                require(t['meta'].get('architecture_profile')=='mandatory_delegation_v3' and report['reviewer_role']=='qa_astra', 'review_identity_mismatch')
            require(author and report['author_attempt_id']==author['attempt_id'],'review_author_mismatch')
            profile=t['meta'].get('architecture_profile','legacy_v1')
            if profile == 'simplified_workflow_v5' or expected_contract_version is not None:
                require(type(expected_contract_version) is int and expected_contract_version == t['contract_version'],
                        'stale_review_contract')
            reviewer_session=session_id.removeprefix('native:') if session_id and profile=='simplified_workflow_v5' else session_id
            author_session=author['session_id'].removeprefix('native:') if author['session_id'] and profile=='simplified_workflow_v5' else author['session_id']
            require(session_id and reviewer_session!=author_session and report['reviewer_attempt_id']!=author['attempt_id'],'self_review')
            if t['meta'].get('architecture_profile') in ('terra_main_v2','mandatory_delegation_v3'):
                reviewer_target=ROLE_TARGETS.get(report['reviewer_role'])
                require(reviewer_target and not same_model_family(ROLE_TARGETS[author['role']][0],reviewer_target[0]),'same_family_review_forbidden')
            review_author=author['role'] if profile in ('mandatory_delegation_v3','simplified_workflow_v5') else t['contract']['assigned_role']
            hard_expert=any(x['hard'] and x['kind']=='expert_review' for x in t['contract']['acceptance'])
            required_role=reviewer_for(review_author,t['risk'],profile,hard_expert=hard_expert)
            require(report['reviewer_role']==required_role,'review_role_mismatch')
            if rule_bound:
                boundary_key = {'qa_sol': 'native_sol_qa_boundary', 'qa_astra': 'native_astra_qa_boundary'}.get(required_role)
                require(t['meta'].get(boundary_key) == 'review_rules_v1',
                        'qa_rule_boundary_not_authorized')
                if required_role == 'qa_astra':
                    native = execution_receipt.get('native_evidence') or {}
                    require(t['meta'].get('astra_focus_required') is True
                            and native.get('permission_boundary') == 'inherits_parent'
                            and native.get('os_isolation_claimed') is False,
                            'qa_rule_boundary_not_authorized')
            if profile in ('mandatory_delegation_v3','simplified_workflow_v5'):
                target=ROLE_TARGETS[required_role][0]
                require(execution_receipt.get('actual_model')==target and execution_receipt.get('requested_effort')=='high', 'review_identity_mismatch')
                require(execution_receipt.get('independent_context') is True and
                        ((execution_receipt.get('channel')=='api_worker' and execution_receipt.get('tools_disabled') is True and execution_receipt.get('response_id')) or
                         (execution_receipt.get('channel')=='subscription_codex' and execution_receipt.get('exact_package_verified') is True and (execution_receipt.get('read_only_verified') is True or rule_bound))),
                        'review_transport_unverified')
            require(report['artifact_hash']==t['meta']['snapshot']['hash'],'stale_review')
            require(self._input_snapshots_valid(t),'input_snapshot_drift')
            require(self._review_materials_bound(t,execution_receipt),'qa_material_binding_invalid')
            focus=execution_receipt.get('astra_focus')
            criteria={x['id'] for x in t['contract']['acceptance']}
            if required_role=='qa_astra' and (focus is not None or t['meta'].get('astra_focus_required')):
                criteria=set(self.astra_focus_criteria(t,focus,db=db))
                require(verified_astra_binding==self._astra_collection_binding(t,report,execution_receipt),
                        'astra_collection_proof_required')
                execution_receipt={**execution_receipt,'astra_collection_binding':verified_astra_binding}
            else:
                require(focus is None and verified_astra_binding is None
                        and 'astra_collection_binding' not in execution_receipt,'astra_focus_reviewer_mismatch')
            require(set(report['checked_criteria'])==criteria,'review_coverage_missing')
            for item in report['findings']:
                require(item['criterion_id'] in criteria,'unknown_criterion')
                self._check_evidence(item['evidence_refs'])
            require(t['state'] in ('VALIDATING','REVIEWING'),'not_reviewing')
            if t['state']=='VALIDATING':
                self._transition(db,t,'REVIEWING','independent_review_received',execution_receipt['evidence_ref'])
            refs={execution_receipt['evidence_ref'],*(ref for f in report['findings'] for ref in f['evidence_refs'])}
            enriched={**report,'reviewer_session_id':session_id,'execution_receipt':execution_receipt,
                      'evidence_hashes':{ref:file_hash(ref) for ref in refs}}
            db.execute('INSERT INTO reviews VALUES(?,?,?,?,?,?,?,?,?)',
                       (str(uuid.uuid4()),t['task_id'],report['artifact_hash'],author['attempt_id'],report['reviewer_attempt_id'],report['verdict'],canonical(enriched),str(time.time()),t['contract_version']))
            self._receipt(db,t,'review',report['artifact_hash'],enriched)

    def _snapshot_valid(self,t):
        s=t['meta'].get('snapshot')
        return bool(s) and artifact_manifest_hash(s['manifest'])==s['hash'] and all(
            Path(x['path']).is_file() and Path(x['source']).is_file() and
            file_hash(x['path'])==x['sha256'] and file_hash(x['source'])==x['sha256'] for x in s['manifest'])

    def _input_snapshots_valid(self,t):
        originals=t['contract']['inputs']
        snapshots=t['meta'].get('input_snapshots',[])
        try:
            return len(snapshots)==len(originals) and all(
                Path(snapshot['original']).resolve()==Path(original['path']).resolve()
                and snapshot['sha256']==original['sha256']
                and Path(snapshot['path']).is_file() and not Path(snapshot['path']).is_symlink()
                and file_hash(snapshot['path'])==original['sha256']
                for original,snapshot in zip(originals,snapshots))
        except (OSError,KeyError,TypeError):
            return False

    @staticmethod
    def qa_material_hashes(t):
        inputs=[('original',item) for item in t['meta']['input_snapshots']]
        artifacts=[('artifact',item) for item in t['meta']['snapshot']['manifest']]
        return {f'{kind}-{index}':item['sha256'] for index,(kind,item) in enumerate(inputs+artifacts)}

    @staticmethod
    def _validated_criterion(db,t,criterion_id):
        row=db.execute('SELECT receipt_json FROM validations WHERE task_id=? AND artifact_hash=? AND criterion_id=? AND contract_version=? AND author_attempt_id=? ORDER BY rowid DESC LIMIT 1',
                       (t['task_id'],t['meta']['snapshot']['hash'],criterion_id,t['contract_version'],t['meta']['author']['attempt_id'])).fetchone()
        if not row:
            return False
        receipt=json.loads(row[0])
        return receipt['status']=='pass' and all(Path(ref).is_file() and file_hash(ref)==saved
                for ref,saved in receipt.get('evidence_hashes',{}).items())

    def astra_focus_criteria(self,t,focus,*,db=None):
        require(isinstance(focus,dict) and set(focus)=={'trigger','basis','criterion_ids','material_ids'}
                and focus.get('trigger')=='sol_authored_independence'
                and isinstance(focus.get('basis'),str) and bool(focus['basis'].strip()),'astra_focus_required')
        require(t['meta']['author']['role']=='executor_sol','astra_focus_reviewer_mismatch')
        criteria={x['id']:x for x in t['contract']['acceptance']}
        selected=focus['criterion_ids']
        materials=focus['material_ids']
        for values in (selected,materials):
            require(isinstance(values,list) and values and all(isinstance(v,str) and v for v in values)
                    and len(set(values))==len(values),'astra_focus_invalid')
        require(set(selected)<=criteria.keys(),'astra_focus_unknown_criterion')
        require(set(materials)<=self.qa_material_hashes(t).keys()
                and any(value.startswith('artifact-') for value in materials),'astra_focus_unknown_material')
        outside=criteria.keys()-set(selected)
        require(not any(criteria[key]['kind']=='expert_review' for key in outside),'astra_focus_expert_criterion_missing')
        if db is None:
            with self.store.read() as read:
                return self.astra_focus_criteria(t,focus,db=read)
        require(all(self._validated_criterion(db,t,key) for key in outside),'astra_focus_outside_coverage_missing')
        return selected

    def _review_materials_bound(self,t,receipt):
        if receipt.get('channel') not in ('api_worker','subscription_codex'):
            return receipt.get('astra_focus') is None  # Legacy non-provider evidence.
        expected=self.qa_material_hashes(t)
        focus=receipt.get('astra_focus')
        if focus is not None:
            if not isinstance(focus,dict) or not isinstance(focus.get('material_ids'),list):
                return False
            expected={key:sha for key,sha in expected.items() if key in focus['material_ids']}
        return receipt.get('qa_material_sha256')==expected

    @staticmethod
    def _astra_collection_binding(t,report,receipt):
        author=t['meta']['author']
        binding = {
            'qa_binding': {'task_id':t['task_id'],'contract_version':t['contract_version'],
                'artifact_hash':t['meta']['snapshot']['hash'],'author_session_id':author['session_id'],
                'author_attempt_id':author['attempt_id'],'reviewer_role':'qa_astra',
                'astra_focus':receipt.get('astra_focus')},
            'provider_task_id':report['reviewer_attempt_id'],
            'package_hash':receipt.get('package_hash'),
        }
        if receipt.get('qa_rule_evidence'):
            binding['rule_evidence_sha256'] = digest(receipt['qa_rule_evidence'])
        return binding

    def accept(self,task_id,*,sol_decision_ref,decision='accept',actor='parent_main'):
        require(actor in ('parent_main','parent_sol'),'final_acceptance_owner')
        self._check_evidence([sol_decision_ref])
        with self.store.transaction() as db:
            t=self.store.task(task_id,db)
            require(t['state'] in ('VALIDATING','REVIEWING','AWAITING_ACCEPTANCE'),'not_awaiting_acceptance')
            reasons=[]
            s=t['meta'].get('snapshot')
            sh=s['hash'] if s else ''
            if not self._snapshot_valid(t):
                reasons.append('snapshot_changed')
            if not self._input_snapshots_valid(t):
                reasons.append('input_snapshot_drift')
            if t['meta'].get('hold'):
                reasons.append('release_hold')
            if t['meta'].get('result_unresolved'):
                reasons.append('worker_unresolved')
            author_attempt=(t['meta'].get('author') or {}).get('attempt_id')
            accounting=db.execute('SELECT * FROM budget_reservations WHERE attempt_id=?',(author_attempt,)).fetchone()
            if accounting and accounting['amount']>0:
                if accounting['state']!='settled' or accounting['actual'] is None:
                    reasons.append('api_accounting_unverified')
                else:
                    proof=json.loads(accounting['usage_json'])
                    ref=proof.get('evidence_ref','')
                    if not Path(ref).is_file() or file_hash(ref)!=proof.get('evidence_sha256'):
                        reasons.append('api_accounting_evidence_changed')
            for item in t['contract']['inputs']:
                if not Path(item['path']).is_file() or file_hash(item['path'])!=item['sha256']:
                    reasons.append('input_drift')
            for criterion in t['contract']['acceptance']:
                if not criterion['hard'] or criterion['kind']=='expert_review':
                    continue
                row=db.execute('SELECT receipt_json FROM validations WHERE task_id=? AND artifact_hash=? AND criterion_id=? AND contract_version=? AND author_attempt_id=? ORDER BY rowid DESC LIMIT 1',
                               (task_id,sh,criterion['id'],t['contract_version'],t['meta']['author']['attempt_id'])).fetchone()
                if not row or json.loads(row[0])['status']!='pass':
                    reasons.append('hard_check_not_passed:'+criterion['id'])
                elif any(not Path(ref).is_file() or file_hash(ref)!=saved for ref,saved in json.loads(row[0]).get('evidence_hashes',{}).items()):
                    reasons.append('validation_evidence_drift')
            profile=t['meta'].get('architecture_profile','legacy_v1')
            review_author=t['meta']['author']['role'] if profile in ('mandatory_delegation_v3','simplified_workflow_v5') else t['contract']['assigned_role']
            hard_expert=any(x['hard'] and x['kind']=='expert_review' for x in t['contract']['acceptance'])
            needs_review=reviewer_for(review_author,t['risk'],profile,hard_expert=hard_expert) is not None or hard_expert
            if needs_review:
                row=db.execute('SELECT report_json FROM reviews WHERE task_id=? AND artifact_hash=? AND contract_version=? AND author_attempt_id=? ORDER BY rowid DESC LIMIT 1',(task_id,sh,t['contract_version'],t['meta']['author']['attempt_id'])).fetchone()
                if not row:
                    reasons.append('review_missing')
                else:
                    review=json.loads(row[0])
                    if review['verdict']!='pass':
                        reasons.append('review_not_passed')
                    execution=review.get('execution_receipt',{})
                    if not self._review_materials_bound(t,execution):
                        reasons.append('qa_material_binding_invalid')
                    focus=execution.get('astra_focus')
                    if focus is not None or (review['reviewer_role']=='qa_astra' and t['meta'].get('astra_focus_required')):
                        if execution.get('astra_collection_binding')!=self._astra_collection_binding(t,review,execution):
                            reasons.append('astra_collection_proof_required')
                        try:
                            coverage=self.astra_focus_criteria(t,focus,db=db)
                            if set(review['checked_criteria'])!=set(coverage):
                                reasons.append('review_coverage_missing')
                        except ControlError as error:
                            reasons.append(error.code)
                    if any(not Path(ref).is_file() or file_hash(ref)!=saved for ref,saved in review.get('evidence_hashes',{}).items()):
                        reasons.append('review_evidence_drift')
                    if any(f['severity'] in ('critical','major') and f['status']!='resolved' for f in review['findings']):
                        reasons.append('material_finding_unresolved')
            if decision!='accept':
                reasons.append('sol_not_accepted')
            if reasons:
                # A still-unsettled API receipt is a recoverable admission gate;
                # preserve the validated snapshot for idempotent collection.
                if reasons!=['api_accounting_unverified']:
                    self._transition(db,t,'BLOCKED',';'.join(reasons),sol_decision_ref)
                outcome='block'
            else:
                if t['state']=='VALIDATING':
                    self._transition(db,t,'REVIEW_NOT_REQUIRED','low_risk_validated',sh)
                if t['state'] in ('REVIEWING','REVIEW_NOT_REQUIRED'):
                    self._transition(db,t,'AWAITING_ACCEPTANCE','gates_checked',sh)
                self._transition(db,t,'ACCEPTED','sol_and_controller_accepted',sol_decision_ref)
                t['meta']['accepted_hash']=sh
                self.store.meta(db,task_id,t['meta'])
                outcome='accept'
            receipt={'schema_version':'1.0','provenance':'runtime','task_id':task_id,'contract_version':t['contract_version'],
                     'artifact_hash':sh,'decision':outcome,'sol_decision_ref':sol_decision_ref,'reasons':reasons,'controller_version':'1.0'}
            db.execute('INSERT INTO acceptances VALUES(?,?,?,?,?,?,?,?,?)',(str(uuid.uuid4()),task_id,t['contract_version'],sh,outcome,sol_decision_ref,'1.0',canonical(receipt),str(time.time())))
            self._receipt(db,t,'acceptance',sh,receipt)
            if outcome=='accept':
                self._notify(db,t,'accepted',sh)
            return receipt

    def _notify(self,db,t,event_type,sh):
        # Task transition and outbox are committed in the same database transaction.
        eid=str(uuid.uuid4())
        payload={'task_id':t['task_id'],'contract_version':t['contract_version'],'artifact_hash':sh,'event_type':event_type}
        path=self.root/'events'/f'{eid}.json'
        atomic_json(path,payload)
        db.execute('INSERT INTO events(event_id,source,source_event_id,project_id,thread_key,event_type,payload_hash,payload_ref,trust_level,correlation_id,state,occurred_at,received_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',
                   (eid,'controller',eid,t['project_id'],t['task_id'],event_type,digest(payload),str(path),'trusted_internal',t['task_id'],'done',str(time.time()),str(time.time())))
        key=f"{t['task_id']}:{t['contract_version']}:{event_type}:{sh}"
        db.execute('INSERT OR IGNORE INTO outbox(outbox_id,event_id,delivery_key,destination,state) VALUES(?,?,?,?,?)',(str(uuid.uuid4()),eid,key,'local_inbox','pending'))

    def approve(self,task_id,*,action,target,expires_at,authorization_ref,actor='authorized_human'):
        require(actor=='authorized_human','human_approval_required')
        self._check_evidence([authorization_ref])
        with self.store.transaction() as db:
            t=self.store.task(task_id,db)
            require(t['meta']['accepted_hash'] and expires_at>time.time(),'approval_invalid')
            aid=str(uuid.uuid4())
            db.execute('INSERT INTO approvals VALUES(?,?,?,?,?,?,?,?,?,?,?)',
                       (aid,t['project_id'],task_id,t['meta']['accepted_hash'],action,target,actor,digest(t['contract']['permissions']),int(expires_at),'active',canonical({'authorization_ref':authorization_ref,'contract_version':t['contract_version']})))
            return aid

    def begin_action(self,task_id,*,action,target,approval_id=None,external_system='local_copy',idempotency_key=None):
        with self.store.transaction() as db:
            t=self.store.task(task_id,db)
            if not self._snapshot_valid(t):
                if t['state'] in ('ACCEPTED','WAITING_APPROVAL'):
                    self._transition(db,t,'BLOCKED','snapshot_changed_before_publish',task_id)
                t['meta']['accepted_hash']=None
                self.store.meta(db,task_id,t['meta'])
                return {'status':'blocked','reason':'snapshot_changed'}
            require(t['state'] in ('ACCEPTED','WAITING_APPROVAL') and t['meta']['accepted_hash']==t['meta']['snapshot']['hash'],'not_accepted')
            require(not t['meta'].get('hold'),'release_hold')
            old=db.execute("SELECT * FROM action_receipts WHERE task_id=? AND status IN ('prepared','started','unknown')",(task_id,)).fetchone()
            require(old is None,'action_requires_reconciliation')
            external=external_system!='local_copy'
            if external:
                a=db.execute('SELECT * FROM approvals WHERE approval_id=?',(approval_id,)).fetchone()
                require(a and a['status']=='active' and a['expires_at_epoch']>time.time()
                        and a['project_id']==t['project_id'] and a['task_id']==task_id and a['artifact_hash']==t['meta']['accepted_hash']
                        and a['action']==action and a['target']==target and a['permission_hash']==digest(t['contract']['permissions']),'approval_mismatch')
                require(action in t['contract']['permissions']['external_actions'],'external_action_not_in_contract')
                db.execute("UPDATE approvals SET status='consumed' WHERE approval_id=?",(approval_id,))
            else:
                permission(t['contract'],target,'write',[self.root,Path(__file__).parent])
                require(not Path(target).exists(),'publish_target_exists')
            action_id=str(uuid.uuid4())
            aid=t['meta']['author']['attempt_id']
            stamp=str(time.time())
            db.execute('INSERT INTO action_receipts VALUES(?,?,?,?,?,?,?,?,?,?)',(action_id,task_id,aid,idempotency_key,external_system,None,'prepared',t['meta']['accepted_hash'],stamp,stamp))
            db.execute('INSERT INTO action_bindings VALUES(?,?,?,?,?,?)',(action_id,t['contract_version'],t['meta']['accepted_hash'],action,target,digest(t['contract']['permissions'])))
            return {'action_id':action_id,'status':'prepared','snapshot':t['meta']['snapshot'],'target':target}

    def finish_action(self,action_id,*,status,evidence_ref,external_reference=None):
        require(status in ('succeeded','failed','unknown'),'action_status_invalid')
        self._check_evidence([evidence_ref])
        with self.store.transaction() as db:
            row=db.execute('SELECT * FROM action_receipts WHERE action_id=?',(action_id,)).fetchone()
            require(row and row['status'] in ('prepared','started','unknown'),'action_already_terminal')
            t=self.store.task(row['task_id'],db)
            binding=db.execute('SELECT * FROM action_bindings WHERE action_id=?',(action_id,)).fetchone()
            require(binding is not None,'action_binding_missing')
            db.execute('UPDATE action_receipts SET status=?,evidence_ref=?,external_reference=?,updated_at=? WHERE action_id=?',(status,evidence_ref,external_reference,str(time.time()),action_id))
            if binding['contract_version']!=t['contract_version'] or binding['artifact_hash']!=t['meta'].get('accepted_hash'):
                # Record the real historical external outcome without promoting a
                # later contract or claiming it can undo the old external action.
                return {'status':status,'state':t['state'],'historical_action_only':True}
            if status=='succeeded':
                if t['state']=='WAITING_APPROVAL':
                    self._transition(db,t,'ACCEPTED','approved_action_completed',evidence_ref)
                self._transition(db,t,'PUBLISHED','actual_publication_confirmed',evidence_ref)
            elif status=='unknown':
                t['meta']['hold']='unknown_external_action'
                self.store.meta(db,t['task_id'],t['meta'])
            return {'status':status,'state':t['state']}

    def publish_local(self,task_id,target):
        current=self.store.task(task_id)
        require(current['meta'].get('snapshot') and len(current['meta']['snapshot']['manifest'])==1,'single_artifact_required')
        prepared=self.begin_action(task_id,action='copy',target=str(target))
        if prepared['status']=='blocked':
            return prepared
        require(len(prepared['snapshot']['manifest'])==1,'single_artifact_required')
        item=prepared['snapshot']['manifest'][0]
        target=Path(target)
        target.parent.mkdir(parents=True,exist_ok=True)
        try:
            # Exclusive create, no overwrite. Only verified snapshot bytes are published.
            data=Path(item['path']).read_bytes()
            require(digest(data)==item['sha256'],'snapshot_changed')
            with target.open('xb') as f:
                f.write(data)
                f.flush()
            require(file_hash(target)==item['sha256'],'publication_hash_mismatch')
            receipt=self.root/'actions'/f"{prepared['action_id']}.json"
            atomic_json(receipt,{'target':str(target.resolve()),'sha256':file_hash(target),'action_id':prepared['action_id']})
            return self.finish_action(prepared['action_id'],status='succeeded',evidence_ref=str(receipt))
        except Exception:
            evidence=self.root/'actions'/f"{prepared['action_id']}-unknown.json"
            atomic_json(evidence,{'status':'unknown','reason':'local_copy_interrupted; reconcile target hash before retry'})
            self.finish_action(prepared['action_id'],status='unknown',evidence_ref=str(evidence))
            raise

    def reconcile_attempt(self,attempt_id,observation):
        """Only observed terminal execution releases a writer or uncertain budget."""
        status=observation.get('status')
        require(status in ('running','completed','failed','cancelled','unknown'),'invalid_observation')
        self._check_evidence([observation.get('evidence_ref','')])
        with self.store.transaction() as db:
            row=db.execute('SELECT * FROM attempts WHERE attempt_id=?',(attempt_id,)).fetchone()
            require(row is not None,'attempt_not_found')
            t=self.store.task(row['task_id'],db)
            if row['status'] in ('completed','failed','cancelled'):
                require(status==row['status'],'terminal_observation_conflict')
                return {'status':status,'unchanged':True}
            if status=='completed':
                # Collect still needs the active attempt's fences; do not free it here.
                db.execute("UPDATE attempts SET status='waiting_external' WHERE attempt_id=?",(attempt_id,))
                return {'status':'collect_required','rerun':False}
            db.execute('UPDATE attempts SET status=? WHERE attempt_id=?',(status,attempt_id))
            if status in ('failed','cancelled'):
                self._unbind(db,row)
                db.execute('UPDATE resource_leases SET owner_attempt_id=? WHERE owner_attempt_id=?',('',attempt_id))
                new='CANCELLED' if status=='cancelled' else 'FAILED'
                if new in self.transitions.get(t['state'],[]):
                    self._transition(db,t,new,'terminal_execution_observed',observation['evidence_ref'],attempt=attempt_id)
            elif status=='unknown' and 'UNKNOWN_EXECUTION' in self.transitions.get(t['state'],[]):
                self._transition(db,t,'UNKNOWN_EXECUTION','execution_requires_reconciliation',observation['evidence_ref'],attempt=attempt_id)
            return {'status':status,'rerun':False}

    def settle_budget(self,attempt_id,*,actual_micro_usd=None,usage=None,confirmed_no_charge=False,evidence_ref):
        self._check_evidence([evidence_ref])
        require(actual_micro_usd is None or type(actual_micro_usd) is int and actual_micro_usd>=0,'invalid_usage')
        require(actual_micro_usd is not None or confirmed_no_charge,'billing_unconfirmed')
        with self.store.transaction() as db:
            row=db.execute('SELECT * FROM budget_reservations WHERE attempt_id=?',(attempt_id,)).fetchone()
            require(row is not None,'reservation_not_found')
            exceeded=actual_micro_usd is not None and actual_micro_usd>row['amount']
            if exceeded:
                t=self.store.task(row['task_id'],db)
                t['meta']['hold']='budget_authorization_exceeded'
                self.store.meta(db,t['task_id'],t['meta'])
            db.execute('UPDATE budget_reservations SET actual=?,state=?,usage_json=? WHERE attempt_id=?',
                       (actual_micro_usd if actual_micro_usd is not None else 0,'over_authorization' if exceeded else 'settled',canonical({'usage':usage or {},'evidence_ref':evidence_ref,'evidence_sha256':file_hash(evidence_ref),'subscription_quota':'unknown'}),attempt_id))

    def rework(self,task_id,*,reason,evidence_ref):
        self._check_evidence([evidence_ref])
        with self.store.transaction() as db:
            t=self.store.task(task_id,db)
            require(not db.execute("SELECT 1 FROM attempts WHERE task_id=? AND status IN ('starting','running','waiting_external','unknown')",(task_id,)).fetchone(),'reconcile_active_before_rework')
            require(t['meta'].get('hold')!='budget_authorization_exceeded','resolve_budget_overrun_before_rework')
            cap=t['contract']['budget']['max_rework_rounds']
            require(t['meta']['rework_rounds']<cap,'rework_limit_escalate')
            if t['state']=='BLOCKED':
                self._transition(db,t,'READY',reason,evidence_ref)
            else:
                self._transition(db,t,'REWORK',reason,evidence_ref)
                self._transition(db,t,'READY','rework_authorized',evidence_ref)
            t['meta'].update(accepted_hash=None,snapshot=None,author=None,hold=None,rework_rounds=t['meta']['rework_rounds']+1)
            self.store.meta(db,task_id,t['meta'])
            db.execute('UPDATE resource_usage SET rework=rework+1 WHERE task_id=?',(task_id,))

    def revise(self,task_id,new_contract,*,decision_ref,actor='parent_main'):
        require(actor in ('parent_main','parent_sol'),'plan_authority_required')
        self._check_evidence([decision_ref])
        self.schema('task',new_contract)
        # Revised scope is explicit and versioned, never inferred from an event.
        with self.store.transaction() as db:
            t=self.store.task(task_id,db)
            require(new_contract['task_id']==task_id and new_contract['project_id']==t['project_id']
                    and new_contract['contract_version']==t['contract_version']+1,'revision_identity_mismatch')
            require(new_contract['assigned_role'] in ROLE_TARGETS,'unknown_role')
            self.enforce_assignment(t['meta'].get('architecture_profile','legacy_v1'),new_contract)
            active=db.execute("SELECT * FROM attempts WHERE task_id=? AND status IN ('starting','running','waiting_external','unknown')",(task_id,)).fetchall()
            # Retain ownership while old execution is being reconciled. Its callback
            # is fenced by contract version and cannot promote the revised task.
            frozen=[]
            for i,item in enumerate(new_contract['inputs']):
                p=permission(new_contract,item['path'],'read',[self.root,Path(__file__).parent])
                require(p.is_file() and file_hash(p)==item['sha256'],'input_hash_mismatch')
                dest=self.root/'tasks'/task_id/f"v{new_contract['contract_version']}"/'inputs'/f'{i}-{p.name}'
                dest.parent.mkdir(parents=True,exist_ok=True)
                require(not dest.exists(),'snapshot_exists')
                shutil.copyfile(p,dest)
                require(file_hash(dest)==item['sha256'],'input_changed_while_freezing')
                frozen.append({'path':str(dest),'sha256':item['sha256'],'original':str(p)})
            ch=digest(new_contract)
            db.execute('INSERT INTO task_versions VALUES(?,?,?,?)',(task_id,new_contract['contract_version'],canonical(new_contract),ch))
            old=t['state']
            t['meta'].update(accepted_hash=None,snapshot=None,author=None,input_snapshots=frozen,hold='prior_version_execution' if active else None)
            if t['meta'].get('architecture_profile')=='mandatory_delegation_v3':
                t['meta']['astra_focus_required']=True
                if self.config.get('native_astra_qa_boundary') == 'review_rules_v1':
                    t['meta']['native_astra_qa_boundary']='review_rules_v1'
            db.execute('UPDATE tasks SET state=?,state_version=state_version+1,contract_version=?,contract_hash=?,contract_json=?,risk=?,complexity=?,updated_at=? WHERE task_id=?',
                       ('BLOCKED' if active else 'READY',new_contract['contract_version'],ch,canonical(new_contract),new_contract['risk'],new_contract['complexity'],str(time.time()),task_id))
            self.store.meta(db,task_id,t['meta'])
            self._audit(db,t,old,'BLOCKED' if active else 'READY','explicit_contract_revision',decision_ref)
            atomic_json(self.root/'tasks'/task_id/f"v{new_contract['contract_version']}"/'task.json',new_contract)
        return self.inspect(task_id)

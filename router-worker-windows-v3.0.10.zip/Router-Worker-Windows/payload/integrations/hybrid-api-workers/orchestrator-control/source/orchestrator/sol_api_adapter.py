"""Tool-aware Responses adapter candidate; credentials remain in the existing adapter."""
import json
import urllib.error
if __package__:
    from .sol_execution_loop import ProviderRejected
else:
    from sol_execution_loop import ProviderRejected

ELIGIBLE_REJECTIONS={'credit_balance_exhausted','organization_spend_limit_exceeded','project_spend_limit_exceeded',
                     'organization_usage_limit_exceeded','rate_limit_exceeded','model_not_found'}


class ToolAwareAdapter:
    def __init__(self, openai_adapter, *, attempt=1):
        self.adapter=openai_adapter
        self.attempt=attempt

    def count(self,payload):
        keys=('model','instructions','input','tools','parallel_tool_calls')
        value,_=self.adapter.post('responses/input_tokens',{key:payload[key] for key in keys if key in payload})
        count=value.get('input_tokens')
        if type(count) is not int or count < 0:
            raise ValueError('Provider input token count unavailable')
        return count

    def prepare_round(self,task_id,number):
        attempt_suffix='' if self.attempt==1 else f'-a{self.attempt}'
        self.adapter.client_request_id=f'hybrid-{task_id}{attempt_suffix}-r{number}'

    def run(self,payload):
        # The existing SSE handler tracks a single response id. Until per-round
        # streaming has its own durable transport, use one foreground response.
        wire=dict(payload);wire['stream']=False
        try:return self.adapter.post('responses',wire)
        except urllib.error.HTTPError as error:
            if error.code in (404,429):
                try:code=json.loads(error.read(65536)).get('error',{}).get('code')
                except (ValueError,OSError):code=None
                if code in ELIGIBLE_REJECTIONS:
                    raise ProviderRejected(code,error.headers.get('x-request-id') if error.headers else None) from None
            raise

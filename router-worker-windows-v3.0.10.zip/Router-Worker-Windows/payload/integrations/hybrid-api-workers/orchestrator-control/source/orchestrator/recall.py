from __future__ import annotations
import json
from pathlib import Path
import time
from .common import canonical, file_hash, require, within

class Recall:
    def __init__(self,controller):
        self.c=controller

    def record(self,*,record_id,project_id,kind,version,source,read_roots,data,sensitivity='project',expires_at=None,supersedes=None):
        require(kind in ('fact','hypothesis','decision','evidence','artifact'),'recall_kind')
        require(sensitivity in ('public','project','confidential'),'recall_sensitivity')
        require(within(source,read_roots) and Path(source).is_file(),'recall_source_not_authorized')
        with self.c.store.transaction() as db:
            if supersedes:
                old=db.execute('SELECT * FROM recall_records WHERE record_id=?',(supersedes,)).fetchone()
                require(old and old['project_id']==project_id and version>old['version'],'invalid_supersession')
                db.execute("UPDATE recall_records SET status='superseded' WHERE record_id=?",(supersedes,))
            db.execute('INSERT INTO recall_records VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',
                       (record_id,project_id,kind,version,str(Path(source).resolve()),file_hash(source),time.time(),expires_at,sensitivity,'active',supersedes,canonical(data)))
        return record_id

    def search(self,project_id,query,*,authorized_projects,read_roots,include_confidential=False,limit=10):
        require(project_id in authorized_projects,'recall_project_denied')
        require(type(limit) is int and 0<limit<=50,'recall_limit')
        with self.c.store.read() as db:
            rows=db.execute("SELECT * FROM recall_records WHERE project_id=? AND status='active' ORDER BY created_at DESC",(project_id,)).fetchall()
        found=[]
        for row in rows:
            if query.casefold() not in row['data'].casefold():
                continue
            require(row['expires_at'] is None or row['expires_at']>time.time(),'recall_source_expired')
            require(within(row['source'],read_roots),'recall_source_not_authorized')
            require(row['sensitivity']!='confidential' or include_confidential,'recall_sensitivity_denied')
            require(Path(row['source']).is_file() and file_hash(row['source'])==row['source_hash'],'recall_source_stale_or_unreadable')
            found.append({'evidence_id':row['record_id'],'project_id':project_id,'kind':row['kind'],
                          'source':row['source'],'source_hash':row['source_hash'],'version':row['version'],
                          'created_at':row['created_at'],'sensitivity':row['sensitivity'],'summary':json.loads(row['data'])})
            if len(found)>=limit:
                break
        return found

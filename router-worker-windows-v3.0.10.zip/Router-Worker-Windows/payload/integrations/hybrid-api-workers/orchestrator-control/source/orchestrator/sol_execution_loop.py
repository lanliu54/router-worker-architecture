"""Bounded stateless tool-loop candidate; not wired to production dispatch.

All side effects are mediated by injected, independently authorized components.
The durable journal must atomically reserve and mark each request before network
dispatch and each tool before execution. Uncertain attempts are never replayed.
"""
from copy import deepcopy
from decimal import Decimal, ROUND_CEILING
import json


class ExecutionError(Exception):
    pass


class ProviderRejected(ExecutionError):
    def __init__(self,code,request_id):
        super().__init__('Confirmed pre-generation provider rejection')
        self.code=code;self.request_id=request_id


TOOL = {'type':'function','name':'run_python','description':'Run Python in the task candidate workspace.',
        'strict':True,'parameters':{'type':'object','properties':{'code':{'type':'string'}},
                                   'required':['code'],'additionalProperties':False}}


def _micro_cost(input_tokens, output_tokens, input_rate, output_rate):
    return int((Decimal(input_tokens)*Decimal(str(input_rate)) +
                Decimal(output_tokens)*Decimal(str(output_rate))).to_integral_value(rounding=ROUND_CEILING))


def execute(*, task_id, payload, adapter, runner, journal, cap_micro_usd,
            input_rate, output_rate, input_limit=128000, max_rounds=3, max_tools=2,
            output_limit=4096, max_tool_output_bytes=16384):
    """Run once. Journal is the ownership/budget source; caller owns acceptance.

    adapter.count takes an entire Responses payload including tools; adapter.run
    returns the terminal response and provider request id. runner.run_python
    returns a JSON-serializable bounded actual execution receipt. journal methods
    are strict atomic operations, not best-effort logs. This function does not
    auto-retry, reset, resume uncertain work, or apply files to user projects.
    """
    if (not task_id or type(cap_micro_usd) is not int or cap_micro_usd <= 0 or
        type(max_rounds) is not int or not 1 <= max_rounds <= 3 or
        type(max_tools) is not int or not 0 <= max_tools <= 2 or
        type(output_limit) is not int or not 1 <= output_limit <= 16384 or
        type(input_limit) is not int or not 1 <= input_limit <= 256000 or
        Decimal(str(input_rate)) <= 0 or Decimal(str(output_rate)) <= 0):
        raise ExecutionError('invalid bounded execution contract')
    base = deepcopy(payload)
    if base.get('model') != 'gpt-6.1-sol' or base.get('reasoning',{}).get('effort') != 'high':
        raise ExecutionError('wrong execution model or effort')
    if type(base.get('store')) is not bool or base.get('background') is not False:
        raise ExecutionError('explicit retention and foreground response required')
    if not isinstance(base.get('input'),list) or 'tools' in base:
        raise ExecutionError('invalid source payload')
    base['tools'] = [deepcopy(TOOL)]
    base['parallel_tool_calls'] = False
    base['include'] = ['reasoning.encrypted_content']
    base['max_output_tokens'] = output_limit
    spent = 0
    used_tools = 0
    journal.begin(task_id, cap_micro_usd)
    for round_no in range(1,max_rounds+1):
        try:
            count = adapter.count(base)
        except Exception:
            journal.stop(task_id,'input_count_failed')
            raise
        if type(count) is not int or count < 0 or count > input_limit:
            journal.stop(task_id,'input_limit')
            raise ExecutionError('complete input exceeds limit')
        reserved = _micro_cost(count, output_limit, input_rate, output_rate)
        if spent + reserved > cap_micro_usd:
            journal.stop(task_id,'budget_exhausted')
            raise ExecutionError('per-task API cap would be exceeded')
        journal.reserve_request(task_id,round_no,reserved,spent)
        try:
            if hasattr(adapter,'prepare_round'):
                adapter.prepare_round(task_id,round_no)
            response, request_id = adapter.run(deepcopy(base))
        except ProviderRejected as error:
            journal.reject_request(task_id,round_no,error.code,error.request_id,round_no==1 and used_tools==0 and spent==0)
            raise
        except Exception:
            journal.unknown_request(task_id,round_no)
            raise
        if not isinstance(response,dict):
            journal.unknown_request(task_id,round_no)
            raise ExecutionError('provider response is malformed')
        usage=response.get('usage',{})
        if any(type(usage.get(k)) is not int or usage[k] < 0 for k in ('input_tokens','output_tokens')):
            journal.unknown_request(task_id,round_no)
            raise ExecutionError('provider usage unavailable; preserve reservation')
        cost=_micro_cost(usage['input_tokens'],usage['output_tokens'],input_rate,output_rate)
        if cost > reserved:
            journal.unknown_request(task_id,round_no)
            raise ExecutionError('reported usage exceeds reserved estimate')
        spent += cost
        journal.complete_request(task_id,round_no,response.get('id'),request_id,usage,cost)
        if (response.get('status') != 'completed' or response.get('model') != 'gpt-6.1-sol' or
            (response.get('reasoning') or {}).get('effort','high') != 'high'):
            journal.stop(task_id,'invalid_terminal_response')
            raise ExecutionError('unexpected provider status, model or effort')
        outputs=response.get('output',[])
        if not isinstance(outputs,list) or any(not isinstance(item,dict) for item in outputs):
            journal.stop(task_id,'invalid_output')
            raise ExecutionError('provider output is malformed')
        if any(part.get('type')=='refusal' for item in outputs if item.get('type')=='message'
               for part in item.get('content',[]) if isinstance(part,dict)):
            journal.stop(task_id,'provider_refusal')
            raise ExecutionError('provider refused the request')
        calls=[item for item in outputs if item.get('type')=='function_call']
        if not calls:
            texts=[content.get('text','') for item in outputs if item.get('type')=='message'
                   for content in item.get('content',[]) if content.get('type')=='output_text']
            if not texts:
                journal.stop(task_id,'missing_final_output')
                raise ExecutionError('missing final output')
            journal.finish(task_id,spent)
            return {'text':''.join(texts),'cost_micro_usd':spent,'tool_calls':used_tools,'rounds':round_no}
        if len(calls)!=1 or used_tools>=max_tools or round_no==max_rounds:
            journal.stop(task_id,'tool_limit')
            raise ExecutionError('tool count or round limit exceeded')
        call=calls[0]
        try:
            args=json.loads(call['arguments'])
            if (call.get('name')!='run_python' or not isinstance(call.get('call_id'),str) or
                not isinstance(args,dict) or set(args)!={'code'} or not isinstance(args['code'],str) or
                not 0<len(args['code'].encode('utf-8'))<=32768):
                raise ValueError('unsupported tool input')
        except (KeyError,ValueError,TypeError):
            journal.stop(task_id,'invalid_tool_call')
            raise ExecutionError('invalid tool call') from None
        call_id=call['call_id']
        journal.begin_tool(task_id,round_no,call_id,args)
        try:
            result=runner.run_python(args['code'])
            encoded=json.dumps(result,ensure_ascii=False,allow_nan=False)
            if len(encoded.encode('utf-8'))>max_tool_output_bytes:
                raise ExecutionError('tool output exceeds bound')
        except Exception:
            journal.unknown_tool(task_id,round_no,call_id)
            raise
        journal.complete_tool(task_id,round_no,call_id,result)
        used_tools += 1
        # Replay the complete original input and returned items in either retention mode.
        base['input'].extend(deepcopy(outputs))
        base['input'].append({'type':'function_call_output','call_id':call_id,'output':encoded})
    raise ExecutionError('unreachable round termination')

"""Bounded hook bridge: structured denial, context summary and durable spool only.

Hooks never start models, sign acceptance or claim that they can undo a tool.
The existing native UI ownership hook remains separately authoritative.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import sqlite3
import sys
from .common import ControlError, atomic_json, canonical, digest, require
from .policy import permission

VERSION='1'
EVENTS=('SessionStart','SubagentStart','PreToolUse','PostToolUse','SubagentStop','Stop')

def denial(reason):
    return {'hookSpecificOutput':{'hookEventName':'PreToolUse','permissionDecision':'deny','permissionDecisionReason':reason}}

def handle(runtime,payload,*,primary_identity_check=None):
    runtime=Path(runtime).resolve()
    event=payload.get('hook_event_name') or payload.get('event_name')
    require(event in EVENTS,'unsupported_hook_event')
    sid=payload.get('session_id')
    # Missing identifiers cannot become an unscoped broad task event.
    if not sid:
        return {'systemMessage':'Orchestrator hook: session identity unavailable; no task binding applied.'}
    dbpath=runtime/'state.sqlite'
    binding=None
    contract=None
    if dbpath.is_file():
        db=sqlite3.connect(dbpath.as_uri()+'?mode=ro',uri=True,timeout=0.5)
        try:
            row=db.execute('SELECT value FROM controller_settings WHERE key=?',('session_binding:'+sid,)).fetchone()
            if row:
                binding=json.loads(row[0])
                task=db.execute('SELECT contract_json,state FROM tasks WHERE task_id=?',(binding['task_id'],)).fetchone()
                if task:
                    contract=json.loads(task[0])
        finally:
            db.close()
    if event=='SessionStart':
        return {'hookSpecificOutput':{'hookEventName':event,'additionalContext':
                'Local Router-Worker controller is available in Observe mode. Hooks are not acceptance evidence. Read the installed runbook for current capability and pending inbox checks.'}}
    if not binding:
        return {}  # Do not impose task permissions on unrelated chats.
    if event=='PreToolUse':
        if not contract:
            return denial('Bound task contract is unavailable; controlled execution is blocked.')
        name=payload.get('tool_name','')
        primary=binding.get('role')=='main_terra'
        if primary:
            try:verified=bool(primary_identity_check and primary_identity_check(payload))
            except Exception:verified=False
            if not verified:return denial('Primary task binding does not match observed Terra/high root identity.')
        if name not in contract['permissions']['tools']:
            return denial('Tool is outside the bound task allowlist.')
        # Shell/code wrappers cannot be authorized by a path-string heuristic.
        if not primary and (name in ('exec','functions.exec','exec_command','shell','js') or name.endswith(('__js','__exec_command'))):
            return denial('Dynamic execution needs the trusted process adapter and a bounded tool registry.')
        args=payload.get('tool_input') or {}
        if not isinstance(args,dict):
            return denial('Unstructured controlled tool input cannot be permission-checked.')
        for field,op in (('path','write' if name in ('write_file','apply_patch') else 'read'),
                         ('source_path','read'),('destination_path','write')):
            if field in args:
                try:
                    permission(contract,args[field],op,[runtime,Path(__file__).parent])
                except (ControlError,OSError):
                    return denial('Resolved path is outside the bound task permission.')
        if name in ('apply_patch','write_file') and 'path' not in args:
            return denial('A structured target path is required; raw patch text is not an authority boundary.')
    turn=payload.get('turn_id') or payload.get('turn', '')
    tool_id=payload.get('tool_use_id') or payload.get('tool_call_id','')
    # Stop events without a host invocation ID are coalesced once per session/task
    # state, rather than creating a timer-dependent pseudo-unique event.
    identity={'session':sid,'turn':turn,'tool_use_id':tool_id,'event':event,'handler_version':VERSION,
              'task_id':binding['task_id'],'contract_version':contract['contract_version'] if contract else None}
    key=digest(identity)
    spool=runtime/'hook-spool'/f'{key}.json'
    record={'identity':identity,'task_id':binding['task_id'],'event_type':'hook.'+event,
            'argument_hash':digest(payload.get('tool_input',{})),'untrusted_payload_retained':False}
    spool.parent.mkdir(parents=True,exist_ok=True)
    try:
        with spool.open('x',encoding='utf-8') as f:
            f.write(canonical(record)+'\n')
    except FileExistsError:
        pass
    if event=='Stop':
        return {'systemMessage':'Orchestrator: result submission and validation are separate from final acceptance; unfinished gates remain pending.'}
    return {}

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--runtime',required=True)
    args=p.parse_args()
    try:
        raw=sys.stdin.buffer.read(1024*1024+1)
        require(len(raw)<=1024*1024,'hook_input_too_large')
        payload=json.loads(raw)
        result=handle(args.runtime,payload)
    except Exception:
        # No arbitrary payload/error content or credentials are echoed.
        result=denial('Local task policy could not be checked.') if isinstance(locals().get('payload'),dict) and payload.get('hook_event_name')=='PreToolUse' else {'systemMessage':'Orchestrator hook unavailable; controller gates remain closed.'}
    print(canonical(result))

if __name__=='__main__':
    main()

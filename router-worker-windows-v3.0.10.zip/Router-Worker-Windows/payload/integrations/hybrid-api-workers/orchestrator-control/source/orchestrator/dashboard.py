from __future__ import annotations
import html
import json
from pathlib import Path
from .common import atomic_json

def snapshot(controller):
    with controller.store.read() as db:
        tasks=[dict(r) for r in db.execute('SELECT task_id,project_id,state,state_version,contract_version,risk,updated_at FROM tasks ORDER BY updated_at DESC')]
        attempts=[dict(r) for r in db.execute('SELECT attempt_id,task_id,role,status,model_requested,effort_requested,model_reported,identity_evidence_level,channel FROM attempts ORDER BY rowid DESC LIMIT 100')]
        budget=[dict(r) for r in db.execute('SELECT task_id,attempt_id,amount,actual,state FROM budget_reservations')]
        inbox=[dict(r) for r in db.execute("SELECT * FROM continuation_inbox WHERE state='pending' ORDER BY rowid DESC LIMIT 50")]
        events=[dict(r) for r in db.execute('SELECT event_id,source,project_id,event_type,state,retry_count FROM events ORDER BY rowid DESC LIMIT 50')]
        approvals=[dict(r) for r in db.execute('SELECT task_id,action,target,status,expires_at_epoch FROM approvals')]
        errors=[dict(r) for r in db.execute('SELECT * FROM failures')]
        observations=[{'attempt_id':r['attempt_id'],**json.loads(r['data'])} for r in db.execute('SELECT * FROM observations')]
    return {'mode':controller.config['mode'],'dispatch_enabled':controller.config['dispatch_enabled'],
            'events_enabled':controller.config['events_enabled'],
            'source_root':str(Path(__file__).resolve().parents[1]),
            'observe_all_bound_projects':controller.config.get('observe_all_bound_projects',False),
            'tasks':tasks,'attempts':attempts,'budget':budget,
            'inbox':inbox,'events':events,'approvals':approvals,'recent_failures':errors,'progress':observations,
            'subscription_quota':'unknown','availability_note':'Requires a running local process; sleep/shutdown pauses service. Native original-session wakeup is not implemented.'}

def render(controller,destination):
    data=snapshot(controller)
    destination.mkdir(parents=True,exist_ok=True)
    atomic_json(destination/'status.json',data)
    esc=lambda x:html.escape(str(x))
    table=lambda rows: '<p>无记录</p>' if not rows else '<table><thead><tr>'+''.join('<th>'+esc(k)+'</th>' for k in rows[0])+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+esc(v)+'</td>' for v in row.values())+'</tr>' for row in rows)+'</tbody></table>'
    body=f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Router–Worker 运行状态</title>
<style>body{{font:15px system-ui,sans-serif;background:#f4f6fa;color:#172438;margin:0;padding:32px}}main{{max-width:1200px;margin:auto}}section{{background:white;padding:22px;margin:18px 0;border-radius:14px;overflow:auto}}h1{{font-size:28px}}h2{{font-size:19px}}table{{border-collapse:collapse;width:100%;font-size:13px}}td,th{{text-align:left;border-bottom:1px solid #e2e8f0;padding:9px;max-width:300px;overflow-wrap:anywhere}}.mode{{padding:12px;background:#e4eefb;border-radius:8px}}</style><main>
<h1>Router–Worker 运行状态</h1><p class="mode">模式：{esc(data['mode'])} · 自动分发：{esc(data['dispatch_enabled'])} · 事件消费：{esc(data['events_enabled'])} · 观察所有已绑定项目：{esc(data['observe_all_bound_projects'])}</p>
<p>这是自定义本地控制层。订阅用量未知；完成、验收和发布分别记录。电脑休眠或关机会暂停服务；原主会话不会被伪称已自动唤醒。</p>'''
    for title,key in [('任务','tasks'),('模型与通道','attempts'),('预算预留与核销（micro USD）','budget'),('待处理续接','inbox'),('事件','events'),('人工批准','approvals'),('最近失败','recent_failures')]:
        body+=f'<section><h2>{title}</h2>{table(data[key])}</section>'
    body+='</main></html>'
    (destination/'index.html').write_text(body,encoding='utf-8')
    return str(destination/'index.html')

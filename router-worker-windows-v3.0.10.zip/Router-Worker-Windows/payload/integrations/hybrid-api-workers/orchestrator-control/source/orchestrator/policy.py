from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
from .common import digest, require, within

# Preserve installed identity. The design's example root/QA medium is not applied.
ROLE_TARGETS = {
    'main_terra': ('gpt-6.1-terra','high','subscription_codex'),
    'router_sol': ('gpt-6.1-sol','high','subscription_codex'),
    'qa_sol': ('gpt-6.1-sol','high','api_worker'),
    'executor_sol': ('gpt-6.1-sol','high','api_worker'),
    'planner_astra': ('gpt-6-astra','high','api_worker'),
    'qa_astra': ('gpt-6-astra','high','api_worker'),
    'writer_terra': ('gpt-6.1-terra','medium','api_worker'),
    'qa_terra': ('gpt-6.1-terra','medium','api_worker'),
    'executor_luna': ('gpt-6-luna','high','api_worker'),
    'desktop_terra': ('gpt-6.1-terra','medium','native_desktop'),
}
API_ROLE = {'planner_astra':'api_astra_review','qa_astra':'api_astra_review',
            'executor_luna':'api_luna_batch','qa_sol':'api_sol_qa','executor_sol':'api_sol_execution'}
API_CAPS = {'api_luna_batch':100000,'api_terra_content':500000,'api_astra_review':3500000,'api_sol_qa':1000000,'api_sol_execution':2000000}
API_CAPS_V3 = {**API_CAPS, 'api_luna_batch':200000, 'api_sol_execution':2500000}

def api_cap(task, role):
    version = task['meta'].get('api_policy_version', 2)
    if version not in (2, 3):
        raise ValueError('Unsupported frozen API budget policy')
    return (API_CAPS_V3 if version == 3 else API_CAPS)[role]

# The parent classifies the task; the controller enforces the frozen mapping.
# This is not a semantic classifier or a host-wide security boundary.
MANDATORY_ASSIGNMENTS = {
    'primary_ui':'main_terra', 'vision':'main_terra', 'writing':'main_terra', 'coordination':'main_terra',
    'batch_extraction':'executor_luna', 'technical_implementation':'executor_sol',
    'substantive_analysis':'planner_astra', 'substantive_review':'qa_astra', 'independent_qa':'qa_sol',
}

SIMPLIFIED_ASSIGNMENTS = {
    **MANDATORY_ASSIGNMENTS,
    'routine_fixed_process': 'executor_luna',
    'planning': 'planner_astra',
    'substantive_review': 'qa_sol',
}

def reviewer_for(role,risk,architecture_profile='legacy_v1', *, hard_expert=False):
    if architecture_profile=='simplified_workflow_v5':
        return 'qa_sol' if risk in ('L2','L3') or hard_expert else None
    if risk=='L1':
        return None
    if architecture_profile=='mandatory_delegation_v3':
        return 'qa_astra' if role=='executor_sol' else 'qa_sol'
    if architecture_profile=='terra_main_v2':return 'qa_sol'
    return 'qa_terra' if role=='executor_luna' else 'qa_sol'

def same_model_family(left,right):
    def family(model):
        return next((name for name in ('terra','sol','luna','astra') if name in model.lower()),model.lower())
    return family(left)==family(right)

@dataclass(frozen=True)
class Requirement:
    model: str
    effort: str
    role_hash: str
    permission_hash: str
    input_hash: str
    acceptance_hash: str
    tools: tuple[str,...]

def requirement(contract, role_prompt):
    model,effort,_=ROLE_TARGETS[contract['assigned_role']]
    return Requirement(model,effort,digest(role_prompt.encode()),digest(contract['permissions']),
                       digest(contract['inputs']),digest(contract['acceptance']),tuple(contract['permissions']['tools']))

def channel(requirement,api_state,capability=None,execution='not_started',*,total_available=True,desktop=False):
    if not total_available:
        return 'BLOCKED_TOTAL_BUDGET'
    if execution=='unknown' or api_state=='timeout':
        return 'UNKNOWN_EXECUTION'
    if execution=='running':
        return 'KEEP_CURRENT'
    if execution not in ('not_started','confirmed_failed_no_side_effect'):
        return 'BLOCKED_EXECUTION'
    if api_state in ('permission_denied','policy_denied','auth_security_error','refused'):
        return 'BLOCKED_SECURITY'
    if desktop:
        return 'native_desktop' if capability and capability.get('native_verified') else 'BLOCKED_CAPABILITY'
    if api_state=='healthy':
        return 'api_worker'
    if api_state=='rate_limited':
        return 'BOUNDED_RETRY'
    if api_state in ('invalid_request','context_overflow'):
        return 'REPAIR_REQUEST'
    if api_state not in ('quota_exhausted','unavailable','local_api_cap'):
        return 'BLOCKED_CAPABILITY'
    if not capability or not capability.get('available') or capability.get('channel')!='subscription_codex':
        return 'BLOCKED_CAPABILITY'
    for key,value in asdict(requirement).items():
        if key=='tools':
            if not set(value)<=set(capability.get(key,[])):
                return 'BLOCKED_CAPABILITY'
        elif capability.get(key)!=value:
            return 'BLOCKED_CAPABILITY'
    return 'subscription_codex'

def permission(contract,path,operation,protected=()):
    require(operation in ('read','write'),'permission_operation')
    p=Path(path).resolve()
    rules=contract['permissions']
    denied=list(rules['denied_paths'])+list(protected)
    if operation=='write':
        # Raw sources always remain immutable, even if an allow directory is broad.
        denied += [x['path'] for x in contract['inputs']]
    require(not within(p,denied),'permission_denied')
    roots=rules['read_paths'] if operation=='read' else rules['write_paths']
    require(within(p,roots),'permission_denied')
    return p

def intersect_policy(global_policy,project_override):
    """Custom controller overlays can only tighten; never claim native precedence."""
    allowed={'max_workers_total','max_writers_per_project','max_solver_jobs','max_parallel_qa','event_mode'}
    require(not set(project_override)-allowed,'project_override_unknown')
    out=dict(global_policy)
    for key,val in project_override.items():
        if key=='event_mode':
            modes=['off','observe','assist','bounded']
            require(val in modes and modes.index(val)<=modes.index(out.get(key,'observe')),'project_override_relaxes')
        else:
            require(type(val) is int and 0<=val<=out[key],'project_override_relaxes')
        out[key]=val
    return out

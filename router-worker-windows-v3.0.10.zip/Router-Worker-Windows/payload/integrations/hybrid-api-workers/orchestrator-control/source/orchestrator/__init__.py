"""Incremental local Router-Worker control plane (custom, not a Codex API)."""
__version__ = '1.0.0'

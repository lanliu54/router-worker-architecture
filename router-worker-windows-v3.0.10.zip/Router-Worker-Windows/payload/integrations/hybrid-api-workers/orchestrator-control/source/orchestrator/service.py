"""Local foreground supervisor and read-only MCP entrypoint; no public listener."""
from __future__ import annotations
from contextlib import contextmanager
from datetime import datetime,timezone
import json
import os
from pathlib import Path
import sys
import threading
import time
import uuid
from .common import ControlError,atomic_json,canonical,digest,require
from .controller import Controller
from .dashboard import render,snapshot
from .events import EventGateway,stable_file_event
from .hooks import EVENTS
from .recall import Recall
from .supervisor import Watchdog

DEFAULTS={'mode':'observe','events_enabled':False,'dispatch_enabled':False,'allowed_projects':[],
          'allowed_sources':['local','worker','solver','timer','hook'], 'watch_paths':[],
          'recall_read_roots':{},'poll_seconds':2,'native_session_control':False,
          'observe_all_bound_projects':False}

def configuration(runtime):
    path=Path(runtime)/'config.json'
    config={**DEFAULTS,**(json.loads(path.read_text(encoding='utf-8')) if path.is_file() else {})}
    require(config['mode'] in ('off','observe','assist','bounded'),'invalid_activation_mode')
    require(type(config['events_enabled']) is bool and type(config['dispatch_enabled']) is bool,'invalid_activation_flags')
    require(type(config['observe_all_bound_projects']) is bool,'invalid_bound_project_observation_flag')
    if config['observe_all_bound_projects']:
        require(config['mode']=='observe' and not config['dispatch_enabled'],'bound_project_observation_requires_observe')
    require(0.1<=config['poll_seconds']<=60,'poll_interval')
    # This release has no native original-chat wakeup endpoint. A JSON flag
    # cannot create one, nor approve paid dispatch from untrusted events.
    require(config['native_session_control'] is False,'native_session_control_unsupported')
    return config

@contextmanager
def service_lock(runtime):
    path=Path(runtime)/'service.lock'
    path.parent.mkdir(parents=True,exist_ok=True)
    handle=path.open('a+b')
    if path.stat().st_size==0:
        handle.write(b'0');handle.flush()
    handle.seek(0)
    try:
        if os.name=='nt':
            import msvcrt
            msvcrt.locking(handle.fileno(),msvcrt.LK_NBLCK,1)
        else:
            import fcntl
            fcntl.flock(handle,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except OSError as exc:
        handle.close()
        raise ControlError('service_already_running') from exc
    try:
        yield
    finally:
        handle.seek(0)
        if os.name=='nt':
            import msvcrt
            msvcrt.locking(handle.fileno(),msvcrt.LK_UNLCK,1)
        else:
            import fcntl
            fcntl.flock(handle,fcntl.LOCK_UN)
        handle.close()

class LocalService:
    def __init__(self,runtime):
        self.runtime=Path(runtime).resolve()
        self.config=configuration(runtime)
        self.c=Controller(runtime,config=self.config)
        self.previous_files={}

    def tick(self):
        self.config=configuration(self.runtime)
        self.c.config.update(self.config)
        g=EventGateway(self.c,allowed_sources=self.config['allowed_sources'],allowed_projects=self.config['allowed_projects'])
        if self.config['events_enabled'] and self.config['mode']!='off':
            self._hook_spool(g)
            self._local_incoming(g)
            self._watch_files(g)
            claim=g.claim('service-'+str(os.getpid()))
            if claim:
                try:
                    g.process(claim)
                except Exception as exc:
                    g.fail(claim,reason=exc.code if isinstance(exc,ControlError) else 'event_processing_failure')
            g.deliver_outbox()
        with self.c.store.read() as db:
            aids=[r[0] for r in db.execute("SELECT attempt_id FROM attempts WHERE status IN ('starting','running','waiting_external','unknown')")]
        watchdog=Watchdog(self.c)
        observations=[watchdog.check(a) for a in aids]
        atomic_json(self.runtime/'watchdog.json',observations)
        render(self.c,self.runtime/'dashboard')
        atomic_json(self.runtime/'service-status.json',{'pid':os.getpid(),'heartbeat':time.time(),'mode':self.config['mode'],
                    'observe_all_bound_projects':self.config['observe_all_bound_projects'],
                    'events_enabled':self.config['events_enabled'],'native_original_session_awakened':False,'model_calls_from_event_loop':0})
        return {'tick':True,'active_attempts':len(aids),'model_calls':0}

    def _envelope(self,source,source_id,project,thread,event_type,payload):
        stamp=datetime.now(timezone.utc).isoformat()
        return {'schema_version':'1.0','provenance':'runtime','event_id':'evt-'+digest([source,source_id])[:40],
                'source':source,'source_event_id':source_id,'project_id':project,'thread_key':thread,
                'event_type':event_type,'occurred_at':stamp,'received_at':stamp,'payload_ref':'inline-local',
                'payload_hash':digest(payload),'trust_level':'untrusted_external','causation_id':None,'correlation_id':thread}

    def _hook_spool(self,g):
        for p in sorted((self.runtime/'hook-spool').glob('*.json'))[:20]:
            try:
                data=json.loads(p.read_text(encoding='utf-8'))
                t=self.c.inspect(data['task_id'])
                gateway=g
                if t['project_id'] not in g.allowed_projects and self.config['observe_all_bound_projects']:
                    identity=data['identity']
                    require(isinstance(identity,dict) and digest(identity)==p.stem and identity.get('session')
                            and identity.get('task_id')==t['task_id'] and identity.get('event') in EVENTS
                            and data['event_type']=='hook.'+identity['event']
                            and data.get('untrusted_payload_retained') is False,'invalid_bound_hook_record')
                    require(any(attempt['contract_version']==identity.get('contract_version')
                                and json.loads(attempt['usage_json']).get('session_id')==identity['session']
                                for attempt in t['attempts']),'hook_session_binding_not_found')
                    # The existing local hook spool is the trust boundary. A
                    # project is derived from the stored task, never the record.
                    gateway=EventGateway(self.c,allowed_sources=g.allowed_sources,allowed_projects=[t['project_id']])
                e=self._envelope('hook',p.stem,t['project_id'],t['task_id'],data['event_type'],data)
                gateway.ingest(e,data,authenticated_source='hook')
                archive=self.runtime/'hook-processed'/p.name
                archive.parent.mkdir(parents=True,exist_ok=True)
                if not archive.exists():
                    p.replace(archive)
                else:
                    require(archive.read_bytes()==p.read_bytes(),'hook_archive_conflict')
                    p.unlink()
            except (ControlError,OSError,ValueError,KeyError):
                # Retain source for manual correction, with no false success ack.
                continue

    def _local_incoming(self,g):
        incoming=self.runtime/'incoming'
        for p in sorted(incoming.glob('*.json'))[:20]:
            try:
                old=self.previous_files.get(str(p))
                stable=stable_file_event(p,old,stable_seconds=.5)
                same=old and all(old.get(k)==stable['observation'][k] for k in ('path','size','mtime_ns','sha256'))
                # Keep the first unchanged observation; frequent polling must
                # not reset the stability clock indefinitely.
                self.previous_files[str(p)]=old if same else stable['observation']
                if not stable['stable']:
                    continue
                data=json.loads(p.read_text(encoding='utf-8'))
                # File producers cannot claim a different trusted origin.
                require(data['envelope']['source']=='local','incoming_source_denied')
                g.ingest(data['envelope'],data['payload'],authenticated_source='local',expires_at=data.get('expires_at'))
                archive=self.runtime/'incoming-processed'/p.name
                archive.parent.mkdir(parents=True,exist_ok=True)
                require(not archive.exists(),'incoming_archive_conflict')
                p.replace(archive)
            except (ControlError,OSError,ValueError,KeyError):
                continue

    def _watch_files(self,g):
        for watch in self.config['watch_paths']:
            # Exact explicitly configured file paths only; no recursive home scan.
            p=Path(watch['path']).resolve()
            if not p.is_file() or p.is_relative_to(self.runtime):
                continue
            old=self.previous_files.get(str(p))
            result=stable_file_event(p,old)
            if old and all(old.get(k)==result['observation'][k] for k in ('size','mtime_ns','sha256')):
                self.previous_files[str(p)]=old
            else:
                self.previous_files[str(p)]=result['observation']
            if result['stable']:
                payload={'path':str(p),'sha256':result['observation']['sha256'],'contract_version':watch['contract_version']}
                e=self._envelope('local','file:'+digest(payload),watch['project_id'],watch['thread_key'],'artifact.stable',payload)
                g.ingest(e,payload,authenticated_source='local',producer_task_id=watch.get('producer_task_id'))

    def serve(self,*,once=False,stop=None):
        stop=stop or threading.Event()
        with service_lock(self.runtime):
            Watchdog(self.c).recover()
            while not stop.is_set():
                if (self.runtime/'stop.request').exists():
                    break
                self.tick()
                if once:
                    break
                stop.wait(self.config['poll_seconds'])
            atomic_json(self.runtime/'service-exit.json',{'pid':os.getpid(),'stopped_at':time.time(),
                        'tasks_rerun':False,'queue_deleted':False,'external_jobs_killed':False})

def readonly_mcp(runtime):
    service=LocalService(runtime)
    # No arbitrary mutation, tool execution, approvals, or dispatch is exposed to
    # inherited worker MCP access. The trusted parent CLI owns those operations.
    definitions=[{'name':'orchestrator_status','description':'Read local custom controller status. Does not execute work.',
                  'inputSchema':{'type':'object','properties':{},'additionalProperties':False}},
                 {'name':'orchestrator_inbox','description':'Read pending local continuation IDs, not raw event instructions.',
                  'inputSchema':{'type':'object','properties':{},'additionalProperties':False}}]
    for line in sys.stdin.buffer:
        request=None
        try:
            require(len(line)<=1024*1024,'mcp_request_size')
            request=json.loads(line)
            if 'id' not in request:
                continue
            method=request.get('method')
            if method=='initialize':
                result={'protocolVersion':request.get('params',{}).get('protocolVersion','2024-11-05'),
                        'capabilities':{'tools':{}},'serverInfo':{'name':'worker_orchestrator','version':'1.0.0'},
                        'instructions':'Read-only custom P0-P3 status interface. Not a dispatch or authorization boundary. Native original-session control is unavailable; pick up inbox manually.'}
            elif method=='tools/list':
                result={'tools':definitions}
            elif method=='tools/call':
                params=request['params']; name=params['name']
                require(name in ('orchestrator_status','orchestrator_inbox') and not params.get('arguments'),'mcp_readonly_tool_required')
                data=snapshot(service.c)
                data=data if name=='orchestrator_status' else {'inbox':data['inbox'],'native_session_awakened':False}
                result={'content':[{'type':'text','text':canonical(data)}],'isError':False}
            elif method=='ping':
                result={}
            else:
                raise ControlError('method_not_supported')
            response={'jsonrpc':'2.0','id':request['id'],'result':result}
        except Exception as exc:
            response={'jsonrpc':'2.0','id':request.get('id') if isinstance(request,dict) else None,
                      'error':{'code':-32602,'message':exc.code if isinstance(exc,ControlError) else 'invalid_request'}}
        sys.stdout.buffer.write((canonical(response)+'\n').encode());sys.stdout.buffer.flush()

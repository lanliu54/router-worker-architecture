from .common import require, safe_id

PARENT_FIELDS=('task_relevant_background','research_or_project_positioning',
    'relevant_user_requirements_with_verbatim_wording_and_provenance','confirmed_decisions',
    'later_corrections_and_superseded_decisions','approved_terminology','constraints_and_immutable_items',
    'current_work_state','known_unknowns_and_conflicts')

def validate_desktop_handoff(value):
    require(all(value.get(k) for k in ('package_id','version','routing_decision','objective','authorized_scope','deliverables','acceptance_criteria','parent_context','ui_ownership')),'desktop_handoff_missing')
    safe_id(value['package_id'])
    require(all(value['parent_context'].get(k) for k in PARENT_FIELDS),'desktop_parent_context_missing')
    route=value['routing_decision']
    require(route.get('owner')=='terra_desktop_native' and route.get('work_kind')=='desktop_operation'
            and route.get('reason') and route.get('bounded_scope'),'desktop_owner_mismatch')

from __future__ import annotations
import argparse
import json
from pathlib import Path
import sys
from .common import ControlError,atomic_json,canonical
from .controller import Controller
from .dashboard import snapshot,render
from .dispatch import Dispatcher
from .qa import SolQA, AstraQA
from .events import EventGateway
from .service import DEFAULTS,LocalService,configuration,readonly_mcp
from .supervisor import Watchdog

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))

def main():
    p=argparse.ArgumentParser(description='Custom local Router-Worker controller; no native Codex command is added.')
    p.add_argument('--runtime',required=True)
    sub=p.add_subparsers(dest='command',required=True)
    for name in ('init','status','pump','recover','stop','mcp'):
        sub.add_parser(name)
    serve=sub.add_parser('serve');serve.add_argument('--once',action='store_true')
    create=sub.add_parser('create');create.add_argument('contract')
    for name in ('inspect','qa-handoff'):
        cmd=sub.add_parser(name);cmd.add_argument('task_id')
    validate=sub.add_parser('validation');validate.add_argument('report');validate.add_argument('--runner',required=True)
    review=sub.add_parser('review');review.add_argument('report');review.add_argument('--session',required=True);review.add_argument('--execution-receipt',required=True);review.add_argument('--contract-version',type=int)
    accept=sub.add_parser('accept');accept.add_argument('task_id');accept.add_argument('--decision-ref',required=True)
    publish=sub.add_parser('publish-local');publish.add_argument('task_id');publish.add_argument('target')
    revise=sub.add_parser('revise');revise.add_argument('task_id');revise.add_argument('contract');revise.add_argument('--decision-ref',required=True)
    backup=sub.add_parser('backup');backup.add_argument('target')
    ingest=sub.add_parser('ingest');ingest.add_argument('event_package')
    subscribe=sub.add_parser('subscribe');subscribe.add_argument('task_id');subscribe.add_argument('thread_key');subscribe.add_argument('event_types',nargs='+')
    collect=sub.add_parser('collect-api');collect.add_argument('attempt_id');collect.add_argument('candidate_path');collect.add_argument('--service-root',required=True)
    claim=sub.add_parser('claim-fallback');claim.add_argument('attempt_id');claim.add_argument('--parent-session',required=True);claim.add_argument('--service-root',required=True)
    for name in ('qa-api-collect','qa-claim-fallback','astra-qa-api-collect','astra-qa-claim-fallback'):
        command=sub.add_parser(name);command.add_argument('record');command.add_argument('--service-root',required=True)
    args=p.parse_args()
    root=Path(args.runtime).resolve()
    try:
        if args.command=='mcp':
            readonly_mcp(root);return
        cfg=configuration(root)
        c=Controller(root,config=cfg)
        g=EventGateway(c,allowed_sources=cfg['allowed_sources'],allowed_projects=cfg['allowed_projects'])
        if args.command=='init':
            if not (root/'config.json').exists():
                atomic_json(root/'config.json',DEFAULTS)
            result={'initialized':True,'mode':'observe','events_enabled':False,'dispatch_enabled':False}
        elif args.command=='status':
            result=snapshot(c)
        elif args.command=='create':result=c.create(read(args.contract))
        elif args.command=='inspect':result=c.inspect(args.task_id)
        elif args.command=='qa-handoff':result=c.qa_handoff(args.task_id)
        elif args.command=='validation':result=c.record_validation(read(args.report),trusted_runner=args.runner)
        elif args.command=='review':result=c.record_review(read(args.report),session_id=args.session,execution_receipt=read(args.execution_receipt),expected_contract_version=args.contract_version)
        elif args.command=='accept':result=c.accept(args.task_id,sol_decision_ref=args.decision_ref)
        elif args.command=='publish-local':result=c.publish_local(args.task_id,args.target)
        elif args.command=='revise':result=c.revise(args.task_id,read(args.contract),decision_ref=args.decision_ref)
        elif args.command=='backup':result={'database_backup':c.store.backup(args.target)}
        elif args.command=='recover':result=Watchdog(c).recover()
        elif args.command=='subscribe':result={'subscription_id':g.subscribe(args.task_id,args.thread_key,args.event_types)}
        elif args.command=='ingest':
            data=read(args.event_package)
            result=g.ingest(data['envelope'],data['payload'],authenticated_source='local',expires_at=data.get('expires_at'))
        elif args.command=='stop':
            atomic_json(root/'stop.request',{'requested':True})
            result={'stop_requested':True,'queue_retained':True,'jobs_killed':False}
        elif args.command in ('serve','pump'):
            LocalService(root).serve(once=args.command=='pump' or args.once)
            result={'service_exited':True,'queue_retained':True}
        elif args.command=='collect-api':
            result=Dispatcher(c,args.service_root).collect_api(args.attempt_id,args.candidate_path)
        elif args.command=='claim-fallback':
            result=Dispatcher(c,args.service_root).claim_content_fallback(args.attempt_id,args.parent_session)
        elif args.command=='qa-api-collect':result=SolQA(c,args.service_root).collect(args.record)
        elif args.command=='qa-claim-fallback':result=SolQA(c,args.service_root).claim_fallback(args.record)
        elif args.command=='astra-qa-api-collect':result=AstraQA(c,args.service_root).collect(args.record)
        elif args.command=='astra-qa-claim-fallback':result=AstraQA(c,args.service_root).claim_fallback(args.record)
        print(canonical(result))
    except ControlError as exc:
        print(canonical({'error':exc.code,'message':str(exc)}));sys.exit(2)

if __name__=='__main__':main()

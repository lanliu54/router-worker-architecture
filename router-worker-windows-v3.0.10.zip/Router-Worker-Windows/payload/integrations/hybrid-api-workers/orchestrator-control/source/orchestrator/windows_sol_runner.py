"""Candidate restricted Windows Python executor; intentionally not deployed.

The caller must provide a dedicated, already-authorized empty candidate root.
Outputs are bounded and a Windows job owns the whole sandbox process tree.
"""
import ctypes
from ctypes import wintypes
import os
from pathlib import Path
import subprocess
import sys
import threading
import time
import base64
import hashlib
import json


class RunnerError(Exception):
    def __init__(self,message,*,execution_unknown=False):
        super().__init__(message)
        self.execution_unknown=execution_unknown


class BasicLimits(ctypes.Structure):
    _fields_=[('PerProcessUserTimeLimit',ctypes.c_int64),('PerJobUserTimeLimit',ctypes.c_int64),
              ('LimitFlags',wintypes.DWORD),('MinimumWorkingSetSize',ctypes.c_size_t),
              ('MaximumWorkingSetSize',ctypes.c_size_t),('ActiveProcessLimit',wintypes.DWORD),
              ('Affinity',ctypes.c_size_t),('PriorityClass',wintypes.DWORD),('SchedulingClass',wintypes.DWORD)]


class IOCounts(ctypes.Structure):
    _fields_=[(name,ctypes.c_uint64) for name in ('ReadOperationCount','WriteOperationCount','OtherOperationCount',
                                                    'ReadTransferCount','WriteTransferCount','OtherTransferCount')]


class ExtendedLimits(ctypes.Structure):
    _fields_=[('BasicLimitInformation',BasicLimits),('IoInfo',IOCounts),('ProcessMemoryLimit',ctypes.c_size_t),
              ('JobMemoryLimit',ctypes.c_size_t),('PeakProcessMemoryUsed',ctypes.c_size_t),('PeakJobMemoryUsed',ctypes.c_size_t)]


class WindowsSolRunner:
    def __init__(self, workspace, *, codex_executable, python_executable, timeout=30, max_output=8192):
        if os.name!='nt':raise RunnerError('Windows restricted-token executor is unavailable')
        raw=Path(workspace)
        if not raw.is_absolute() or raw.is_symlink() or not raw.is_dir():raise RunnerError('An absolute real candidate workspace is required')
        self.workspace=raw.resolve(strict=True)
        self.codex=Path(codex_executable).resolve(strict=True)
        self.python=Path(python_executable).resolve(strict=True)
        if not 1<=timeout<=60 or not 1<=max_output<=131072:raise RunnerError('Invalid bounded execution limits')
        self.timeout=timeout;self.max_output=max_output

    def run_python(self, code):
        if not isinstance(code,str) or not 0<len(code.encode('utf-8'))<=32768:raise RunnerError('Invalid Python input')
        kernel=ctypes.WinDLL('kernel32',use_last_error=True)
        kernel.CreateJobObjectW.argtypes=[ctypes.c_void_p,wintypes.LPCWSTR];kernel.CreateJobObjectW.restype=wintypes.HANDLE
        kernel.SetInformationJobObject.argtypes=[wintypes.HANDLE,ctypes.c_int,ctypes.c_void_p,wintypes.DWORD];kernel.SetInformationJobObject.restype=wintypes.BOOL
        kernel.AssignProcessToJobObject.argtypes=[wintypes.HANDLE,wintypes.HANDLE];kernel.AssignProcessToJobObject.restype=wintypes.BOOL
        kernel.TerminateJobObject.argtypes=[wintypes.HANDLE,wintypes.UINT];kernel.TerminateJobObject.restype=wintypes.BOOL
        kernel.CloseHandle.argtypes=[wintypes.HANDLE];kernel.CloseHandle.restype=wintypes.BOOL
        job=kernel.CreateJobObjectW(None,None)
        if not job:raise RunnerError('Could not create job object')
        process=None;buffer=bytearray();overflow=threading.Event();start=time.monotonic()
        try:
            limits=ExtendedLimits();limits.BasicLimitInformation.LimitFlags=0x2000 | 0x8
            limits.BasicLimitInformation.ActiveProcessLimit=8
            if not kernel.SetInformationJobObject(job,9,ctypes.byref(limits),ctypes.sizeof(limits)):
                raise RunnerError('Could not constrain job object')
            allowed=('SYSTEMROOT','WINDIR','COMSPEC','PATH','PATHEXT','TEMP','TMP','USERPROFILE','LOCALAPPDATA','APPDATA')
            env={k:v for k,v in os.environ.items() if k.upper() in allowed}
            env['PYTHONIOENCODING']='utf-8';env['PYTHONDONTWRITEBYTECODE']='1'
            program="import sys; exec(compile(sys.stdin.read(), '<sol-candidate>', 'exec'))"
            command=[str(self.codex),'sandbox','--permission-profile',':workspace','-C',str(self.workspace),
                     '--',str(self.python),'-I','-c',program]
            process=subprocess.Popen(command,cwd=self.workspace,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,
                                     stderr=subprocess.STDOUT,creationflags=0x4 | 0x08000000)
            if not kernel.AssignProcessToJobObject(job,wintypes.HANDLE(process._handle)):
                process.kill();raise RunnerError('Could not assign suspended process to job')
            ntdll=ctypes.WinDLL('ntdll');ntdll.NtResumeProcess.argtypes=[wintypes.HANDLE];ntdll.NtResumeProcess.restype=ctypes.c_long
            if ntdll.NtResumeProcess(wintypes.HANDLE(process._handle))!=0:
                kernel.TerminateJobObject(job,1);raise RunnerError('Could not resume sandbox process')
            def read_output():
                while True:
                    data=process.stdout.read(2048)
                    if not data:break
                    remaining=self.max_output-len(buffer)
                    buffer.extend(data[:max(0,remaining)])
                    if len(data)>remaining:
                        overflow.set();kernel.TerminateJobObject(job,1);break
            reader=threading.Thread(target=read_output,daemon=True);reader.start()
            def send_input():
                try:process.stdin.write(code.encode('utf-8'));process.stdin.close()
                except (OSError,ValueError):pass
            writer=threading.Thread(target=send_input,daemon=True);writer.start()
            timed_out=False
            try:process.wait(timeout=self.timeout)
            except subprocess.TimeoutExpired:
                timed_out=True
                if not kernel.TerminateJobObject(job,1):raise RunnerError('Timed-out process tree termination is unconfirmed',execution_unknown=True)
                process.wait(timeout=5)
            # Kill descendants even if the original process has exited.
            if not kernel.TerminateJobObject(job,0):raise RunnerError('Process tree cleanup is unconfirmed',execution_unknown=True)
            reader.join(5);writer.join(5)
            if reader.is_alive() or writer.is_alive():raise RunnerError('Process stream cleanup is unconfirmed',execution_unknown=True)
            process.stdout.close()
            return {'exit_code':process.returncode,'timed_out':timed_out,'output_truncated':overflow.is_set(),
                    'output':bytes(buffer).decode('utf-8',errors='replace'),'elapsed_seconds':round(time.monotonic()-start,3),
                    'sandbox':'codex :workspace; local boundary checks required'}
        finally:
            if process and process.poll() is None:
                kernel.TerminateJobObject(job,1)
                try:process.wait(timeout=5)
                except subprocess.TimeoutExpired:pass
            kernel.CloseHandle(job)

    def collect_file(self, relative_path, destination):
        """Copy one explicit small artifact via a fresh sandbox, never auto-apply it."""
        relative=Path(relative_path)
        if (not relative_path or relative.is_absolute() or '..' in relative.parts or
            any(part in ('','.','..') for part in relative.parts)):
            raise RunnerError('Artifact must be an explicit workspace-relative path')
        dest=Path(destination)
        if not dest.is_absolute() or dest.exists() or dest.is_symlink() or not dest.parent.is_dir():
            raise RunnerError('Artifact destination must be a new absolute file in an existing parent')
        source=repr(relative.as_posix())
        code=("import base64,hashlib,json,os\nfrom pathlib import Path\n"
              "root=Path.cwd().resolve(); p=Path("+source+")\n"
              "if any((root / Path(*p.parts[:i])).is_symlink() for i in range(1,len(p.parts)+1)): raise ValueError('linked artifact')\n"
              "q=(root/p).resolve(strict=True)\n"
              "if not q.is_relative_to(root) or not q.is_file() or q.stat().st_size>65536: raise ValueError('invalid artifact')\n"
              "data=q.read_bytes(); print(json.dumps({'bytes':base64.b64encode(data).decode('ascii'),'sha256':hashlib.sha256(data).hexdigest(),'size':len(data)}))\n")
        previous=self.max_output
        try:
            self.max_output=131072
            receipt=self.run_python(code)
        finally:self.max_output=previous
        if receipt['exit_code']!=0 or receipt['timed_out'] or receipt['output_truncated']:
            raise RunnerError('Artifact collection failed in restricted workspace')
        try:
            result=json.loads(receipt['output']);raw=base64.b64decode(result['bytes'],validate=True)
            if len(raw)!=result['size'] or len(raw)>65536 or hashlib.sha256(raw).hexdigest()!=result['sha256']:
                raise ValueError('artifact integrity mismatch')
        except (ValueError,KeyError,TypeError) as error:
            raise RunnerError('Artifact collection output failed integrity validation') from error
        with dest.open('xb') as handle:handle.write(raw)
        return {'path':str(dest),'size':len(raw),'sha256':result['sha256'],'source':relative.as_posix(),
                'execution_receipt':receipt['sandbox'],'applied':False}

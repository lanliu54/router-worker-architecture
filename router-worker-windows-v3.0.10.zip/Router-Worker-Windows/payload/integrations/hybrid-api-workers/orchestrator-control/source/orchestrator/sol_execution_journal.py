"""Use the existing worker task ledger for a single Sol execution attempt."""
import hashlib
import json
from copy import deepcopy


class JournalError(Exception):
    pass


class EngineJournal:
    def __init__(self, engine, *, config=None):
        self.engine=engine
        self.config=deepcopy(config)

    def change(self, task_id, operation):
        with self.engine.transaction() as db:
            task=self.engine.load(db,task_id)
            operation(task)
            self.engine.save(db,task)

    def begin(self, task_id, cap):
        def apply(t):
            if t.get('role')!='api_sol_execution' or t.get('status')!='api_running' or 'execution_loop' in t:
                raise JournalError('execution task is not a unique active Sol attempt')
            if t.get('api_charge_uncertain') or type(cap) is not int or cap <= 0:
                raise JournalError('invalid or uncertain execution budget')
            t['execution_loop']={'phase':'ready','cap_micro_usd':cap,'spent_micro_usd':0,'rounds':[],'tools':[]}
        self.change(task_id,apply)

    def reserve_request(self,task_id,number,reserve,spent):
        with self.engine.transaction() as db:
            t=self.engine.load(db,task_id)
            x=t['execution_loop']
            if t.get('cancellation_requested'):raise JournalError('cancellation_requested')
            if (t['status']!='api_running' or x['phase']!='ready' or number!=len(x['rounds'])+1 or
                spent!=x['spent_micro_usd'] or type(reserve) is not int or reserve<=0 or spent+reserve>x['cap_micro_usd']):
                raise JournalError('request reservation conflicts with task state or cap')
            if self.config is not None:
                self.engine.require_not_maintenance()
                if self.engine.current_config()!=self.config or self.engine.readiness(self.config):
                    raise JournalError('execution settings changed or request is no longer authorized')
                if self.config.get('budget_mode','cumulative_and_per_task')!='per_task_only':
                    tasks=[json.loads(row[0]) for row in db.execute('SELECT data FROM tasks')]
                    if any(row['status']=='unknown_execution' or row.get('api_charge_uncertain') for row in tasks):
                        raise JournalError('cumulative budget paused for uncertain charge')
                    total=sum((row.get('charged_micro_usd',0) if
                               row.get('budget_cycle_start')==self.config['cycle_start'] or
                               'budget_cycle_start' not in row and row.get('created_at',0)>=self.config['cycle_start'] else 0)
                              +row.get('closed_attempt_charges',{}).get(str(self.config['cycle_start']),0)
                              +row.get('interaction_unsettled_micro_usd',0)
                              +(row.get('reserved_micro_usd',0) if row['id']!=task_id else 0)
                              for row in tasks)
                    if total+reserve>self.config['cycle_budget_micro_usd']:
                        raise JournalError('cumulative budget would be exceeded by this round')
            attempt=t.get('api_attempt',1)
            attempt_suffix='' if attempt==1 else f'-a{attempt}'
            x['rounds'].append({'number':number,'state':'dispatching','reserve_micro_usd':reserve,
                                'client_request_id':f'hybrid-{task_id}{attempt_suffix}-r{number}'})
            x['phase']='request_dispatching';t['reserved_micro_usd']=reserve
            self.engine.save(db,t)

    def complete_request(self,task_id,number,response_id,request_id,usage,cost):
        def apply(t):
            x=t['execution_loop'];r=x['rounds'][-1]
            if x['phase']!='request_dispatching' or r['number']!=number or not response_id or cost<0 or cost>r['reserve_micro_usd']:
                raise JournalError('request result conflicts with active reservation')
            r.update(state='completed',response_id=response_id,provider_request_id=request_id,usage=usage,charged_micro_usd=cost)
            x['spent_micro_usd']+=cost;x['phase']='ready';t['charged_micro_usd']=x['spent_micro_usd'];t['reserved_micro_usd']=0
        self.change(task_id,apply)

    def unknown_request(self,task_id,number):
        def apply(t):
            x=t['execution_loop'];r=x['rounds'][-1]
            if r['number']!=number or r['state']!='dispatching':raise JournalError('request not pending')
            r['state']='unknown';x['phase']='unknown_request';t['status']='unknown_execution';t['api_charge_uncertain']=True
        self.change(task_id,apply)

    def begin_tool(self,task_id,number,call_id,args):
        def apply(t):
            x=t['execution_loop']
            if t.get('cancellation_requested'):raise JournalError('cancellation_requested')
            if t['status']!='api_running':raise JournalError('execution owner is not active')
            if x['phase']!='ready' or any(v['call_id']==call_id for v in x['tools']):raise JournalError('tool call already exists or task is not ready')
            encoded=json.dumps(args,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8')
            x['tools'].append({'round':number,'call_id':call_id,'input_sha256':hashlib.sha256(encoded).hexdigest(),'state':'running'})
            x['phase']='tool_running'
        self.change(task_id,apply)

    def begin_collection(self,task_id,index,source):
        def apply(t):
            if t.get('cancellation_requested'):raise JournalError('cancellation_requested')
            x=t['execution_loop']
            if t['status']!='api_running' or x['phase'] not in ('awaiting_result_validation','artifact_collection_complete'):
                raise JournalError('artifact collection is not authorized')
            x.update(phase='artifact_collecting',collection_index=index,collection_source=source)
        self.change(task_id,apply)

    def reject_request(self,task_id,number,code,request_id,allow_fallback):
        def apply(t):
            x=t['execution_loop'];r=x['rounds'][-1]
            if x['phase']!='request_dispatching' or r['number']!=number or r['state']!='dispatching':
                raise JournalError('rejected request is not pending')
            r.update(state='confirmed_rejected',rejection_code=code,provider_request_id=request_id)
            x['phase']='provider_rejected';t['reserved_micro_usd']=0;t['api_charge_uncertain']=False
            if t.get('cancellation_requested'):
                t.update(status='cancelled',reason='cancelled_after_confirmed_rejection')
            elif allow_fallback and len(x['rounds'])==1 and not x['tools'] and x['spent_micro_usd']==0:
                t.update(status='fallback_ready',reason=code)
            else:t.update(status='blocked',reason='later_round_provider_rejection_no_replay')
        self.change(task_id,apply)

    def complete_tool(self,task_id,number,call_id,result):
        def apply(t):
            x=t['execution_loop'];v=x['tools'][-1]
            if x['phase']!='tool_running' or v['call_id']!=call_id or v['round']!=number:raise JournalError('tool call is not active')
            v.update(state='completed',receipt=result);x['phase']='ready'
        self.change(task_id,apply)

    def unknown_tool(self,task_id,number,call_id):
        def apply(t):
            x=t['execution_loop'];v=x['tools'][-1]
            if v['call_id']!=call_id or v['round']!=number or v['state']!='running':raise JournalError('tool call is not active')
            v['state']='unknown';x['phase']='unknown_tool';t['status']='unknown_execution';t['reason']='tool_execution_unreconciled'
        self.change(task_id,apply)

    def stop(self,task_id,reason):
        def apply(t):
            x=t['execution_loop']
            if x['phase']!='ready':raise JournalError('cannot stop an uncertain in-flight call')
            # Ready proves no request or tool is in flight. This also clears the
            # outer preflight reservation when the complete first round cannot start.
            x.update(phase='stopped',reason=reason);t['status']='blocked';t['reason']=reason
            t['reserved_micro_usd']=0
        self.change(task_id,apply)

    def finish(self,task_id,spent):
        def apply(t):
            x=t['execution_loop']
            if x['phase']!='ready' or x['spent_micro_usd']!=spent:raise JournalError('completion accounting mismatch')
            x['phase']='awaiting_result_validation'
        self.change(task_id,apply)

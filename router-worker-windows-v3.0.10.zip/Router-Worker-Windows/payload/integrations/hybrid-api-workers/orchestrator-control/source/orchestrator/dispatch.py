"""Trusted worker dispatch and collection through the owning service ledger."""
from __future__ import annotations
import json
import os
import shutil
import tempfile
from pathlib import Path
import time
from .adapters import APIWorkerAdapter
from .common import ControlError,atomic_json,canonical,digest,file_hash,require,write_bytes_exclusive
from .policy import api_cap,API_ROLE,permission

class Dispatcher:
    def __init__(self,controller,service_root):
        self.c=controller
        self.api=APIWorkerAdapter(service_root,controller)

    @staticmethod
    def copy_candidate(source,target,expected_hash):
        """Publish only a complete verified file, without replacing a target."""
        temporary=None
        try:
            with tempfile.NamedTemporaryFile(prefix='.collect-',dir=target.parent,delete=False) as dst:
                temporary=Path(dst.name)
                with source.open('rb') as src:shutil.copyfileobj(src,dst)
                dst.flush();os.fsync(dst.fileno())
            require(file_hash(temporary)==expected_hash and file_hash(source)==expected_hash,'candidate_artifact_changed_during_copy')
            try:os.link(temporary,target)
            except FileExistsError:
                require(target.is_file() and not target.is_symlink() and file_hash(target)==expected_hash,'collection_candidate_conflict')
        finally:
            if temporary is not None:temporary.unlink(missing_ok=True)


    def collect_api(self,attempt_id,candidate_path):
        with self.c.store.read() as db:
            row=db.execute('SELECT * FROM attempts WHERE attempt_id=?',(attempt_id,)).fetchone()
            require(row and row['channel'] in ('api_worker','subscription_codex'),'api_attempt_not_found')
            row=dict(row)
        t=self.c.inspect(row['task_id'])
        require(row['contract_version']==t['contract_version'],'stale_contract')
        observed=self.api.inspect(row)
        provider=observed['provider']
        if observed['status']!='completed':
            return {'status':observed['status'],'provider_status':provider['status'],'rerun':False}
        native=provider.get('native_evidence',{}) if provider.get('route')=='subscription' else None
        actual_model=native.get('actual_model') if native is not None else provider.get('actual_model')
        actual_effort=native.get('actual_reasoning_effort') if native is not None else provider.get('returned_reasoning_effort')
        require(actual_model==row['model_requested'] and actual_effort in (None,row['effort_requested']), 'actual_identity_mismatch')
        workspace = None
        if row['role']=='executor_sol' and native is not None:
            package=self.api.engine().read_package(provider)
            if package['task']['execution_contract']['mode']=='workspace_implementation':
                from worker_core import verify_workspace_artifacts
                artifacts=provider.get('workspace_artifacts')
                verify_workspace_artifacts(provider,package,artifacts)
                workspace=Path(package['task']['execution_workspace'])
                require(Path(candidate_path).resolve()==workspace,'workspace_collection_mismatch')
        p=workspace if workspace is not None else permission(t['contract'],candidate_path,'write',[self.c.root,Path(__file__).parent])
        result=provider.get('result')
        require(isinstance(result,dict) and result.get('status')=='completed','worker_result_incomplete')
        collection_path=self.c.root/'dispatch'/f'{attempt_id}-collection.json'
        binding={'attempt_id':attempt_id,'contract_version':t['contract_version'],'contract_hash':t['contract_hash'],
                 'provider_task_id':provider['id'],'package_hash':provider['package_hash'],'candidate_path':str(p),
                 'result_hash':digest(result),'candidate_artifacts_hash':digest(provider.get('candidate_artifacts',[]))}
        if workspace is not None:
            binding['workspace_artifacts_hash'] = digest(artifacts)
        if collection_path.exists():
            collection=json.loads(collection_path.read_text(encoding='utf-8'))
            require(collection.get('binding')==binding,'collection_binding_changed')
        else:
            require(workspace is not None or not p.exists(),'candidate_exists')
            collection={'binding':binding,'phase':'prepared'}
            atomic_json(collection_path,collection)
        outputs=[]
        if workspace is not None:
            for artifact in artifacts:
                output=permission(t['contract'],artifact['path'],'write',[self.c.root,Path(__file__).parent])
                require(output.is_relative_to(workspace),'workspace_artifact_outside_scope')
                outputs.append({'path':str(output),'sha256':artifact['sha256']})
        elif row['role']=='executor_sol':
            package=self.api.engine().read_package(provider)
            expected=package['task']['execution_sandbox']['artifact_paths']
            candidates=provider.get('candidate_artifacts')
            require(isinstance(candidates,list) and [x.get('source') for x in candidates]==expected,'candidate_artifact_manifest_mismatch')
            attempt=provider.get('api_attempt',1) if native is None else 1
            artifact_folder='candidate-artifacts' if attempt==1 else f'candidate-artifacts-a{attempt}'
            package_root=Path(provider['package_path']).resolve().parent/artifact_folder
            prepared=[]
            for candidate in candidates:
                rel=Path(candidate['source']);source=Path(candidate['path'])
                require(not rel.is_absolute() and '..' not in rel.parts and source.is_file() and not source.is_symlink(), 'candidate_artifact_invalid')
                require(source.resolve().is_relative_to(package_root.resolve()) and file_hash(source)==candidate['sha256'], 'candidate_artifact_integrity')
                target=(p/rel).resolve()
                require(target.is_relative_to(p.resolve()),'candidate_artifact_invalid')
                permission(t['contract'],target,'write',[self.c.root,Path(__file__).parent])
                prepared.append((source,target,candidate['sha256']))
            p.mkdir(parents=True,exist_ok=True)
            for source,target,expected_hash in prepared:
                target.parent.mkdir(parents=True,exist_ok=True)
                if target.exists():
                    require(not target.is_symlink() and target.is_file() and file_hash(target)==expected_hash,'collection_candidate_conflict')
                else:
                    self.copy_candidate(source,target,expected_hash)
                require(file_hash(target)==expected_hash and file_hash(source)==expected_hash,'candidate_artifact_changed_during_copy')
                outputs.append({'path':str(target),'sha256':expected_hash})
        else:
            expected_hash=digest((canonical(result)+os.linesep).encode('utf-8'))
            if p.exists():
                require(not p.is_symlink() and p.is_file() and file_hash(p)==expected_hash,'collection_candidate_conflict')
            else:write_bytes_exclusive(p,(canonical(result)+os.linesep).encode('utf-8'))
            require(file_hash(p)==expected_hash,'collection_candidate_conflict')
            outputs=[{'path':str(p),'sha256':expected_hash}]
        collection.update(phase='candidate_verified',artifacts=outputs);atomic_json(collection_path,collection)
        receipt_path=self.c.root/'dispatch'/f'{attempt_id}-provider-receipt.json'
        atomic_json(receipt_path,{'task_id':provider['id'],'response_id':provider.get('response_id'),
                                  'request_id_provider':provider.get('request_id_provider'),'actual_model':actual_model,
                                  'requested_effort':provider.get('requested_reasoning_effort'),
                                  'returned_effort':actual_effort,'native_evidence':native,
                                  'api_usage':provider.get('api_usage'),'subscription_usage':provider.get('subscription_usage','unknown'),
                                  'package_hash':provider['package_hash'],'execution_loop':provider.get('execution_loop')})
        session=('native:'+native['native_thread_id']) if native else 'api:'+str(provider.get('response_id') or provider['id'])
        with self.c.store.transaction() as db:
            current=db.execute('SELECT usage_json FROM attempts WHERE attempt_id=?',(attempt_id,)).fetchone()
            data=json.loads(current[0]); data['session_id']=session
            db.execute('UPDATE attempts SET model_reported=?,effort_reported=?,identity_evidence_level=?,usage_json=?,channel=? WHERE attempt_id=?',
                       (actual_model,actual_effort,'parent_observed_native_metadata' if native else 'provider_response_metadata',canonical(data),
                        'subscription_codex' if native else 'api_worker',attempt_id))
        current=self.c.inspect(row['task_id'])
        if (current['meta'].get('author') or {}).get('attempt_id')==attempt_id:
            require(self.c._snapshot_valid(current),'collection_snapshot_changed')
            require([(x['source'],x['sha256']) for x in current['meta']['snapshot']['manifest']]==
                    [(x['path'],x['sha256']) for x in outputs],'collection_snapshot_mismatch')
            submitted={'state':current['state'],'artifact_hash':current['meta']['snapshot']['hash'],'attempt_id':attempt_id}
        else:
            direct_scope = {'in_place_workspace': workspace} if workspace is not None else {}
            submitted=self.c.submit_result({'schema_version':'1.0','provenance':'runtime','task_id':row['task_id'],
                'attempt_id':attempt_id,'contract_version':row['contract_version'],'role':row['role'],'status':'submitted',
                'summary':'Verified in-place output; parent validation remains required' if workspace is not None else 'Collected existing API output; parent validation remains required',
                'artifacts':outputs,'evidence_refs':[str(receipt_path)],'unresolved':[]},
                session_id=session,fences=data['fences'],**direct_scope)
        collection.update(phase='submitted');atomic_json(collection_path,collection)
        self.c.settle_budget(attempt_id,actual_micro_usd=provider.get('charged_micro_usd'),
                             usage=provider.get('api_usage'),evidence_ref=str(receipt_path))
        collection.update(phase='settled');atomic_json(collection_path,collection)
        return submitted

    def claim_content_fallback(self,attempt_id,parent_session_id):
        with self.c.store.read() as db:
            row=db.execute('SELECT * FROM attempts WHERE attempt_id=?',(attempt_id,)).fetchone()
            require(row and row['channel'] in ('api_worker','subscription_codex') and row['provider_request_id'],
                    'worker_attempt_not_found')
            t=self.c.store.task(row['task_id'],db)
            require(self.c._resource_available(db,t),'total_task_budget_exhausted')
        claimed=self.api.claim_fallback(row['provider_request_id'],parent_session_id)
        # Return exact service spawn_message. Parent uses the named subscription
        # role with independent context; this service never imitates native UI.
        path=self.c.root/'dispatch'/f'{attempt_id}-fallback-claim.json'
        atomic_json(path,claimed)
        return claimed

    def complete_content_fallback(self,attempt_id,claim_token,*,native_evidence,result):
        with self.c.store.read() as db:
            row=db.execute('SELECT * FROM attempts WHERE attempt_id=?',(attempt_id,)).fetchone()
            require(row is not None and row['provider_request_id'],'worker_attempt_not_found')
        # Owning service enforces claim/package/original parity and exact runtime
        # target. Parent must independently observe native metadata before calling.
        return self.api.engine().complete_subscription_fallback(row['provider_request_id'],claim_token,native_evidence,result)

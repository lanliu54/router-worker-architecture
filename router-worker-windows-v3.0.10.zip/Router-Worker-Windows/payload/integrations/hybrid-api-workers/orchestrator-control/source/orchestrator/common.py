from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import shutil
import time
from datetime import datetime

class ControlError(Exception):
    def __init__(self, code, detail=''):
        self.code = code
        super().__init__(detail or code)

def require(condition, code, detail=''):
    if not condition:
        raise ControlError(code, detail)

def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':'), allow_nan=False)

def digest(value):
    return hashlib.sha256(value if isinstance(value, bytes) else canonical(value).encode()).hexdigest()

def file_hash(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def artifact_manifest_hash(manifest):
    # Snapshot identity follows ordered content, not its local storage directory.
    # This keeps audit references stable across a verified disaster restore.
    return digest([{'ordinal':i,'sha256':item['sha256'],'size_bytes':item['size_bytes']} for i,item in enumerate(manifest)])

def atomic_json(path, value):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_name(p.name + '.writing-' + secrets.token_hex(6))
    try:
        with tmp.open('x', encoding='utf-8') as f:
            f.write(canonical(value) + '\n')
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, p)
    finally:
        tmp.unlink(missing_ok=True)


def publish_verified_temp(temp,target,expected_hash):
    require(file_hash(temp)==expected_hash,'exclusive_source_changed')
    try:os.link(temp,target)
    except FileExistsError:
        require(target.is_file() and not target.is_symlink() and file_hash(target)==expected_hash,'exclusive_target_conflict')
    require(file_hash(target)==expected_hash,'exclusive_target_changed')


def write_bytes_exclusive(path,data):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_name(path.name+'.writing-'+secrets.token_hex(6))
    try:
        with temp.open('xb') as handle:
            handle.write(data);handle.flush();os.fsync(handle.fileno())
        publish_verified_temp(temp,path,digest(data))
    finally:temp.unlink(missing_ok=True)


def copy_verified_exclusive(source,target,expected_hash):
    source,target=Path(source),Path(target);target.parent.mkdir(parents=True,exist_ok=True)
    temp=target.with_name(target.name+'.writing-'+secrets.token_hex(6))
    try:
        with source.open('rb') as src,temp.open('xb') as dst:
            shutil.copyfileobj(src,dst);dst.flush();os.fsync(dst.fileno())
        require(file_hash(source)==expected_hash,'exclusive_source_changed')
        publish_verified_temp(temp,target,expected_hash)
    finally:temp.unlink(missing_ok=True)

def safe_id(value):
    require(isinstance(value, str) and re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,119}', value)
            and value not in ('.','..'), 'invalid_identifier')
    return value

def within(path, roots):
    p = Path(path).resolve()
    return any(p.is_relative_to(Path(root).resolve()) for root in roots)

def clean_environment(source=None):
    # Allowlisting avoids arbitrary aliases such as BUILD_CREDENTIAL leaking to tests.
    source = os.environ if source is None else source
    allowed = {'PATH','PATHEXT','SYSTEMROOT','WINDIR','COMSPEC','TEMP','TMP','TMPDIR',
               'LANG','LC_ALL','PYTHONUTF8','NUMBER_OF_PROCESSORS'}
    env = {k:v for k,v in source.items() if k.upper() in allowed}
    env['PYTHONUTF8'] = '1'
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    return env

def validate_schema(value, schema, location='$'):
    """Fail-closed evaluator for the subset used by the bundled contracts.

    Unsupported keywords fail at load time rather than being silently ignored.
    This is deliberately not a general JSON Schema implementation.
    """
    supported = {'$schema','title','description','type','const','enum','properties','required',
                 'additionalProperties','items','minItems','minimum','minLength','pattern','format'}
    require(not set(schema) - supported, 'schema_keyword_unsupported')
    types = {'object': dict, 'array': list, 'string': str, 'integer': int,
             'number': (int,float), 'boolean': bool, 'null': type(None)}
    if 'type' in schema:
        expected = schema['type'] if isinstance(schema['type'],list) else [schema['type']]
        require(all(t in types for t in expected), 'schema_type_unsupported')
        require(any(isinstance(value, types[t]) and not (isinstance(value,bool) and t in ('integer','number')) for t in expected), 'schema_type', location)
    if 'const' in schema:
        require(value == schema['const'], 'schema_const', location)
    if 'enum' in schema:
        require(value in schema['enum'], 'schema_enum', location)
    if isinstance(value, dict):
        require(all(k in value for k in schema.get('required',[])), 'schema_required', location)
        props = schema.get('properties',{})
        if schema.get('additionalProperties') is False:
            require(not set(value)-set(props), 'schema_additional', location)
        for k,v in value.items():
            if k in props:
                validate_schema(v, props[k], location+'.'+k)
    if isinstance(value,list):
        require(len(value)>=schema.get('minItems',0), 'schema_min_items', location)
        for i,item in enumerate(value):
            if 'items' in schema:
                validate_schema(item,schema['items'],f'{location}[{i}]')
    if isinstance(value,str):
        require(len(value)>=schema.get('minLength',0), 'schema_min_length', location)
        if 'pattern' in schema:
            require(re.search(schema['pattern'],value) is not None,'schema_pattern',location)
        if 'format' in schema:
            require(schema['format']=='date-time','schema_format_unsupported')
            try:
                parsed=datetime.fromisoformat(value.replace('Z','+00:00'))
                require(parsed.tzinfo is not None,'schema_datetime_timezone',location)
            except ValueError as exc:
                raise ControlError('schema_datetime',location) from exc
    if isinstance(value,(int,float)) and not isinstance(value,bool) and 'minimum' in schema:
        require(value>=schema['minimum'],'schema_minimum',location)

def now():
    return time.time()

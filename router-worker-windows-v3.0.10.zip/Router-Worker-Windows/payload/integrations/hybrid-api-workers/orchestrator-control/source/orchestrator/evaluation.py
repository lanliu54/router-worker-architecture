"""A/B/C evaluation recording. Missing domain runs stay NOT_RUN, never fabricated."""
from __future__ import annotations
import csv
import json
from pathlib import Path
import random
from .common import atomic_json,canonical,require
from .common import file_hash,digest,safe_id
import shutil

CATEGORIES=('file_organization','writing','formula_data','local_code','research_plan','visual_desktop')
METRICS=('satisfied','true_positive','false_positive','false_negative','clean_false_alarm','severe_miss',
         'rework_rounds','human_review_seconds','elapsed_seconds','api_micro_usd','subscription_usage','route_compliant','invalid_escalation')

def schedule(cases,*,seed):
    require(len(cases)==30 and len({x['case_id'] for x in cases})==30,'evaluation_requires_30_distinct_cases')
    for category in CATEGORIES:
        require(sum(x['category']==category for x in cases)==5,'evaluation_category_count')
    jobs=[{'case_id':case['case_id'],'variant':variant,'input_hash':case.get('input_hash'),
           'criteria_hash':case.get('criteria_hash'),'model_effort':case.get('model_effort'),
           'status':'NOT_RUN','metrics':None,'evidence':None} for case in cases for variant in ('A','B','C')]
    random.Random(seed).shuffle(jobs)
    return {'seed':seed,'sample_size':30,'planned_runs':90,'jobs':jobs}

def summarize(run):
    output={'sample_size':run['sample_size'],'seed':run['seed'],'variants':{},'improvement_claim':'not_established'}
    for variant in ('A','B','C'):
        rows=[j for j in run['jobs'] if j['variant']==variant]
        done=[r for r in rows if r['status']=='COMPLETED']
        for row in done:
            require(row.get('evidence') and Path(row['evidence']).is_file() and row.get('metrics') is not None,'evaluation_evidence_missing')
        output['variants'][variant]={'completed':len(done),'not_run':sum(r['status']=='NOT_RUN' for r in rows),
                                    'failed':sum(r['status']=='FAILED' for r in rows)}
        if done:
            output['variants'][variant]['task_satisfaction_rate']=sum(bool(r['metrics'].get('satisfied')) for r in done)/len(done)
            for metric in ('elapsed_seconds','api_micro_usd','rework_rounds','human_review_seconds','severe_miss'):
                vals=[r['metrics'].get(metric) for r in done]
                output['variants'][variant][metric]=sum(vals) if all(type(v) in (int,float) for v in vals) else None
            tp=sum(r['metrics'].get('true_positive',0) for r in done)
            fp=sum(r['metrics'].get('false_positive',0) for r in done)
            fn=sum(r['metrics'].get('false_negative',0) for r in done)
            output['variants'][variant]['precision']=tp/(tp+fp) if tp+fp else None
            output['variants'][variant]['recall']=tp/(tp+fn) if tp+fn else None
    return output

def initialize_evaluation(destination):
    destination=Path(destination);destination.mkdir(parents=True,exist_ok=True)
    paths=[destination/'cases.json',destination/'raw-results.json',destination/'comparison.json']
    if any(p.exists() for p in paths):
        require(all(p.exists() for p in paths),'evaluation_partial_state_requires_reconciliation')
        cases=json.loads(paths[0].read_text(encoding='utf-8'))
        run=json.loads(paths[1].read_text(encoding='utf-8'))
        # A report refresh must never overwrite enrolled cases or executed runs.
        return {'status':'PRESERVED_EXISTING','cases_enrolled':sum(x.get('material_status')=='ENROLLED' for x in cases),
                'planned_cases':len(cases),'planned_runs':len(run['jobs'])}
    # These are honest enrollment slots. Real/deidentified input, hidden trusted
    # labels and authorized model/tool runs are mandatory before a slot can run.
    cases=[{'case_id':f'{category}-{i}','category':category,'input_hash':None,'criteria_hash':None,
            'model_effort':None,'material_status':'NOT_ENROLLED','trusted_label_ref':None,
            'blocker':'Requires authorized real/deidentified case and trusted labels; synthetic policy tests do not count as DOMAIN runs.'}
           for category in CATEGORIES for i in range(1,6)]
    run=schedule(cases,seed=20261104)
    atomic_json(destination/'cases.json',cases)
    atomic_json(destination/'raw-results.json',run)
    atomic_json(destination/'comparison.json',summarize(run))
    with (destination/'raw-results.csv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=['case_id','variant','status','input_hash','criteria_hash','evidence'])
        writer.writeheader();writer.writerows({k:row.get(k) for k in writer.fieldnames} for row in run['jobs'])
    return {'status':'NOT_RUN','cases_enrolled':0,'planned_cases':30,'planned_runs':90}

TARGETS={'gpt-6.1-sol':('high',),'gpt-6.1-terra':('high','medium'),'gpt-6-luna':('high',),'gpt-6-astra':('high',)}

def validate_cases(cases,*,full=True):
    require(isinstance(cases,list) and len(cases)==(30 if full else 6),'evaluation_case_count')
    require(len({x.get('case_id') for x in cases})==len(cases),'evaluation_duplicate_case')
    for category in CATEGORIES:
        require(sum(x.get('category')==category for x in cases)==(5 if full else 1),'evaluation_category_count')
    validated=[]
    for source in cases:
        case=json.loads(canonical(source))
        safe_id(case['case_id'])
        require(case.get('provenance') in ('real','deidentified') and case.get('source_version') and case.get('objective'),'evaluation_provenance_required')
        require(case.get('criteria') and len({x['id'] for x in case['criteria']})==len(case['criteria']),'evaluation_criteria_required')
        require(all(x.get('id') and x.get('description') for x in case['criteria']),'evaluation_criterion_description')
        target=case.get('execution_target',{})
        require(target.get('effort') in TARGETS.get(target.get('model'),()),'evaluation_fixed_target_required')
        require(case.get('input_files'),'evaluation_inputs_required')
        inputs=[]
        for item in case['input_files']:
            path=Path(item['path']).resolve()
            require(path.is_file(),'evaluation_input_missing')
            actual=file_hash(path)
            require(not item.get('sha256') or item['sha256']==actual,'evaluation_input_changed')
            inputs.append({'path':str(path),'sha256':actual})
        label=case.get('trusted_label',{})
        require(label.get('authorized_by') and label.get('kind') in ('known_defect','clean','uncertain'),'evaluation_trusted_label_required')
        label_path=Path(label.get('path','')).resolve()
        require(label_path.is_file() and str(label_path) not in {x['path'] for x in inputs},'evaluation_label_must_be_separate')
        label_hash=file_hash(label_path)
        require(not label.get('sha256') or label['sha256']==label_hash,'evaluation_label_changed')
        case.update(input_files=inputs,input_hash=digest(inputs),criteria_hash=digest(case['criteria']),
                    model_effort=target,material_status='ENROLLED',trusted_label={**label,'path':str(label_path),'sha256':label_hash})
        validated.append(case)
    return validated

def enroll_cases(cases,destination,*,seed=20261104):
    cases=validate_cases(cases,full=True)
    destination=Path(destination)
    require(not destination.exists(),'evaluation_enrollment_requires_new_directory')
    destination.mkdir(parents=True)
    atomic_json(destination/'cases.json',cases)
    run=schedule(cases,seed=seed)
    atomic_json(destination/'raw-results.json',run)
    atomic_json(destination/'comparison.json',summarize(run))
    return run

def worker_packet(case,destination):
    """Copy only public task inputs; hidden labels/answer paths never enter it."""
    destination=Path(destination);destination.mkdir(parents=True,exist_ok=True)
    materials=[]
    for i,item in enumerate(case['input_files']):
        source=Path(item['path'])
        require(file_hash(source)==item['sha256'],'evaluation_input_changed')
        target=destination/f'{i}-{source.name}'
        require(not target.exists(),'evaluation_packet_target_exists')
        shutil.copyfile(source,target)
        require(file_hash(target)==item['sha256'],'evaluation_snapshot_changed')
        materials.append({'path':str(target.resolve()),'sha256':item['sha256']})
    packet={k:case[k] for k in ('case_id','category','objective','criteria','execution_target','input_hash','criteria_hash')}
    packet['materials']=materials
    atomic_json(destination/'task-input.json',packet)
    return packet

def record_run(run,cases,case_id,variant,receipt,metrics,*,trusted_collector):
    require(trusted_collector=='parent_validator','evaluation_trusted_collector_required')
    case=next((x for x in cases if x['case_id']==case_id),None)
    require(case is not None and variant in ('A','B','C'),'evaluation_run_identity')
    row=next(x for x in run['jobs'] if x['case_id']==case_id and x['variant']==variant)
    require(row['status']=='NOT_RUN' and not row.get('execution_recorded'),'evaluation_run_already_recorded')
    require(receipt.get('input_hash')==case['input_hash'] and receipt.get('criteria_hash')==case['criteria_hash'],'evaluation_comparison_input_drift')
    require(receipt.get('model_reported')==case['execution_target']['model'] and receipt.get('effort_reported')==case['execution_target']['effort'],'evaluation_observed_target_mismatch')
    require(receipt.get('attempt_id') and receipt.get('status') in ('completed','failed','not_run'),'evaluation_actual_execution_required')
    for key in ('evidence_ref','identity_evidence_ref'):
        require(Path(receipt.get(key,'')).is_file(),'evaluation_execution_evidence_missing')
    require(file_hash(case['trusted_label']['path'])==case['trusted_label']['sha256'],'evaluation_label_changed')
    checks=receipt.get('checks',[])
    require(checks and {x['criterion_id'] for x in checks}=={x['id'] for x in case['criteria']},'evaluation_checks_missing')
    require(all(x.get('status') in ('pass','fail','not_run') for x in checks),'evaluation_check_status')
    status='NOT_RUN' if receipt['status']=='not_run' or any(x['status']=='not_run' for x in checks) else 'FAILED' if receipt['status']=='failed' else 'COMPLETED'
    if status=='COMPLETED':
        require(set(METRICS)<=set(metrics),'evaluation_metrics_missing')
        require(type(metrics['satisfied']) is bool and type(metrics['route_compliant']) is bool,'evaluation_boolean_metric')
        require(all(type(metrics[k]) is int and metrics[k]>=0 for k in ('true_positive','false_positive','false_negative','clean_false_alarm','severe_miss','rework_rounds','invalid_escalation')),'evaluation_count_metric')
        require(all(metrics[k] is None or type(metrics[k]) in (int,float) and metrics[k]>=0 for k in ('human_review_seconds','elapsed_seconds','api_micro_usd')),'evaluation_resource_metric')
        require(not metrics['satisfied'] or all(x['status']=='pass' for x in checks),'evaluation_false_success')
    row.update(status=status,metrics=metrics if status=='COMPLETED' else None,evidence=receipt['evidence_ref'],
               execution_recorded=True,actual_receipt=receipt,evidence_sha256=file_hash(receipt['evidence_ref']))
    return row

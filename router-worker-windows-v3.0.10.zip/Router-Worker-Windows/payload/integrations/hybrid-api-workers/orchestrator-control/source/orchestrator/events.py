"""Durable local gateway, subscriptions, leased queue and notification outbox.

Delivery is at least once with idempotent local sinks. No payload is executable
instruction and no event source can grant permission or choose an agent model.
"""
from __future__ import annotations
from datetime import datetime, timezone
import json
from pathlib import Path
import secrets
import time
import uuid
from .common import atomic_json, canonical, digest, file_hash, require, safe_id

class EventGateway:
    def __init__(self,controller,*,allowed_sources=('local','worker','solver','timer','hook'),allowed_projects=()):
        self.c=controller
        self.allowed_sources=set(allowed_sources)
        self.allowed_projects=set(allowed_projects)

    def ingest(self,envelope,payload,*,authenticated_source,expires_at=None,producer_task_id=None):
        self.c.schema('event',envelope)
        require(envelope['source'] in self.allowed_sources and authenticated_source==envelope['source'],'event_source_not_authorized')
        require(envelope['project_id'] in self.allowed_projects,'event_project_not_authorized')
        safe_id(envelope['event_id'])
        raw=canonical(payload).encode()
        require(len(raw)<=1024*1024,'event_size_limit')
        require(digest(raw)==envelope['payload_hash'],'event_payload_hash_mismatch')
        require(envelope['trust_level']=='untrusted_external' or authenticated_source in ('worker','solver','hook'),'event_trust_not_granted')
        stamp=time.time()
        occurred=datetime.fromisoformat(envelope['occurred_at'].replace('Z','+00:00')).timestamp()
        require(occurred<=stamp+300,'event_time_in_future')
        meta={'expires_at':expires_at if expires_at is not None else occurred+86400,
              'producer_task_id':producer_task_id,'schema_version':envelope['schema_version']}
        with self.c.store.transaction() as db:
            old=db.execute('SELECT * FROM events WHERE source=? AND source_event_id=?',(envelope['source'],envelope['source_event_id'])).fetchone()
            if old:
                require(old['payload_hash']==envelope['payload_hash'] and old['project_id']==envelope['project_id']
                        and old['thread_key']==envelope['thread_key'] and old['event_type']==envelope['event_type'],'event_id_collision')
                return {'event_id':old['event_id'],'duplicate':True,'durable':True}
            path=self.c.root/'events'/f"{envelope['event_id']}.json"
            if path.exists():
                # A crash after durable payload write but before DB commit may
                # leave the identical orphan. Recover it without overwriting.
                require(digest(json.loads(path.read_text(encoding='utf-8')))==envelope['payload_hash'],'event_artifact_collision')
            else:
                atomic_json(path,payload)
            db.execute('INSERT INTO events VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
                       (envelope['event_id'],envelope['source'],envelope['source_event_id'],envelope['project_id'],
                        envelope['thread_key'],envelope['event_type'],envelope['payload_hash'],str(path),
                        envelope['trust_level'],envelope['causation_id'],envelope['correlation_id'],'pending',0,
                        envelope['occurred_at'],datetime.now(timezone.utc).isoformat()))
            db.execute('INSERT INTO event_meta VALUES(?,?)',(envelope['event_id'],canonical(meta)))
            return {'event_id':envelope['event_id'],'duplicate':False,'durable':True}

    def subscribe(self,task_id,thread_key,event_types,*,owner_attempt_id=None,expires_at=None):
        require(event_types and all(isinstance(x,str) and x for x in event_types),'event_type_required')
        with self.c.store.transaction() as db:
            t=self.c.store.task(task_id,db)
            sid=str(uuid.uuid4())
            if owner_attempt_id:
                require(db.execute('SELECT 1 FROM attempts WHERE attempt_id=? AND task_id=?',(owner_attempt_id,task_id)).fetchone(),'subscription_owner_mismatch')
            db.execute('INSERT INTO subscriptions VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(task_id,thread_key) DO UPDATE SET filter_json=excluded.filter_json,owner_attempt_id=excluded.owner_attempt_id,status=excluded.status,expires_at=excluded.expires_at',
                       (sid,task_id,t['project_id'],thread_key,canonical({'event_types':event_types}),owner_attempt_id,'active',str(expires_at) if expires_at else None))
            return sid

    def claim(self,owner,*,lease_seconds=30):
        if not self.c.config['events_enabled']:
            return None
        now=time.time()
        with self.c.store.transaction() as db:
            row=db.execute("SELECT e.* FROM events e LEFT JOIN queue_claims q USING(event_id) WHERE e.state IN ('pending','retry','processing') AND (q.event_id IS NULL OR q.expires<?) ORDER BY e.rowid LIMIT 1",(now,)).fetchone()
            if not row:
                return None
            token=secrets.token_hex(16)
            db.execute('INSERT INTO queue_claims VALUES(?,?,?,?) ON CONFLICT(event_id) DO UPDATE SET owner=excluded.owner,token=excluded.token,expires=excluded.expires',
                       (row['event_id'],owner,token,now+lease_seconds))
            db.execute("UPDATE events SET state='processing' WHERE event_id=?",(row['event_id'],))
            return {**dict(row),'claim_token':token,'owner':owner}

    def process(self,claim):
        with self.c.store.transaction() as db:
            q=db.execute('SELECT * FROM queue_claims WHERE event_id=?',(claim['event_id'],)).fetchone()
            require(q and q['token']==claim['claim_token'] and q['owner']==claim['owner'] and q['expires']>time.time(),'event_claim_lost')
            row=db.execute('SELECT * FROM events WHERE event_id=?',(claim['event_id'],)).fetchone()
            require(row['state']=='processing','event_not_processing')
            meta=json.loads(db.execute('SELECT data FROM event_meta WHERE event_id=?',(row['event_id'],)).fetchone()[0])
            path=Path(row['payload_ref'])
            require(path.is_file(),'event_payload_missing')
            payload=json.loads(path.read_text(encoding='utf-8'))
            require(digest(payload)==row['payload_hash'],'event_payload_changed')
            state='done'
            if meta['expires_at']<=time.time():
                state='expired'
            subscriptions=db.execute("SELECT * FROM subscriptions WHERE project_id=? AND thread_key=? AND status='active'",(row['project_id'],row['thread_key'])).fetchall()
            routed=[]
            if state=='done':
                for sub in subscriptions:
                    if sub['expires_at'] is not None and float(sub['expires_at'])<=time.time():
                        continue
                    if row['event_type'] not in json.loads(sub['filter_json'])['event_types']:
                        continue
                    task=self.c.store.task(sub['task_id'],db)
                    if meta.get('producer_task_id')==task['task_id']:
                        state='self_filtered'
                        continue
                    if row['causation_id']:
                        ancestor=db.execute('SELECT source,thread_key FROM events WHERE event_id=?',(row['causation_id'],)).fetchone()
                        if ancestor and ancestor['source']=='controller' and ancestor['thread_key']==task['task_id']:
                            state='self_filtered'
                            continue
                    version=payload.get('contract_version') if isinstance(payload,dict) else None
                    if version is not None and version!=task['contract_version']:
                        state='stale'
                        continue
                    active=db.execute("SELECT 1 FROM attempts WHERE task_id=? AND status IN ('starting','running','waiting_external','unknown')",(task['task_id'],)).fetchone()
                    reason='queued_until_safe_checkpoint' if active else 'parent_review_required'
                    if self.c.config['mode']=='observe':
                        reason='observe_only_no_model_or_file_action'
                    inbox_id=digest({'task':task['task_id'],'event':row['event_id']})
                    db.execute('INSERT OR IGNORE INTO continuation_inbox VALUES(?,?,?,?,?,?)',
                               (inbox_id,task['task_id'],row['event_id'],task['contract_version'],'pending',reason))
                    key=f"event:{row['event_id']}:task:{task['task_id']}:v{task['contract_version']}"
                    db.execute('INSERT OR IGNORE INTO outbox(outbox_id,event_id,delivery_key,destination,state) VALUES(?,?,?,?,?)',
                               (str(uuid.uuid4()),row['event_id'],key,'local_inbox','pending'))
                    routed.append(task['task_id'])
            if not routed and state=='done':
                # No reliable native original-session wakeup interface is assumed.
                db.execute('INSERT OR IGNORE INTO continuation_inbox VALUES(?,?,?,?,?,?)',
                           (digest({'event':row['event_id']}),'unassigned',row['event_id'],0,'pending','no_supported_native_session_control; manual_parent_pickup'))
            db.execute('UPDATE events SET state=? WHERE event_id=?',(state,row['event_id']))
            db.execute('DELETE FROM queue_claims WHERE event_id=?',(row['event_id'],))
            return {'event_id':row['event_id'],'state':state,'routed':routed,'model_invoked':False,'session_awakened':False}

    def fail(self,claim,*,reason,max_retries=2):
        with self.c.store.transaction() as db:
            q=db.execute('SELECT * FROM queue_claims WHERE event_id=?',(claim['event_id'],)).fetchone()
            require(q and q['token']==claim['claim_token'],'event_claim_lost')
            count=db.execute('SELECT retry_count FROM events WHERE event_id=?',(claim['event_id'],)).fetchone()[0]+1
            state='dead_letter' if count>=max_retries else 'retry'
            db.execute('UPDATE events SET state=?,retry_count=? WHERE event_id=?',(state,count,claim['event_id']))
            db.execute('DELETE FROM queue_claims WHERE event_id=?',(claim['event_id'],))
            atomic_json(self.c.root/'logs'/f"event-{claim['event_id']}-failure.json",{'reason_code':reason,'retry_count':count,'state':state})
            return state

    def deliver_outbox(self,*,fail=False):
        # Only the local idempotent inbox is supported. External sends require a
        # separate authorized action receipt and never use this retry mechanism.
        with self.c.store.transaction() as db:
            row=db.execute("SELECT * FROM outbox WHERE state IN ('pending','retry') ORDER BY rowid LIMIT 1").fetchone()
            if not row:
                return None
            require(row['destination']=='local_inbox','external_sink_not_authorized')
            db.execute('UPDATE outbox SET attempt_count=attempt_count+1 WHERE outbox_id=?',(row['outbox_id'],))
            if fail:
                db.execute("UPDATE outbox SET state='retry',last_error='injected_sink_failure' WHERE outbox_id=?",(row['outbox_id'],))
                return {'status':'retry','worker_rerun':False}
            db.execute('INSERT OR IGNORE INTO notification_log VALUES(?,?,?)',(row['delivery_key'],time.time(),canonical({'event_id':row['event_id']})))
            db.execute("UPDATE outbox SET state='delivered',acknowledged_at=?,last_error=NULL WHERE outbox_id=?",(str(time.time()),row['outbox_id']))
            return {'status':'delivered','delivery_key':row['delivery_key'],'worker_rerun':False}

def stable_file_event(path,previous,*,stable_seconds=1,now=None):
    p=Path(path)
    stat=p.stat()
    current={'path':str(p.resolve()),'size':stat.st_size,'mtime_ns':stat.st_mtime_ns,'sha256':file_hash(p),'observed_at':time.time() if now is None else now}
    same=previous and all(previous.get(k)==current[k] for k in ('path','size','mtime_ns','sha256'))
    stable=bool(same and current['observed_at']-previous['observed_at']>=stable_seconds)
    return {'stable':stable,'observation':current}

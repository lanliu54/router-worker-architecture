-- Initial storage design, not an installer. Apply through versioned migrations.
-- Controller is the sole authorized writer. SQL constraints alone do not enforce identity.
PRAGMA foreign_keys = ON;

CREATE TABLE schema_migrations (
  version INTEGER PRIMARY KEY,
  applied_at TEXT NOT NULL,
  checksum TEXT NOT NULL
);
CREATE TABLE tasks (
  task_id TEXT PRIMARY KEY,
  project_id TEXT NOT NULL,
  state TEXT NOT NULL,
  state_version INTEGER NOT NULL DEFAULT 1 CHECK (state_version >= 1),
  contract_version INTEGER NOT NULL CHECK (contract_version >= 1),
  contract_hash TEXT NOT NULL,
  contract_json TEXT NOT NULL,
  risk TEXT NOT NULL CHECK (risk IN ('L1','L2','L3')),
  complexity TEXT NOT NULL CHECK (complexity IN ('C0','C1','C2')),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE attempts (
  attempt_id TEXT PRIMARY KEY,
  task_id TEXT NOT NULL REFERENCES tasks(task_id),
  contract_version INTEGER NOT NULL,
  role TEXT NOT NULL,
  status TEXT NOT NULL,
  model_requested TEXT NOT NULL,
  model_reported TEXT,
  effort_requested TEXT NOT NULL,
  effort_reported TEXT,
  identity_evidence_level TEXT NOT NULL,
  channel TEXT NOT NULL,
  adapter_version TEXT NOT NULL,
  role_hash TEXT NOT NULL,
  permission_hash TEXT NOT NULL,
  input_manifest_hash TEXT NOT NULL,
  provider_request_id TEXT,
  process_id INTEGER,
  process_started_at TEXT,
  working_directory TEXT,
  started_at TEXT,
  finished_at TEXT,
  usage_json TEXT
);
-- Review and validation subtasks should have distinct task IDs where needed.
CREATE UNIQUE INDEX one_active_attempt_per_task ON attempts(task_id)
  WHERE status IN ('starting','running','waiting_external','unknown');
CREATE TABLE artifacts (
  artifact_id TEXT PRIMARY KEY,
  task_id TEXT NOT NULL REFERENCES tasks(task_id),
  attempt_id TEXT NOT NULL REFERENCES attempts(attempt_id),
  path TEXT NOT NULL,
  sha256 TEXT NOT NULL,
  size_bytes INTEGER NOT NULL CHECK (size_bytes >= 0),
  sensitivity TEXT NOT NULL,
  created_at TEXT NOT NULL,
  UNIQUE(attempt_id, path, sha256)
);
CREATE TABLE validations (
  validation_id TEXT PRIMARY KEY,
  task_id TEXT NOT NULL REFERENCES tasks(task_id),
  artifact_hash TEXT NOT NULL,
  criterion_id TEXT NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('pass','fail','not_run')),
  runner_id TEXT NOT NULL,
  runner_version TEXT NOT NULL,
  evidence_ref TEXT,
  receipt_json TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE TABLE reviews (
  review_id TEXT PRIMARY KEY,
  task_id TEXT NOT NULL REFERENCES tasks(task_id),
  artifact_hash TEXT NOT NULL,
  author_attempt_id TEXT NOT NULL,
  reviewer_attempt_id TEXT NOT NULL,
  verdict TEXT NOT NULL CHECK(verdict IN ('pass','changes_requested','inconclusive')),
  report_json TEXT NOT NULL,
  created_at TEXT NOT NULL,
  CHECK (author_attempt_id <> reviewer_attempt_id)
);
CREATE TABLE acceptances (
  acceptance_id TEXT PRIMARY KEY,
  task_id TEXT NOT NULL REFERENCES tasks(task_id),
  contract_version INTEGER NOT NULL,
  artifact_hash TEXT NOT NULL,
  decision TEXT NOT NULL CHECK(decision IN ('accept','rework','block','human_review','cancel')),
  sol_decision_ref TEXT NOT NULL,
  controller_version TEXT NOT NULL,
  receipt_json TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE TABLE events (
  event_id TEXT PRIMARY KEY,
  source TEXT NOT NULL,
  source_event_id TEXT NOT NULL,
  project_id TEXT NOT NULL,
  thread_key TEXT NOT NULL,
  event_type TEXT NOT NULL,
  payload_hash TEXT NOT NULL,
  payload_ref TEXT NOT NULL,
  trust_level TEXT NOT NULL,
  causation_id TEXT,
  correlation_id TEXT NOT NULL,
  state TEXT NOT NULL DEFAULT 'pending',
  retry_count INTEGER NOT NULL DEFAULT 0 CHECK(retry_count >= 0),
  occurred_at TEXT NOT NULL,
  received_at TEXT NOT NULL,
  UNIQUE(source, source_event_id)
);
CREATE TABLE outbox (
  outbox_id TEXT PRIMARY KEY,
  event_id TEXT NOT NULL REFERENCES events(event_id),
  delivery_key TEXT NOT NULL UNIQUE,
  destination TEXT NOT NULL,
  state TEXT NOT NULL DEFAULT 'pending',
  attempt_count INTEGER NOT NULL DEFAULT 0,
  next_attempt_at TEXT,
  acknowledged_at TEXT,
  last_error TEXT
);
CREATE TABLE subscriptions (
  subscription_id TEXT PRIMARY KEY,
  task_id TEXT NOT NULL REFERENCES tasks(task_id),
  project_id TEXT NOT NULL,
  thread_key TEXT NOT NULL,
  filter_json TEXT NOT NULL,
  owner_attempt_id TEXT,
  status TEXT NOT NULL,
  expires_at TEXT,
  UNIQUE(task_id, thread_key)
);
CREATE TABLE resource_leases (
  resource_key TEXT PRIMARY KEY,
  owner_attempt_id TEXT NOT NULL,
  fencing_token INTEGER NOT NULL CHECK(fencing_token > 0),
  lease_expires_at_epoch INTEGER NOT NULL,
  last_confirmed_at_epoch INTEGER NOT NULL
);
CREATE TABLE approvals (
  approval_id TEXT PRIMARY KEY,
  project_id TEXT NOT NULL,
  task_id TEXT NOT NULL REFERENCES tasks(task_id),
  artifact_hash TEXT NOT NULL,
  action TEXT NOT NULL,
  target TEXT NOT NULL,
  authorized_by TEXT NOT NULL,
  permission_hash TEXT NOT NULL,
  expires_at_epoch INTEGER NOT NULL,
  status TEXT NOT NULL,
  receipt_json TEXT NOT NULL
);
CREATE TABLE channel_health (
  channel_key TEXT PRIMARY KEY,
  state TEXT NOT NULL CHECK(state IN ('closed','open','half_open','unknown')),
  last_verified_at TEXT,
  failure_category TEXT,
  capability_ref TEXT,
  budget_state TEXT NOT NULL DEFAULT 'unknown'
);
CREATE TABLE action_receipts (
  action_id TEXT PRIMARY KEY,
  task_id TEXT NOT NULL REFERENCES tasks(task_id),
  attempt_id TEXT NOT NULL REFERENCES attempts(attempt_id),
  idempotency_key TEXT,
  external_system TEXT NOT NULL,
  external_reference TEXT,
  status TEXT NOT NULL CHECK(status IN ('prepared','started','succeeded','failed','unknown')),
  evidence_ref TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  UNIQUE(external_system,idempotency_key)
);
CREATE INDEX tasks_by_project_state ON tasks(project_id, state);
CREATE INDEX events_by_thread_state ON events(project_id, thread_key, state);
CREATE INDEX validations_by_task_hash ON validations(task_id, artifact_hash);

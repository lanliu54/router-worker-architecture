from __future__ import annotations
from contextlib import contextmanager, closing
import json
from pathlib import Path
import sqlite3
import time
from .common import ControlError, canonical, digest, require

EXTRA_DDL = '''
CREATE TABLE task_versions(task_id TEXT NOT NULL REFERENCES tasks(task_id), version INTEGER NOT NULL, contract_json TEXT NOT NULL, contract_hash TEXT NOT NULL, PRIMARY KEY(task_id,version));
CREATE TABLE task_meta(task_id TEXT PRIMARY KEY REFERENCES tasks(task_id), data TEXT NOT NULL);
CREATE TABLE audit(seq INTEGER PRIMARY KEY AUTOINCREMENT, task_id TEXT, actor TEXT NOT NULL, prior_state TEXT, next_state TEXT, state_version INTEGER, reason TEXT NOT NULL, evidence_ref TEXT NOT NULL, contract_version INTEGER, attempt_id TEXT, occurred_at REAL NOT NULL);
CREATE TABLE receipts(id TEXT PRIMARY KEY, task_id TEXT NOT NULL REFERENCES tasks(task_id), contract_version INTEGER NOT NULL, kind TEXT NOT NULL, artifact_hash TEXT NOT NULL, data TEXT NOT NULL, created_at REAL NOT NULL);
CREATE TABLE budget_reservations(attempt_id TEXT PRIMARY KEY, task_id TEXT NOT NULL REFERENCES tasks(task_id), amount INTEGER NOT NULL CHECK(amount>=0), actual INTEGER, state TEXT NOT NULL, usage_json TEXT NOT NULL);
CREATE TABLE resource_usage(task_id TEXT PRIMARY KEY REFERENCES tasks(task_id), wall_seconds REAL NOT NULL DEFAULT 0, disk_bytes INTEGER NOT NULL DEFAULT 0, attempts INTEGER NOT NULL DEFAULT 0, rework INTEGER NOT NULL DEFAULT 0, transient_retries INTEGER NOT NULL DEFAULT 0);
CREATE TABLE observations(attempt_id TEXT PRIMARY KEY, data TEXT NOT NULL, observed_at REAL NOT NULL);
CREATE TABLE failures(task_id TEXT NOT NULL, signature TEXT NOT NULL, kind TEXT NOT NULL, count INTEGER NOT NULL, PRIMARY KEY(task_id,signature,kind));
CREATE TABLE queue_claims(event_id TEXT PRIMARY KEY REFERENCES events(event_id), owner TEXT NOT NULL, token TEXT NOT NULL, expires REAL NOT NULL);
CREATE TABLE event_meta(event_id TEXT PRIMARY KEY REFERENCES events(event_id), data TEXT NOT NULL);
CREATE TABLE continuation_inbox(id TEXT PRIMARY KEY, task_id TEXT NOT NULL, event_id TEXT NOT NULL, contract_version INTEGER NOT NULL, state TEXT NOT NULL, reason TEXT NOT NULL, UNIQUE(task_id,event_id));
CREATE TABLE recall_records(record_id TEXT PRIMARY KEY, project_id TEXT NOT NULL, kind TEXT NOT NULL, version INTEGER NOT NULL, source TEXT NOT NULL, source_hash TEXT NOT NULL, created_at REAL NOT NULL, expires_at REAL, sensitivity TEXT NOT NULL, status TEXT NOT NULL, supersedes TEXT, data TEXT NOT NULL);
CREATE TABLE controller_settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE notification_log(delivery_key TEXT PRIMARY KEY, received_at REAL NOT NULL, data TEXT NOT NULL);
ALTER TABLE validations ADD COLUMN contract_version INTEGER NOT NULL DEFAULT 1;
ALTER TABLE validations ADD COLUMN author_attempt_id TEXT;
ALTER TABLE reviews ADD COLUMN contract_version INTEGER NOT NULL DEFAULT 1;
CREATE TABLE action_bindings(action_id TEXT PRIMARY KEY REFERENCES action_receipts(action_id), contract_version INTEGER NOT NULL, artifact_hash TEXT NOT NULL, action TEXT NOT NULL, target TEXT NOT NULL, permission_hash TEXT NOT NULL);
'''

class Store:
    def __init__(self, root, contract_dir):
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True,exist_ok=True)
        self.path = self.root/'state.sqlite'
        self.contract_dir = Path(contract_dir)
        # Additive, versioned, transactional migration. Never touches the API ledger.
        ddl = (self.contract_dir/'state-store.sql').read_text(encoding='utf-8')
        with closing(self.connect()) as db:
            db.execute('PRAGMA journal_mode=WAL')
            exists = db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='schema_migrations'").fetchone()
            if not exists:
                try:
                    db.executescript('BEGIN IMMEDIATE;\n'+ddl+'\n'+EXTRA_DDL)
                    db.execute('INSERT INTO schema_migrations VALUES(?,?,?)',(1,str(time.time()),digest((ddl+EXTRA_DDL).encode())))
                    db.commit()
                except Exception:
                    db.rollback()
                    raise
            row = db.execute('SELECT version,checksum FROM schema_migrations ORDER BY version DESC LIMIT 1').fetchone()
            require(row and row['version']==1 and row['checksum']==digest((ddl+EXTRA_DDL).encode()),'migration_version_conflict')

    def connect(self):
        db = sqlite3.connect(self.path, timeout=5, isolation_level=None)
        db.row_factory=sqlite3.Row
        db.execute('PRAGMA foreign_keys=ON')
        db.execute('PRAGMA synchronous=FULL')
        return db

    @contextmanager
    def transaction(self):
        db = self.connect()
        try:
            db.execute('BEGIN IMMEDIATE')
            yield db
            db.commit()
        except Exception:
            db.rollback()
            raise
        finally:
            db.close()

    @contextmanager
    def read(self):
        db=self.connect()
        try:
            yield db
        finally:
            db.close()

    def task(self, task_id, db=None):
        if db is None:
            with self.read() as conn:
                return self.task(task_id,conn)
        row=db.execute('SELECT * FROM tasks WHERE task_id=?',(task_id,)).fetchone()
        require(row is not None,'task_not_found')
        value=dict(row)
        value['contract']=json.loads(value.pop('contract_json'))
        value['meta']=json.loads(db.execute('SELECT data FROM task_meta WHERE task_id=?',(task_id,)).fetchone()[0])
        return value

    @staticmethod
    def meta(db,task_id,value):
        db.execute('UPDATE task_meta SET data=? WHERE task_id=?',(canonical(value),task_id))

    def backup(self,path):
        path=Path(path).resolve()
        require(path!=self.path,'backup_target_is_live_database')
        path.parent.mkdir(parents=True,exist_ok=True)
        with self.read() as source, closing(sqlite3.connect(path)) as target:
            source.backup(target)
            require(target.execute('PRAGMA integrity_check').fetchone()[0]=='ok','backup_integrity')
        return str(path)

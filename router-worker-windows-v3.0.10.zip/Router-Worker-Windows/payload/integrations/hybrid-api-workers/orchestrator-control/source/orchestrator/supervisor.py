"""Rule-only observation, recovery and budgets. It never terminates a solver."""
from __future__ import annotations
import json
from pathlib import Path
import time
from .adapters import process_identity
from .common import atomic_json, canonical, digest, require

class Watchdog:
    def __init__(self,controller):
        self.c=controller

    def observe(self,attempt_id,*,agent_heartbeat=None,tool=None,solver=None,quality=None):
        record={'agent_heartbeat':agent_heartbeat,'tool_process':tool,'solver_progress':solver,'quality_progress':quality}
        with self.c.store.transaction() as db:
            require(db.execute('SELECT 1 FROM attempts WHERE attempt_id=?',(attempt_id,)).fetchone(),'attempt_not_found')
            db.execute('INSERT INTO observations VALUES(?,?,?) ON CONFLICT(attempt_id) DO UPDATE SET data=excluded.data,observed_at=excluded.observed_at',(attempt_id,canonical(record),time.time()))
        return record

    def check(self,attempt_id,*,now=None,heartbeat_seconds=90):
        now=time.time() if now is None else now
        with self.c.store.transaction() as db:
            row=db.execute('SELECT * FROM attempts WHERE attempt_id=?',(attempt_id,)).fetchone()
            require(row is not None,'attempt_not_found')
            t=self.c.store.task(row['task_id'],db)
            obs=db.execute('SELECT data FROM observations WHERE attempt_id=?',(attempt_id,)).fetchone()
            obs=json.loads(obs[0]) if obs else {}
            heartbeat=obs.get('agent_heartbeat')
            missing=heartbeat is None or now-heartbeat>heartbeat_seconds
            tool=obs.get('tool_process') or {}
            solver=obs.get('solver_progress') or {}
            budget=self.c._resource_available(db,t)
            action='HEALTHY'
            if not budget:
                action='STOP_NEW_WORK_AND_CHECKPOINT'
            elif missing and solver.get('alive') is True:
                action='VERIFY_AGENT_KEEP_SOLVER'
            elif missing:
                action='RECONCILE_PROCESS'
            elif not obs.get('quality_progress'):
                action='OBSERVE_QUALITY_SEPARATELY'
            receipt={'attempt_id':attempt_id,'action':action,'observations':obs,'checked_at':now,
                     'terminate_solver':False,'log_growth_is_scientific_progress':False,'tool_state':tool.get('status','unknown')}
            return receipt

    def record_failure(self,task_id,signature,*,kind='rework',evidence_ref,threshold=2):
        require(kind in ('transient','rework','unchanged_result'),'failure_kind')
        self.c._check_evidence([evidence_ref])
        with self.c.store.transaction() as db:
            t=self.c.store.task(task_id,db)
            db.execute('INSERT INTO failures VALUES(?,?,?,1) ON CONFLICT(task_id,signature,kind) DO UPDATE SET count=count+1',(task_id,signature,kind))
            count=db.execute('SELECT count FROM failures WHERE task_id=? AND signature=? AND kind=?',(task_id,signature,kind)).fetchone()[0]
            if count>=threshold:
                t['meta']['hold']='repeat_failure_escalate'
                self.c.store.meta(db,task_id,t['meta'])
            return {'count':count,'action':'PAUSE_AND_ESCALATE' if count>=threshold else 'BOUNDED_DIAGNOSIS','kind':kind}

    def recover(self):
        results=[]
        with self.c.store.read() as db:
            rows=[dict(r) for r in db.execute("SELECT * FROM attempts WHERE status IN ('starting','running','waiting_external','unknown')")]
        for row in rows:
            if row.get('process_id'):
                current=process_identity(row['process_id'])
                same=current.get('started_at') is not None and current.get('started_at')==row['process_started_at']
                outcome='running' if same and current['status']=='running' else 'unknown'
                reason='original_process_still_running' if outcome=='running' else 'process_missing_or_identity_changed'
            else:
                current={'status':'unknown'}
                outcome='unknown'
                reason='provider_or_parent_native_query_required'
            receipt=self.c.root/'recovery'/f"{row['attempt_id']}-{digest(current)[:12]}.json"
            atomic_json(receipt,{'observation':current,'reason':reason,'automatic_rerun':False})
            if outcome=='unknown':
                self.c.reconcile_attempt(row['attempt_id'],{'status':'unknown','evidence_ref':str(receipt)})
            results.append({'attempt_id':row['attempt_id'],'status':outcome,'reason':reason,'rerun':False,'evidence_ref':str(receipt)})
        return results

    def account_resources(self,task_id,*,wall_seconds,disk_bytes):
        require(wall_seconds>=0 and disk_bytes>=0,'invalid_resource_usage')
        with self.c.store.transaction() as db:
            t=self.c.store.task(task_id,db)
            # Cumulative counters supplied by trusted supervisor; never reset on fallback.
            old=db.execute('SELECT * FROM resource_usage WHERE task_id=?',(task_id,)).fetchone()
            require(wall_seconds>=old['wall_seconds'],'resource_counter_regression')
            db.execute('UPDATE resource_usage SET wall_seconds=?,disk_bytes=? WHERE task_id=?',(wall_seconds,disk_bytes,task_id))
            return {'new_work_allowed':self.c._resource_available(db,t),'subscription_quota':'unknown'}

class ChannelCircuit:
    def __init__(self,store):
        self.store=store

    def set(self,key,state,*,category=None,evidence_ref=None):
        require(state in ('closed','open','half_open','unknown'),'circuit_state')
        with self.store.transaction() as db:
            db.execute('INSERT INTO channel_health VALUES(?,?,?,?,?,?) ON CONFLICT(channel_key) DO UPDATE SET state=excluded.state,last_verified_at=excluded.last_verified_at,failure_category=excluded.failure_category,capability_ref=excluded.capability_ref',
                       (key,state,str(time.time()),category,evidence_ref,'unknown'))

    def admit(self,key,*,probe=False,budget_authorized=False):
        with self.store.transaction() as db:
            row=db.execute('SELECT * FROM channel_health WHERE channel_key=?',(key,)).fetchone()
            if not row or row['state']=='unknown':
                return False
            if row['state']=='closed':
                return True
            if row['state']=='open' and probe and budget_authorized:
                # Atomic one-probe claim; later callers observe half_open and wait.
                db.execute("UPDATE channel_health SET state='half_open' WHERE channel_key=?",(key,))
                return True
            return False

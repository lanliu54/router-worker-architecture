"""API-first independent Sol QA; existing worker ledger owns execution/fallback."""
import copy
import json
import os
import sys
from pathlib import Path
from .adapters import APIWorkerAdapter
from .common import atomic_json,digest,file_hash,require
from .handoff import PARENT_FIELDS
from .policy import ROLE_TARGETS,same_model_family

class SolQA:
    reviewer_role='qa_sol'
    api_role='api_sol_qa'
    model='gpt-6.1-sol'
    def __init__(self,controller,service_root):
        self.c=controller;self.api=APIWorkerAdapter(service_root,controller)

    @staticmethod
    def require_current_binding(task, binding):
        snapshot=task['meta'].get('snapshot') or {}
        author=task['meta'].get('author') or {}
        require(task['contract_version']==binding['contract_version']
                and snapshot.get('hash')==binding['artifact_hash']
                and author.get('attempt_id')==binding['author_attempt_id'], 'stale_review')

    def project_from_owner(self,owner):
        routing_dir=str(self.api.root/'routing')
        if routing_dir not in sys.path:
            sys.path.insert(0,routing_dir)
        from project_handoffs import project_for_session
        return project_for_session(self.api.root.parents[1],owner)

    def verify_package_binding(self,task,package,binding):
        require(package['task']['qa_binding']==binding,'qa_binding_changed')
        manifest=package['evidence']['source_material_manifest']
        actual={item['material_id']:item['sha256'] for item in manifest}
        expected=self.c.qa_material_hashes(task)
        if 'astra_focus' in binding:
            selected=binding['astra_focus']['material_ids']
            expected={key:sha for key,sha in expected.items() if key in selected}
            require(set(expected)==set(selected),'qa_material_binding_invalid')
        require(len(actual)==len(manifest) and actual==expected,
                'qa_material_binding_invalid')
        return actual


    def claim_fallback(self,record_path):
        record=json.loads(Path(record_path).read_text())
        return self.api.engine().claim_subscription_fallback(record['provider_task_id'],record['parent_session_id'])

    def collect(self,record_path):
        path=Path(record_path).resolve();require(path.is_relative_to(self.c.root/'qa'),'qa_record_outside_runtime')
        record=json.loads(path.read_text());task=self.c.inspect(record['task_id']);binding=record['binding']
        require(task['contract_version']==binding['contract_version'] and task['meta']['snapshot']['hash']==binding['artifact_hash'],'stale_review')
        require(self.c._input_snapshots_valid(task),'input_snapshot_drift')
        if record.get('integrated_review'):
            with self.c.store.transaction() as db:
                self.require_current_binding(self.c.store.task(record['task_id'],db),binding)
            require(file_hash(record['review_path'])==record['review_sha256'],'qa_integrated_report_changed')
            return {'review_recorded':True,'reused':True,'task_id':record['task_id']}
        provider=self.api.engine().get_task(record['provider_task_id'])
        require(provider['package_hash']==record['package_hash'],'qa_package_changed')
        transport=provider.get('native_dispatch',{})
        collect_carrier=(provider['status']=='fallback_claimed' and transport.get('host_session_id')
                         and transport.get('phase')=='active')
        astra_parent = (self.reviewer_role == 'qa_astra'
                        and provider.get('astra_fallback_transport') == 'parent_subagent_review_v1')
        if self.reviewer_role=='qa_astra' and not astra_parent and (provider['status']=='fallback_ready' or collect_carrier):
            routing_dir=str(self.api.root/'routing')
            if routing_dir not in sys.path:
                sys.path.insert(0,routing_dir)
            from readonly_host import collect_astra_readonly_result,run_astra_readonly_fallback
            from worker_core import ELIGIBLE_CODES
            from api_balance import SESSION_NATIVE_REASON
            balance_route=(provider.get('reason')==SESSION_NATIVE_REASON
                           and provider.get('api_credit_rejection_receipt',{}).get('route')=='subscription')
            if collect_carrier or balance_route or provider.get('reason') in ELIGIBLE_CODES | {
                    'api_budget_insufficient_before_dispatch','confirmed_pre_inference_provider_unavailable'}:
                require(os.environ.get('CODEX_THREAD_ID')==record['parent_session_id'],'qa_readonly_host_owner_required')
                project=record.get('project_root') or self.project_from_owner(record['parent_session_id'])
                require(project is not None,'qa_project_root_required')
                package=self.api.engine().read_package(provider)
                self.verify_package_binding(task,package,binding)
                if collect_carrier:
                    provider=collect_astra_readonly_result(self.api.engine(),provider['id'],record['parent_session_id'])
                else:
                    provider=run_astra_readonly_fallback(
                        self.api.engine(),provider['id'],record['parent_session_id'],project)
        if provider['status'] not in ('completed','completed_observed'):
            result = {'review_recorded':False,'provider_status':provider['status'],'reason':provider.get('reason'),'rerun':False}
            if astra_parent and provider['status'] in ('fallback_ready', 'fallback_claimed'):
                result.update(native_transport='parent_subagent_review_v1', provider_task_id=provider['id'])
            return result
        package=self.api.engine().read_package(provider)
        materials=self.verify_package_binding(task,package,binding)
        model=provider.get('actual_model');effort=provider.get('requested_reasoning_effort')
        channel='api_worker';session='api:'+str(provider.get('response_id') or '')
        rule_proof=None
        if provider.get('route')=='subscription':
            native=provider.get('native_evidence',{})
            model=native.get('actual_model');effort=native.get('actual_reasoning_effort');channel='subscription_codex'
            session='native:'+str(native.get('native_thread_id') or '')
            sol_rules = self.reviewer_role == 'qa_sol' and package['task'].get('native_qa_boundary') == 'review_rules_v1'
            if sol_rules or astra_parent:
                boundary_key = 'native_astra_qa_boundary' if astra_parent else 'native_sol_qa_boundary'
                rule_proof=transport.get('qa_rule_evidence') or {}
                require(task['meta'].get(boundary_key)=='review_rules_v1'
                        and rule_proof.get('boundary')=='review_rules_v1'
                        and rule_proof.get('os_isolation_claimed') is False
                        and rule_proof.get('native_thread_id')==transport.get('child_id')==native.get('native_thread_id')
                        and rule_proof.get('package_hash')==provider['package_hash']
                        and rule_proof.get('completed_review_turn_id')
                        and rule_proof.get('review_result_sha256')==digest(provider['result'])
                        and rule_proof.get('trace_sha256') and rule_proof.get('observed_tool_calls'),
                        'qa_rule_evidence_unverified')
                routing_dir=str(self.api.root/'routing')
                if routing_dir not in sys.path:
                    sys.path.insert(0,routing_dir)
                from architecture_policy import ASTRA_READ_RECEIPT
                from sol_qa_rules import verify_bound_trace, verify_material_read_receipt
                try:
                    verify_bound_trace(rule_proof,self.api.root.parents[1])
                    if package['task'].get('astra_read_receipt') == ASTRA_READ_RECEIPT:
                        verify_material_read_receipt(package,rule_proof)
                except (ValueError,OSError,KeyError,TypeError):
                    require(False,'qa_rule_trace_integrity_failed')
            else:
                require(native.get('reviewed_artifacts_read_only_verified') is True and native.get('isolation_evidence_ref'),'qa_native_readonly_unverified')
            if self.reviewer_role=='qa_astra' and not astra_parent:
                transport=provider.get('native_dispatch',{})
                system=transport.get('system_readonly',{})
                require(transport.get('child_id')==native.get('native_thread_id')
                        and system.get('policy')=='read-only' and system.get('approval_policy')=='never'
                        and len(system.get('turn_ids',[]))==2,'qa_native_readonly_unverified')
            if rule_proof is None:
                self.c._check_evidence([native['isolation_evidence_ref']])
        else:
            require(provider.get('response_id') and provider.get('returned_reasoning_effort') in (None,'high'),'qa_provider_metadata_missing')
        require(model==self.model and effort=='high' and record.get('reviewer_role','qa_sol')==self.reviewer_role,'qa_actual_identity_mismatch')
        report=copy.deepcopy(provider['result']['Result']);require(isinstance(report,dict),'qa_report_not_object')
        for key in ('task_id','author_attempt_id','artifact_hash','reviewer_role'):require(report.get(key)==binding[key],'qa_report_binding_mismatch')
        require(report.get('reviewer_attempt_id')==provider['id'],'qa_reviewer_attempt_mismatch')
        evidence={x['material_id']:x['frozen_snapshot_reference'] for x in package['evidence']['source_material_manifest']}
        for finding in report.get('findings',[]):
            require(all(x in evidence for x in finding['evidence_refs']),'qa_unknown_material_reference')
            finding['evidence_refs']=[evidence[x] for x in finding['evidence_refs']]
        receipt_path=path.with_name(path.stem+'-execution.json')
        receipt={'channel':channel,'independent_context':True,'read_only':True,'tools_disabled':channel=='api_worker',
            'actual_model':model,'requested_effort':effort,'response_id':provider.get('response_id'),
            'provider_task_id':provider['id'],'exact_package_verified':True,'read_only_verified':True,
            'evidence_ref':str(receipt_path),'package_hash':provider['package_hash'],'api_usage':provider.get('api_usage'),
            'native_evidence':provider.get('native_evidence'),'acceptance_owner':'parent_main',
            'qa_material_sha256':materials}
        if 'astra_focus' in binding:
            receipt['astra_focus']=binding['astra_focus']
        if rule_proof is not None:
            receipt.update(read_only=False,read_only_verified=False,qa_rule_evidence=rule_proof)
        verified_astra_binding=None
        if 'astra_focus' in binding:
            require(package['identity']['task_id']==provider['id'],'qa_reviewer_attempt_mismatch')
            verified_astra_binding={'qa_binding':package['task']['qa_binding'],
                'provider_task_id':provider['id'],'package_hash':package['integrity']['package_sha256']}
            if rule_proof is not None:
                verified_astra_binding['rule_evidence_sha256'] = digest(rule_proof)
        atomic_json(receipt_path,receipt)
        with self.c.store.transaction() as db:
            self.require_current_binding(self.c.store.task(record['task_id'],db),binding)
            old=db.execute('SELECT report_json FROM reviews WHERE task_id=? AND reviewer_attempt_id=? AND artifact_hash=? '
                'AND contract_version=? AND author_attempt_id=?',
                (record['task_id'],provider['id'],binding['artifact_hash'],binding['contract_version'],binding['author_attempt_id'])).fetchone()
            if old:
                saved=json.loads(old[0]);require(all(saved.get(k)==v for k,v in report.items()),'qa_review_replay_conflict')
                if verified_astra_binding is not None:
                    require(saved.get('execution_receipt',{}).get('astra_collection_binding')==verified_astra_binding,
                            'astra_collection_proof_required')
        if not old:
            self.c.record_review(report,session_id=session,execution_receipt=receipt,
                                 verified_astra_binding=verified_astra_binding,
                                 expected_contract_version=binding['contract_version'])
        review_path=path.with_name(path.stem+'-review.json');atomic_json(review_path,report)
        record.update(integrated_review=True,review_path=str(review_path),review_sha256=file_hash(review_path));atomic_json(path,record)
        return {'review_recorded':True,'task_id':record['task_id'],'channel':channel,'main_acceptance_required':True}


class AstraQA(SolQA):
    reviewer_role='qa_astra'
    api_role='api_astra_review'
    model='gpt-6-astra'

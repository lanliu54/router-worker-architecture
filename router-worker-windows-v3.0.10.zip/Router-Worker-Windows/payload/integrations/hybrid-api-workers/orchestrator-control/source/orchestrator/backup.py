"""Consistent state + referenced evidence backups, with verified isolated restore."""
from __future__ import annotations
import json
from pathlib import Path
import shutil
import sqlite3
from contextlib import closing
from .common import atomic_json,digest,file_hash,require,within

def backup_runtime(controller,destination):
    destination=Path(destination).resolve()
    require(not destination.exists(),'backup_destination_exists')
    require(not destination.is_relative_to(controller.root),'backup_must_be_outside_runtime')
    destination.mkdir(parents=True)
    controller.store.backup(destination/'state.sqlite')
    with closing(sqlite3.connect((destination/'state.sqlite').as_uri()+'?mode=ro',uri=True)) as db:
        tasks=[json.loads(r[0]) for r in db.execute('SELECT data FROM task_meta')]
        events=[r[0] for r in db.execute('SELECT payload_ref FROM events')]
        receipts=[json.loads(r[0]) for r in db.execute('SELECT data FROM receipts')]
    paths=set()
    for meta in tasks:
        for item in meta['input_snapshots']:
            paths.add(item['path'])
        for item in (meta.get('snapshot') or {}).get('manifest',[]):
            paths.add(item['path'])
    paths.update(events)
    # Receipt files plus referenced validator/review/execution evidence are
    # included only from the controlled runtime, never broad home directories.
    for p in (controller.root/'tasks').rglob('*.json'):
        paths.add(str(p))
    def collect_refs(value):
        if isinstance(value,dict):
            for key,val in value.items():
                if key in ('evidence_refs','evidence_ref','sol_decision_ref'):
                    for candidate in val if isinstance(val,list) else [val]:
                        if isinstance(candidate,str) and Path(candidate).is_file():
                            require(within(candidate,[controller.root]),'external_evidence_requires_explicit_export')
                            paths.add(candidate)
                else:collect_refs(val)
        elif isinstance(value,list):
            for item in value:collect_refs(item)
    for receipt in receipts:collect_refs(receipt)
    manifest=[]
    for original in sorted(paths):
        src=Path(original).resolve()
        require(src.is_file() and within(src,[controller.root]),'backup_reference_outside_runtime')
        require(src.name not in ('auth.json','.env.local') and not src.name.startswith('.env'),'backup_secret_path_denied')
        rel=src.relative_to(controller.root)
        target=destination/'evidence'/rel
        target.parent.mkdir(parents=True,exist_ok=True)
        before=file_hash(src)
        shutil.copyfile(src,target)
        require(file_hash(target)==before and file_hash(src)==before,'backup_source_changed')
        manifest.append({'path':str(rel),'sha256':before})
    atomic_json(destination/'manifest.json',{'version':1,'runtime_origin':str(controller.root),'database_sha256':file_hash(destination/'state.sqlite'),
                'files':manifest,'credentials_included':False,'paths_rebased_on_restore':True})
    return {'backup':str(destination),'files':len(manifest),'credentials_included':False}

def restore_runtime(backup,destination):
    backup=Path(backup).resolve();destination=Path(destination).resolve()
    manifest=json.loads((backup/'manifest.json').read_text())
    require(not destination.exists(),'restore_destination_exists')
    require(file_hash(backup/'state.sqlite')==manifest['database_sha256'],'backup_database_hash_mismatch')
    for item in manifest['files']:
        path=backup/'evidence'/item['path']
        require(path.resolve().is_relative_to(backup/'evidence') and file_hash(path)==item['sha256'],'backup_evidence_hash_mismatch')
    destination.mkdir(parents=True)
    shutil.copyfile(backup/'state.sqlite',destination/'state.sqlite')
    for item in manifest['files']:
        target=destination/item['path'];target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(backup/'evidence'/item['path'],target)
    origin=Path(manifest['runtime_origin'])
    def rebase(value):
        if isinstance(value,dict):return {k:rebase(v) for k,v in value.items()}
        if isinstance(value,list):return [rebase(x) for x in value]
        if isinstance(value,str):
            try:
                p=Path(value)
                if p.is_absolute() and p.is_relative_to(origin):return str(destination/p.relative_to(origin))
            except (OSError,ValueError):pass
        return value
    # Content identities are independent of local storage paths. Rebase only
    # controller metadata, never source files or candidate artifact bytes.
    with closing(sqlite3.connect(destination/'state.sqlite')) as db:
        for task_id,data in db.execute('SELECT task_id,data FROM task_meta').fetchall():
            meta=rebase(json.loads(data))
            # A restored copy is an isolated recovery candidate, not permission to
            # publish a duplicate external action or resume a second writer.
            meta['hold']='restored_state_requires_reconciliation'
            db.execute('UPDATE task_meta SET data=? WHERE task_id=?',(json.dumps(meta),task_id))
        for table,pk,col in [('receipts','id','data'),('validations','validation_id','receipt_json'),
                             ('reviews','review_id','report_json'),('acceptances','acceptance_id','receipt_json'),
                             ('budget_reservations','attempt_id','usage_json')]:
            for rid,data in db.execute(f'SELECT {pk},{col} FROM {table}').fetchall():
                db.execute(f'UPDATE {table} SET {col}=? WHERE {pk}=?',(json.dumps(rebase(json.loads(data))),rid))
        for table,pk,col in [('artifacts','artifact_id','path'),('events','event_id','payload_ref')]:
            for rid,value in db.execute(f'SELECT {pk},{col} FROM {table}').fetchall():
                db.execute(f'UPDATE {table} SET {col}=? WHERE {pk}=?',(rebase(value),rid))
        db.commit()
        require(db.execute('PRAGMA integrity_check').fetchone()[0]=='ok','restored_database_integrity')
    for path in (destination/'tasks').glob('*/v*/receipts/*.json'):
        atomic_json(path,rebase(json.loads(path.read_text(encoding='utf-8'))))
    atomic_json(destination/'restore-receipt.json',{'source':str(backup),'automatic_dispatch':False,'publication_hold':True,'auth_restored':False})
    return {'restored':str(destination),'integrity':'ok','publication_hold':True}

"""Start the controller from its canonical editable source directory."""
from pathlib import Path
import sys

BASE = Path(__file__).resolve().parent


def use_source():
    source = BASE / "source"
    if not (source / "orchestrator" / "__init__.py").is_file():
        raise RuntimeError("Router-Worker controller source is missing.")
    sys.path.insert(0, str(source))
    return source


def main():
    use_source()
    arguments = sys.argv[1:]
    if arguments == ["hook"]:
        from orchestrator.hooks import main as entrypoint
        arguments = []
    else:
        from orchestrator.__main__ import main as entrypoint
    sys.argv[1:] = ["--runtime", str(BASE / "runtime"), *arguments]
    entrypoint()


if __name__ == "__main__":
    main()

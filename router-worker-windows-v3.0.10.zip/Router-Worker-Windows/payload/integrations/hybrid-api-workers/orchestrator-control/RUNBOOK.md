# Local Controller

Use [the active routing runbook](../RUNBOOK.md) for new subscription dispatch. The Controller is a separate local record and acceptance layer. Keep `mode=observe` and `dispatch_enabled=false`. Its MCP serves read-only status and inbox; it does not launch workers or call models. `python -X utf8 -B launch.py status` reports controller state, and `inspect <task-id>` reads the task and its existing evidence.

The accepted historical Controller task and its formal review receipts remain at their original paths. The historical Worker package that backs that review is identified in [the archive index](../state/legacy-archive.json). New built-in results need the evidence specified by their contract before formal acceptance.

## 任务与验收

`contracts/task.schema.json` 是任务契约。创建时核对输入哈希并冻结副本；原始输入始终禁止写入。每条验收条件冻结 ID、检查种类和硬性要求。Worker 提交 `result.json` 只能表示 submitted/blocked。适配器写入可观测执行身份，未知字段保持 not_observable。

`validation <report> --runner <trusted-id>` 记录程序验证，`review <report> --session <id> --execution-receipt <receipt>` 记录独立 QA。报告和证据必须指向当前快照。QA 需要与作者不同的会话和 attempt、正确审查角色及独立根会话的只读执行凭证。第一轮 QA 包不含作者自评或其他审查结论。风险和独立性按任务冻结契约判断。历史任务按原 profile 执行。

`accept <task> --decision-ref <文件>` 需要主会话的可定位决定（历史字段名 sol_decision_ref 保留兼容），Controller 再次检查原输入、快照、硬条件、独立 QA、未解决 major/critical 与执行保留状态。硬检查 not_run 不计通过。`publish-local <task> <新目标>` 在发布前重新校验，只能复制已通过的快照，目标必须不已存在。外发由独立 action receipt 管理；审批绑定项目、任务、权限、目标、动作、哈希和有效期，Worker 无权自批。状态未知时核对外部结果，禁止盲重试。

CLI 和本机数据库是受信父会话控制接口；同一 OS 用户可任意改控制源码、数据库或伪造本地证据时，本实现不提供对抗该用户的安全隔离。不要向不受信 Worker 暴露控制目录写权限。验证程序仅接受父会话注册的执行工具，子进程环境采用允许列表去掉密钥；这不等于网络或完整文件系统沙盒。独立 QA 的 Windows/CLI 沙盒与目标软件能力必须另行实测，缺少时保持 NOT_RUN/BLOCKED。


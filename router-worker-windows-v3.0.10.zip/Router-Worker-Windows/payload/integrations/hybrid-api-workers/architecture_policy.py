"""Versioned coordinator policy; legacy roots without a policy keep v1 behavior."""
import json
from pathlib import Path
import re
import time

ROOT_MODEL='gpt-6.1-terra'
ROOT_EFFORT='high'
ASTRA_PARENT_FALLBACK = 'parent_subagent_review_v1'
ASTRA_MANIFEST_DELIVERY = 'frozen_manifest_v1'
ASTRA_READ_RECEIPT = 'tool_delivery_v1'
NATIVE_DIRECT_ROLES={'api_sol_execution','api_sol_qa','api_luna_batch'}

def load(root):
    path=Path(root)/'architecture-policy.json'
    if not path.exists():return None
    policy=json.loads(path.read_text(encoding='utf-8'))
    return validate(policy)


def validate(policy):
    if not isinstance(policy,dict):
        raise ValueError('Coordinator policy must be an object.')
    version=policy.get('version')
    if version not in (2,3,4,5) or policy.get('root_model')!=ROOT_MODEL or policy.get('root_effort')!=ROOT_EFFORT:
        raise ValueError('Unsupported active coordinator policy; no controlled dispatch.')
    native_roles=policy.get('native_direct_roles',[])
    if (not isinstance(native_roles,list) or any(not isinstance(role,str) or role not in NATIVE_DIRECT_ROLES for role in native_roles)
            or native_roles and policy.get('profile') not in ('mandatory_delegation_v3','simplified_workflow_v5')):
        raise ValueError('Unsupported direct-native roles in coordinator policy.')
    if version==5 and policy.get('profile')!='simplified_workflow_v5':
        raise ValueError('Version 5 requires the simplified profile.')
    if version==5 and 'accounting_mode' in policy:
        raise ValueError('Budget policy remains controlled by the existing frozen role policy.')
    if version!=5 and policy.get('profile')=='simplified_workflow_v5':
        raise ValueError('The simplified profile requires coordinator policy version 5.')
    if 'host_spawn_effective_at_epoch' in policy:
        cutoff = policy['host_spawn_effective_at_epoch']
        if (version != 5 or type(cutoff) is not int or cutoff < policy['effective_at_epoch']
                or policy.get('release_status') != 'parent_accepted'):
            raise ValueError('Host spawn requires an accepted v5 policy and a valid cutover time.')
    qualification=policy.get('native_direct_qualification')
    if version==2 and ('native_direct_qualification' in policy or policy.get('release_status')=='qualification_in_progress'):
        raise ValueError('Direct-native qualification requires coordinator policy version 3.')
    if version in (3,4,5):
        if len(native_roles)!=len(NATIVE_DIRECT_ROLES) or set(native_roles)!=NATIVE_DIRECT_ROLES:
            raise ValueError('Version 3 requires the exact three managed native roles.')
        if version==3 and policy.get('release_status')=='qualification_in_progress':
            validate_qualification(qualification)
        elif policy.get('release_status')!='parent_accepted' or 'native_direct_qualification' in policy:
            raise ValueError('Version 3 requires an exact qualification grant or completed parent acceptance.')
    if (version in (4,5) and policy.get('astra_readonly_api_first') is not True
            or version not in (4,5) and 'astra_readonly_api_first' in policy):
        raise ValueError('Astra API-first read-only review requires the accepted v4 coordinator schema.')
    if 'astra_readonly_qualification' in policy:
        grant=policy['astra_readonly_qualification']
        if (version!=3 or policy.get('release_status')!='parent_accepted' or not isinstance(grant,dict)
                or set(grant)!={'parent_session_id','request_id','expires_at_epoch','material_sha256','probe_sha256'}
                or not isinstance(grant['parent_session_id'],str)
                or not re.fullmatch(r'[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}',grant['parent_session_id'])
                or not isinstance(grant['request_id'],str)
                or not re.fullmatch(r'[A-Za-z0-9_-]{1,160}',grant['request_id'])
                or type(grant['expires_at_epoch']) is not int or grant['expires_at_epoch']<=0
                or not isinstance(grant['material_sha256'],list) or not grant['material_sha256']
                or any(not isinstance(h,str) or not re.fullmatch(r'[a-f0-9]{64}',h) for h in grant['material_sha256'])
                or not isinstance(grant['probe_sha256'],str)
                or not re.fullmatch(r'[a-f0-9]{64}',grant['probe_sha256'])):
            raise ValueError('Astra qualification requires one owner, request, evidence and probe binding, and expiry.')
    return policy


def astra_parent_fallback(task):
    return (task.get('role') == 'api_astra_review'
            and task.get('astra_fallback_transport') == ASTRA_PARENT_FALLBACK)


def astra_direct_task(task):
    return (task.get('role')=='api_astra_review' and task.get('dispatch_mode')=='subscription_direct'
            and task.get('reason')=='native_direct')


def validate_qualification(grant):
    if not isinstance(grant,dict) or set(grant)!={'parent_session_id','requests','expires_at_epoch'}:
        raise ValueError('Native qualification requires an owner, exact requests, and an expiry.')
    owner=grant['parent_session_id']
    requests=grant['requests']
    expiry=grant['expires_at_epoch']
    if (not isinstance(owner,str) or not re.fullmatch(r'[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}',owner)
            or not isinstance(requests,dict) or set(requests)!=NATIVE_DIRECT_ROLES
            or any(not isinstance(rid,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,160}',rid) for rid in requests.values())
            or len(set(requests.values()))!=len(NATIVE_DIRECT_ROLES)
            or type(expiry) is not int or expiry <= 0):
        raise ValueError('Invalid native qualification owner, request IDs, or expiry.')


def qualification_allows(policy,role,parent,request_id):
    grant=(policy or {}).get('native_direct_qualification')
    if grant is None or not native_direct(policy,role):
        return True
    return (time.time()<grant['expires_at_epoch'] and parent==grant['parent_session_id']
            and request_id==grant['requests'][role])


def is_primary(who,policy):
    return bool(policy and who and not who.get('is_child') and not who.get('role')
                and who.get('model')==policy['root_model'] and who.get('effort')==policy['root_effort'])

def new_api_role_allowed(policy,role,created_at=None):
    if role=='api_terra_content':return False  # Historical records remain readable.
    if not policy:return True
    if role=='api_sol_execution':return policy.get('profile') in ('mandatory_delegation_v3','simplified_workflow_v5')
    return True

def native_direct(policy,role):
    return bool(policy and role in policy.get('native_direct_roles',[]))

def family(model):
    value=model.lower()
    for name in ('terra','sol','luna','astra'):
        if name in value:return name
    return value

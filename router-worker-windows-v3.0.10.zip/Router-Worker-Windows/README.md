# Router–Worker Windows 迁移包 v3.0.10

当前新任务统一由 Terra/high 主会话通过内置 `spawn_agent` 直接派遣四个订阅角色。付费 Worker API 的提交、重试和网络请求实现已从包中移除。Astra 仅通过 Codex 内置订阅子会话运行。现行 Hook 用于核对派遣与身份，Controller 保持观察模式。Luna 新直派使用父会话消息和授权输入；历史领取任务继续使用原冻结包、回执和校验规则。安装器只部署路由专用技能，保留目标机已有的项目管理与结构映射技能。

解压后在 `Router-Worker-Windows` 目录运行。需要 Windows、Codex 和 Python 3.12 或更新版本。

```powershell
python -X utf8 -B .\portable.py check-package
python -X utf8 -B .\portable.py install
python -X utf8 -B .\portable.py install --apply
python -X utf8 -B .\portable.py verify
```

已有旧版时，使用[原地升级指南](原地升级指南.md)。新装默认进入维护状态。核对配置并结束维护后重启 Codex，在新会话检查四个角色、实际派遣和 Hook 回调。目标机 Hook 信任需在 Codex 中审核；包不转移信任、凭据、账本、冻结材料或私有数据。

安装记录以部署时的文件为准。结束维护或审核 Hook 后，若验证或回退报告配置变动，先核对并协调变动。

安装回退先运行 `portable.py rollback`，预览无冲突后加 `--apply`。离线验证范围见 `VALIDATION.json`。
